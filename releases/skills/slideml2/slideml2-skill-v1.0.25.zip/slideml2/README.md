# SlideML2 Skill Package

Version: 1.0.25

Use this skill whenever the user asks to create, edit, render, review, or export slide decks, presentations, PPT, PPTX, or SlideML2 decks. This skill is the component reference for Cowork's SlideML2 deck tools.

## Install

Unzip this archive so the target agent has a skill directory like:

```
slideml2/
  SKILL.md
  business.md
  LICENSE.txt
  manifest.json
  runtime/
    package.json
    src/
    dist/
    node_modules/
    bin/slideml2.js
```

For Codex-style local skill installs, place that `slideml2` directory under
the agent's skills directory, for example `$CODEX_HOME/skills/slideml2`.

## Runtime

The `runtime/` directory is a standalone SlideML2 package. It includes all
runtime TypeScript source under `runtime/src`, compiled JavaScript under
`runtime/dist`, examples, and validation/render docs. The agent-facing
entrypoint remains the CLI below.

After unzipping, production dependencies are already bundled. Normal deck
authoring runs directly with Node.js; do not run `npm install` for ordinary
use.

```bash
export SLIDEML2_SKILL_DIR=/path/to/slideml2
mkdir -p /path/to/deck-workdir
cd /path/to/deck-workdir
node "$SLIDEML2_SKILL_DIR/runtime/bin/slideml2.js" create-deck create-deck.json
node "$SLIDEML2_SKILL_DIR/runtime/bin/slideml2.js" replace-slide replace-slide-01.json
node "$SLIDEML2_SKILL_DIR/runtime/bin/slideml2.js" validate-render validate-render.json
```

All CLI commands run from the deck workspace. If an argument file omits
`deckPath`, the CLI reads and writes `./deck.json` in that workspace.

Supported agent-facing commands are:

- `create-deck`
- `read-deck`
- `replace-slide`
- `validate-render`

Do not call TypeScript handlers, npm scripts, or tool adapters as the agent
interface. Run `npm install` only when you need development dependencies for
TypeScript rebuilds:

```bash
cd "$SLIDEML2_SKILL_DIR/runtime"
npm install
npm run build
```
