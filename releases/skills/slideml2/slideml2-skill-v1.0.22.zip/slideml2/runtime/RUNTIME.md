# SlideML2 Runtime

This directory is bundled with the SlideML2 skill so another agent can run the
renderer and authoring loop without the full Cowork repository.

## Install

Production dependencies are bundled in the package, so basic runtime commands
can run immediately with Node.js:

```bash
node bin/slideml2.js render examples/data-binding-business-analysis.json output/example.pptx
```

Run `npm install` only when you need development dependencies such as
TypeScript rebuilds, `tsx`, or tests:

```bash
npm install
npm run build
```

## Render A Deck

```bash
npm run render -- examples/data-binding-business-analysis.json output/example.pptx
```

This writes the PPTX plus validation, diagnostics, inspect-layout, and
render-tree JSON files next to the output path.

## Markdown-To-PPTX Agent Loop

```bash
LLM_API=... LLM_API_KEY=... LLM_MODEL=... npm run md2pptx -- input.md output.pptx
```

## Tool Adapter Source

`tools/md2pptx/tools.ts` contains standalone TypeScript implementations for:

- describe_schema
- create_deck
- read_deck
- replace_slide
- patch_deck
- validate_render

Agents with their own tool/plugin systems can wrap those handlers directly.

## Standalone CLI

Use the CLI when the target agent does not expose native SlideML2 tools:

```bash
node bin/slideml2.js create-deck create-deck.args.json
node bin/slideml2.js replace-slide replace-slide.args.json
node bin/slideml2.js validate-render validate-render.args.json
```

Do not write a complete deck JSON and jump straight to `render` for normal
deck creation. Use `create-deck` and per-slide `replace-slide` so validation
can reject bad slides before they enter the source deck.
