# SlideML2 Runtime

This directory is bundled with the SlideML2 skill so another agent can run the
renderer and authoring loop without the full Cowork repository.

## Install

```bash
npm install
npm run build
```

## Render A Deck

```bash
npm run render -- examples/data-binding-business-analysis.json output/example.pptx
```

This writes the PPTX plus validation, diagnostics, inspect-layout, and
render-tree JSON files next to the output path.

## Markdown-To-PPTX Agent Loop

```bash
LLM_API=... LLM_API_KEY=... LLM_MODEL=... npm run md2pptx -- input.md output.pptx
```

## Tool Adapter Source

`tools/md2pptx/tools.ts` contains standalone TypeScript implementations for:

- describe_schema
- create_deck
- read_deck
- replace_slide
- patch_deck
- validate_render

Agents with their own tool/plugin systems can wrap those handlers directly.
