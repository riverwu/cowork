# SlideML2 Skill Package

Version: 1.0.22

Use this skill whenever the user asks to create, edit, render, review, or export slide decks, presentations, PPT, PPTX, or SlideML2 decks. This skill is the component reference for Cowork's SlideML2 deck tools.

## Install

Unzip this archive so the target agent has a skill directory like:

```
slideml2/
  SKILL.md
  business.md
  LICENSE.txt
  manifest.json
  runtime/
    package.json
    src/
    dist/
    node_modules/
    tools/
    bin/slideml2.js
```

For Codex-style local skill installs, place that `slideml2` directory under
the agent's skills directory, for example `$CODEX_HOME/skills/slideml2`.

## Runtime

The `runtime/` directory is a standalone SlideML2 package. It includes all
runtime TypeScript source under `runtime/src`, compiled JavaScript under
`runtime/dist`, authoring/rendering tools under `runtime/tools`, examples,
and validation/render docs.

After unzipping, production dependencies are already bundled. Basic runtime
commands can run directly with Node.js:

```bash
cd slideml2/runtime
node bin/slideml2.js render examples/data-binding-business-analysis.json output/example.pptx
```

Run `npm install` only when you need development dependencies such as
TypeScript rebuilds, `tsx`, or tests:

```bash
npm install
npm run build
npm run render -- examples/data-binding-business-analysis.json output/example-dev.pptx
```

LLM-backed markdown-to-PPTX generation is also included:

```bash
cd slideml2/runtime
LLM_API=... LLM_API_KEY=... LLM_MODEL=... npm run md2pptx -- input.md output.pptx
```

For agents that need tool adapters, start from
`runtime/tools/md2pptx/tools.ts`. It contains standalone implementations for
`describe_schema`, `create_deck`, `read_deck`, `replace_slide`,
`patch_deck`, and `validate_render` using the included SlideML2 runtime.

For command-line use without an agent adapter, run:

```bash
node runtime/bin/slideml2.js create-deck create-deck.args.json
node runtime/bin/slideml2.js replace-slide replace-slide.args.json
node runtime/bin/slideml2.js validate-render validate-render.args.json
```
