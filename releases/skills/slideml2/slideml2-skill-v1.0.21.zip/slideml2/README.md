# SlideML2 Skill Package

Version: 1.0.21

Use this skill whenever the user asks to create, edit, render, review, or export slide decks, presentations, PPT, PPTX, or SlideML2 decks. This skill is the component reference for Cowork's SlideML2 deck tools.

## Install

Unzip this archive so the target agent has a skill directory like:

```
slideml2/
  SKILL.md
  business.md
  LICENSE.txt
  manifest.json
```

For Codex-style local skill installs, place that `slideml2` directory under
the agent's skills directory, for example `$CODEX_HOME/skills/slideml2`.

This package contains only the SlideML2 skill instructions and references. The
target agent still needs compatible Cowork/SlideML2 tools, including
`create_deck`, `replace_slide`, `read_deck`, `patch_deck`,
`generate_icon_sheet`, and `validate_render`.
