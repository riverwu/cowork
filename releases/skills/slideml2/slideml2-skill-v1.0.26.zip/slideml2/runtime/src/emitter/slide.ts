/**
 * Build `ppt/slides/slide{N}.xml` from a `SlideAst`.
 *
 * The slide envelope is fixed boilerplate; the variable parts are the
 * shape tree (`<p:spTree>`) and an optional background fill.
 */

import { gradientFillXml, shapeXml, type SlideRels } from "./shapes.js";
import { assertHex } from "./xml.js";
import type { SlideAst } from "./types.js";

const SLIDE_NS =
  ` xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"` +
  ` xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"` +
  ` xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"`;

export interface SlideXml {
  /** The full `slide{N}.xml` body, ready to write to the package. */
  body: string;
  /** Relationships the slide accumulated (images, charts, etc). */
  rels: SlideRels;
}

/** Produce `slide{N}.xml` for one `SlideAst`. */
export function slideXml(slide: SlideAst, slidePart: string): SlideXml {
  const rels: SlideRels = { entries: [] };

  // Background image needs a slide-level rel BEFORE shape rels, so the
  // package emitter can match it deterministically. nextRelId for shapes
  // starts at rId2, so an image-bg consumes rId2 and bumps shapes to rId3+.
  const bgXml = backgroundXml(slide, rels);

  // Required first two shapes: the title placeholder and the body
  // placeholder slots are NOT mandatory in OOXML for slides that don't
  // declare placeholders. We simply emit a `nvGrpSpPr` group then our
  // content shapes.
  const groupHeader =
    `<p:nvGrpSpPr>` +
    `<p:cNvPr id="1" name=""/>` +
    `<p:cNvGrpSpPr/>` +
    `<p:nvPr/>` +
    `</p:nvGrpSpPr>` +
    `<p:grpSpPr>` +
    `<a:xfrm>` +
    `<a:off x="0" y="0"/>` +
    `<a:ext cx="0" cy="0"/>` +
    `<a:chOff x="0" y="0"/>` +
    `<a:chExt cx="0" cy="0"/>` +
    `</a:xfrm>` +
    `</p:grpSpPr>`;

  const shapesXml = slide.shapes.map((s) => shapeXml(s, slidePart, rels)).join("");

  const spTree = `<p:spTree>${groupHeader}${shapesXml}</p:spTree>`;

  const cSld = `<p:cSld>${bgXml}${spTree}</p:cSld>`;
  const clrMapOvr = `<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>`;

  const body = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld${SLIDE_NS}>${cSld}${clrMapOvr}</p:sld>`;

  return { body, rels };
}

function backgroundXml(slide: SlideAst, rels: SlideRels): string {
  if (!slide.background) return "";
  if (slide.background.type === "solid") {
    assertHex(slide.background.color, "Slide.background.color");
    return (
      `<p:bg>` +
      `<p:bgPr>` +
      `<a:solidFill><a:srgbClr val="${slide.background.color.toUpperCase()}"/></a:solidFill>` +
      `<a:effectLst/>` +
      `</p:bgPr>` +
      `</p:bg>`
    );
  }
  if (slide.background.type === "gradient") {
    return (
      `<p:bg>` +
      `<p:bgPr>` +
      gradientFillXml(slide.background, "Slide.background") +
      `<a:effectLst/>` +
      `</p:bgPr>` +
      `</p:bg>`
    );
  }
  // Image background: register a slide-level image rel and emit blipFill.
  // The package emitter rewrites the placeholder Target to the actual
  // `../media/imageN.{ext}` once it has resolved the asset.
  const rId = `rId${rels.entries.length + 2}`; // rId1 reserved for slideLayout
  rels.entries.push({
    id: rId,
    type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
    target: `../media/__background-${slide.background.src}`, // package emitter rewrites
  });
  return (
    `<p:bg>` +
    `<p:bgPr>` +
    `<a:blipFill dpi="0" rotWithShape="1">` +
    `<a:blip r:embed="${rId}"/>` +
    `<a:srcRect/>` +
    `<a:stretch><a:fillRect/></a:stretch>` +
    `</a:blipFill>` +
    `<a:effectLst/>` +
    `</p:bgPr>` +
    `</p:bg>`
  );
}

/** Build the `slide{N}.xml.rels` document for a slide's relationships. */
export function slideRelsXml(rels: SlideRels, slideLayoutRId: string): string {
  // Every slide must have a relationship to its slideLayout.
  const layoutRel =
    `<Relationship Id="${slideLayoutRId}" ` +
    `Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" ` +
    `Target="../slideLayouts/slideLayout1.xml"/>`;

  const otherRels = rels.entries
    .map((e) => {
      const tm = e.targetMode ? ` TargetMode="${e.targetMode}"` : "";
      // Hyperlink targets must be XML-escaped (& → &amp;) but the target is
      // already a URL with possible &; we minimal-escape to keep it safe.
      const target = e.target.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
      return `<Relationship Id="${e.id}" Type="${e.type}" Target="${target}"${tm}/>`;
    })
    .join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${layoutRel}${otherRels}</Relationships>`;
}
