/**
 * Asset pipeline.
 *
 * One place to turn an image-shaped src (path / URL / data URL) into bytes
 * and assign it a stable place in the OOXML package. Used for both image
 * shapes and background images so a single image referenced in both ways
 * is embedded only once.
 *
 * Disk cache (~/.cache/slideml/) survives between builds — agents that
 * generate a deck once a minute don't re-download remote images.
 */
import { createHash } from "node:crypto";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { resolveImage } from "./emitter/image.js";
/**
 * Collect assets across a deck render. The package emitter creates one
 * Assets instance per compile, calls `intern(src)` for every image source
 * encountered, and at the end iterates `entries` to write `ppt/media/` files.
 *
 * `intern` is idempotent for the same `src` — the second call returns the
 * already-allocated filename and reuses the bytes.
 */
export class Assets {
    constructor(baseDir) {
        this.byKey = new Map();
        this.nextIndex = 1;
        this.baseDir = baseDir ?? process.cwd();
    }
    /** Resolve a src and return its allocated package filename. */
    async intern(src) {
        const key = this.normalize(src);
        const existing = this.byKey.get(key);
        if (existing)
            return existing;
        const resolved = await resolveSrc(key);
        const filename = `image${this.nextIndex++}.${resolved.ext}`;
        const entry = { filename, resolved };
        this.byKey.set(key, entry);
        return entry;
    }
    /** Look up a previously-interned src without resolving. */
    get(src) {
        return this.byKey.get(this.normalize(src));
    }
    /** All assets that should be written under `ppt/media/`. */
    entries() {
        return [...this.byKey.values()];
    }
    /** Unique file extensions in the package (drives Content_Types defaults). */
    extensions() {
        const exts = new Set();
        for (const e of this.byKey.values())
            exts.add(e.resolved.ext);
        return exts;
    }
    /**
     * Normalize a src into a stable cache key:
     *   - data: URLs and http(s) URLs → as-is
     *   - relative paths → resolved against baseDir
     *   - absolute paths → as-is
     */
    normalize(src) {
        if (src.startsWith("data:"))
            return src;
        if (/^https?:\/\//i.test(src))
            return src;
        return isAbsolute(src) ? src : resolve(this.baseDir, src);
    }
}
// ---- HTTP disk cache ------------------------------------------------------
const HTTP_CACHE_DIR = join(homedir(), ".cache", "slideml", "http");
async function resolveSrc(src) {
    if (/^https?:\/\//i.test(src)) {
        const cached = await readHttpCache(src);
        if (cached)
            return cached;
        const fresh = await resolveImage(src);
        await writeHttpCache(src, fresh);
        return fresh;
    }
    // Local path or data URL — resolveImage handles both directly.
    return resolveImage(src);
}
async function readHttpCache(url) {
    const path = httpCachePath(url);
    if (!existsSync(path) || !existsSync(`${path}.meta`))
        return undefined;
    try {
        const bytes = await readFile(path);
        const meta = JSON.parse(await readFile(`${path}.meta`, "utf8"));
        return {
            bytes: new Uint8Array(bytes),
            ext: meta.ext,
            mimeType: meta.mimeType,
            ...(meta.dimensions ? { dimensions: meta.dimensions } : {}),
        };
    }
    catch {
        return undefined;
    }
}
async function writeHttpCache(url, img) {
    const path = httpCachePath(url);
    await mkdir(dirname(path), { recursive: true });
    await writeFile(path, img.bytes);
    await writeFile(`${path}.meta`, JSON.stringify({
        ext: img.ext, mimeType: img.mimeType,
        ...(img.dimensions ? { dimensions: img.dimensions } : {}),
    }));
}
function httpCachePath(url) {
    // Hash the full URL — short, collision-free, filesystem-safe.
    const h = createHash("sha256").update(url).digest("hex").slice(0, 32);
    return join(HTTP_CACHE_DIR, h);
}
