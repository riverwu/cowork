/**
 * ShapeList — the IR the emitter consumes.
 *
 * Layouts (Stage 3) produce `Shape[]` per slide using helpers that take
 * cm/in/pt and convert to EMU. By the time anything reaches the emitter,
 * every number is EMU. Tools that read `Shape` must not re-interpret units.
 */
export {};
