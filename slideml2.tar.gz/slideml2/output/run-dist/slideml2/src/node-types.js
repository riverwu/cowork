export const NODE_TYPES = [
    {
        type: "slide",
        use: "Root of one slide. Set background and hold top-level containers.",
        fields: {
            background: "theme token or 6-char hex",
        },
        acceptsChildren: ["stack", "grid", "spacer", "divider", "text", "bullets", "image", "table", "chart", "shape", "component"],
    },
    {
        type: "stack",
        use: "Auto-layout container that arranges children vertically or horizontally.",
        fields: {
            direction: "vertical | horizontal",
            gap: "number in px-like layout units",
            area: "content | full | left | right | bottom-right",
            align: "start | center | end",
            padding: "number in px-like layout units",
            fill: "theme token",
            line: "theme token",
            layoutWeight: "number; explicit grow weight for stack children",
            fixedHeight: "number in cm; agent-specified height wins over inference",
            minHeight: "number in cm; lower bound when renderer infers",
            maxHeight: "number in cm; upper bound when renderer infers",
        },
        acceptsChildren: ["spacer", "divider", "text", "bullets", "image", "table", "chart", "shape", "component", "stack", "grid"],
    },
    {
        type: "grid",
        use: "Auto-layout container that arranges children in equal columns.",
        fields: {
            columns: "number",
            gap: "number in px-like layout units",
            area: "content | full",
            columnWeights: "number[]; explicit column proportions, otherwise equal",
            rowWeights: "number[]; explicit row proportions, otherwise equal",
            fixedHeight: "number in cm; agent-specified height wins over inference",
        },
        acceptsChildren: ["spacer", "divider", "text", "bullets", "image", "table", "chart", "shape", "component", "stack"],
    },
    {
        type: "spacer",
        use: "Layout-only empty space. Use for intentional gaps, flexible push, or breathing room inside stack/grid.",
        fields: {
            fixedWidth: "number in cm; explicit width in horizontal stacks or grids",
            fixedHeight: "number in cm; explicit height in vertical stacks or grids",
            minWidth: "number in cm; lower bound when width is inferred",
            minHeight: "number in cm; lower bound when height is inferred",
            layoutWeight: "number; set to grow and consume remaining stack space",
        },
    },
    {
        type: "divider",
        use: "Visual separator or splitter line between regions. OOXML-like line shape with layout-aware thickness.",
        fields: {
            orientation: "horizontal | vertical | auto",
            thickness: "number in px-like layout units",
            line: "theme token or 6-char hex",
            fixedWidth: "number in cm; useful for vertical dividers",
            fixedHeight: "number in cm; useful for horizontal dividers",
        },
    },
    {
        type: "text",
        use: "Single title, subtitle, paragraph, caption, or source line.",
        fields: {
            text: "string",
            style: "theme text style; usually omitted for agents",
            color: "theme token or 6-char hex",
            align: "left | center | right",
            fixedHeight: "number in cm; agent-specified height wins over inference",
        },
    },
    {
        type: "bullets",
        use: "List of parallel points, steps, options, or business lines.",
        fields: {
            items: "string[]",
            density: "comfortable | compact",
        },
    },
    {
        type: "image",
        use: "Single image, logo, or visual asset.",
        fields: {
            src: "absolute path, URL, or data URL",
            alt: "string",
            caption: "optional string rendered below the image",
            fit: "cover | contain | fill",
            position: "bottom-right | top-right | center",
            width: "number in px-like layout units",
            height: "number in px-like layout units",
            fixedHeight: "number in cm; agent-specified height wins over inference",
            minHeight: "number in cm; lower bound when renderer infers",
        },
    },
    {
        type: "table",
        use: "Primitive table for compact structured comparisons or data rows.",
        fields: {
            headers: "string[]",
            rows: "string[][]",
            caption: "optional string rendered below the table",
            fixedHeight: "number in cm; agent-specified height wins over inference",
        },
    },
    {
        type: "chart",
        use: "Primitive chart for simple native bar, line, pie, doughnut, or area charts.",
        fields: {
            chartType: "bar | line | pie | doughnut | area",
            labels: "string[]",
            series: "array of {name?, values:number[]}",
            title: "string",
            axis: "optional object for axis labels or formatting",
            legend: "optional object for legend visibility or position",
            caption: "optional string rendered below the chart",
            showValues: "boolean",
            fixedHeight: "number in cm; agent-specified height wins over inference",
        },
    },
    {
        type: "shape",
        use: "Primitive geometric mark, rule, divider, or simple background shape.",
        fields: {
            preset: "rect | roundRect | ellipse | line",
            fill: "theme token or 6-char hex",
            line: "theme token or 6-char hex",
            fixedHeight: "number in cm; agent-specified height wins over inference",
        },
    },
    {
        type: "component",
        use: "Agent-facing component selected from listComponents(); may expand to a primitive, semantic leaf, or composite node.",
        fields: {
            component: "registered component name",
            "...fields": "component-specific fields from describeComponent(name)",
        },
    },
];
export function listNodeTypes() {
    return NODE_TYPES;
}
export function describeNodeType(type) {
    const found = NODE_TYPES.find((item) => item.type === type);
    if (!found)
        throw new Error(`Unknown node type: ${type}`);
    return found;
}
