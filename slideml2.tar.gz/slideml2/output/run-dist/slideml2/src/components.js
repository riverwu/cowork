export function titleText(slideId, id, text) {
    return { id: `${slideId}.${id}`, type: "component", component: "slide-title", text, align: "left" };
}
export function paragraphText(slideId, id, text) {
    return { id: `${slideId}.${id}`, type: "component", component: "text", text, align: "left" };
}
export function bulletList(slideId, id, items, density = "comfortable") {
    return { id: `${slideId}.${id}`, type: "bullets", items, density };
}
export function imageBlock(slideId, id, src, alt, fit = "cover") {
    return { id: `${slideId}.${id}`, type: "image", src, alt, fit };
}
export function imageWithCaptionPanel(slideId, imageSrc, imageTitle) {
    const image = { ...imageBlock(slideId, "brief-image", imageSrc, imageTitle, "contain"), caption: imageTitle };
    return {
        id: `${slideId}.visualPanel`,
        type: "stack",
        direction: "vertical",
        gap: 10,
        role: "image-with-caption",
        children: [
            { ...image, layoutWeight: 1, minHeight: 6.8 },
        ],
    };
}
export function metricCard(slideId, id, value, label) {
    return {
        id: `${slideId}.${id}`,
        type: "stack",
        direction: "vertical",
        gap: 6,
        role: "metric-card",
        fill: "surface",
        line: "divider",
        padding: 10,
        children: [
            { id: `${slideId}.${id}.value`, type: "text", text: value, style: "metric-value" },
            { id: `${slideId}.${id}.label`, type: "text", text: label, style: "metric-label" },
        ],
    };
}
export function stepCard(slideId, id, step, title, body) {
    return {
        id: `${slideId}.${id}`,
        type: "stack",
        direction: "vertical",
        gap: 8,
        role: "step-card",
        fill: "surface",
        line: "divider",
        padding: 10,
        children: [
            { id: `${slideId}.${id}.step`, type: "text", text: step, style: "label", color: "brand.primary", fixedHeight: 0.45 },
            { id: `${slideId}.${id}.title`, type: "text", text: title, style: "card-title", fixedHeight: 0.75 },
            { id: `${slideId}.${id}.body`, type: "text", text: body, style: "caption", valign: "top" },
        ],
    };
}
export function comparisonCard(slideId, id, title, points) {
    return {
        id: `${slideId}.${id}`,
        type: "stack",
        direction: "vertical",
        gap: 8,
        role: "comparison-card",
        fill: "surface",
        line: "divider",
        padding: 10,
        children: [
            { id: `${slideId}.${id}.title`, type: "text", text: title, style: "card-title", color: "brand.primary", fixedHeight: 0.7 },
            bulletList(slideId, `${id}-points`, points, "compact"),
        ],
    };
}
export function insightCallout(slideId, id, text) {
    return { id: `${slideId}.${id}`, type: "text", text, style: "callout", fill: "surface", line: "divider", fixedHeight: 1.15 };
}
export function companyOverviewLayout(options) {
    return {
        id: `${options.slideId}.overviewLayout`,
        type: "grid",
        area: "content",
        columns: 2,
        gap: 22,
        role: "company-overview-layout",
        children: [
            {
                id: `${options.slideId}.narrativeColumn`,
                type: "stack",
                direction: "vertical",
                gap: 12,
                children: [
                    paragraphText(options.slideId, "company-summary", options.summary),
                    bulletList(options.slideId, "business-lines", options.businessLines, "compact"),
                ],
            },
            {
                id: `${options.slideId}.visualColumn`,
                type: "stack",
                direction: "vertical",
                gap: 14,
                children: [
                    imageBlock(options.slideId, "hero-visual", options.visualSrc, "Company visual", "cover"),
                    {
                        id: `${options.slideId}.metricGrid`,
                        type: "grid",
                        columns: 3,
                        gap: 10,
                        children: options.metrics.map((metric) => metricCard(options.slideId, metric.name, metric.value, metric.label)),
                    },
                ],
            },
        ],
    };
}
