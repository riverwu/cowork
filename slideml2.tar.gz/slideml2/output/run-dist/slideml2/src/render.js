import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { emitPackage } from "../../slideml/src/emitter/package.js";
import { expandComponent } from "./component-registry.js";
import { inferTextKind } from "./text-normalizer.js";
import { sourceToRenderedDeck } from "./source-deck.js";
import { buildTheme, color, textStyle } from "./theme.js";
const EMU_PER_CM = 360000;
const PX_PER_CM = 40;
export async function renderToPptx(deck, outputPath) {
    const ast = renderToAst(deck);
    const buffer = await emitPackage(ast);
    await mkdir(dirname(outputPath), { recursive: true });
    await writeFile(outputPath, buffer);
    const domPath = `${outputPath}.render-tree.json`;
    await writeFile(domPath, JSON.stringify(materializeDeck(deck), null, 2), "utf8");
    return { outputPath, domPath };
}
export async function renderSourceDeckToPptx(deck, outputPath) {
    return renderToPptx(sourceToRenderedDeck(deck), outputPath);
}
export function renderToAst(deck) {
    const theme = buildTheme(deck.deck.brand, deck.deck.theme);
    const slides = deck.slides.map((slide) => {
        const dom = materializeNode(slide.dom, slide.id, deck.deck.brand.logo || "");
        return {
            shapes: renderNode(theme, dom, fullRect(theme), { nextId: 2 }, slide.id, deck.deck.brand.logo || ""),
            background: { type: "solid", color: color(theme, dom.background, "background") },
            notes: typeof dom.notes === "string" ? dom.notes : undefined,
        };
    });
    return {
        size: "16x9",
        language: "zh-CN",
        title: "SlideML2 MVP",
        author: "SlideML2",
        slides,
    };
}
export function measureDeck(deck) {
    const theme = buildTheme(deck.deck.brand, deck.deck.theme);
    return deck.slides.map((slide) => {
        const dom = materializeNode(slide.dom, slide.id, deck.deck.brand.logo || "");
        const nodes = [];
        measureNode(theme, dom, fullRect(theme), nodes);
        return { slideId: slide.id, nodes };
    });
}
function materializeDeck(deck) {
    return {
        ...deck,
        slides: deck.slides.map((slide) => ({
            ...slide,
            dom: materializeNode(slide.dom, slide.id, deck.deck.brand.logo || ""),
        })),
    };
}
function renderNode(theme, node, rect, ids, slideId = "slide", logo = "") {
    if (node.type === "slide") {
        return (node.children || []).flatMap((child) => renderNode(theme, child, rectForNode(theme, child, rect), ids, slideId, logo));
    }
    if (node.type === "stack")
        return renderStack(theme, node, rect, ids, slideId, logo);
    if (node.type === "grid")
        return renderGrid(theme, node, rect, ids, slideId, logo);
    if (node.type === "spacer")
        return [];
    if (node.type === "divider")
        return [dividerShape(theme, node, rect, ids)];
    if (node.type === "text")
        return [textShape(theme, node, rect, ids)];
    if (node.type === "bullets")
        return [bulletsShape(theme, node, rect, ids)];
    if (node.type === "image")
        return captionedShapes(theme, node, rect, ids, (bodyRect) => imageShape(node, bodyRect, ids));
    if (node.type === "table")
        return captionedShapes(theme, node, rect, ids, (bodyRect) => [tableShape(theme, node, bodyRect, ids)]);
    if (node.type === "chart")
        return captionedShapes(theme, node, rect, ids, (bodyRect) => [chartShape(theme, node, bodyRect, ids)]);
    if (node.type === "shape")
        return [presetShape(theme, node, rect, ids)];
    return [];
}
function renderStack(theme, node, rect, ids, slideId, logo) {
    const children = node.children || [];
    if (children.length === 0)
        return [];
    return [
        ...containerBackgroundShape(theme, node, rect, ids),
        ...layoutStackChildren(theme, node, contentRect(theme, node, rect)).flatMap(({ node: child, rect: childRect }) => renderNode(theme, child, childRect, ids, slideId, logo)),
    ];
}
function renderGrid(theme, node, rect, ids, slideId, logo) {
    const children = node.children || [];
    if (children.length === 0)
        return [];
    const columns = Math.max(1, numberProp(node, "columns", 2));
    const gap = pxToCm(numberProp(node, "gap", theme.layout.defaultGap));
    const rows = Math.ceil(children.length / columns);
    return [
        ...containerBackgroundShape(theme, node, rect, ids),
        ...layoutGridChildren(theme, node, contentRect(theme, node, rect), columns, rows, gap).flatMap(({ node: child, rect: childRect }) => renderNode(theme, child, childRect, ids, slideId, logo)),
    ];
}
function textShape(theme, node, rect, ids) {
    const kind = textStyleKey(node);
    const style = textStyle(theme, kind, "paragraph");
    const runs = textRuns(theme, node, style);
    return {
        type: "text",
        id: ids.nextId++,
        name: nodeLabel(node),
        xfrm: xfrm(rect),
        valign: valignProp(node),
        paragraphs: [{
                align: alignProp(node),
                runs,
            }],
        margin: { l: cm(0.1), r: cm(0.1), t: cm(0.05), b: cm(0.05) },
        fill: typeof node.fill === "string" ? { type: "solid", color: color(theme, node.fill) } : undefined,
        line: typeof node.line === "string" ? { color: color(theme, node.line), width: cm(0.02) } : undefined,
        cornerRadius: typeof node.fill === "string" || typeof node.line === "string" ? 0.08 : undefined,
    };
}
function bulletsShape(theme, node, rect, ids) {
    const items = Array.isArray(node.items) ? node.items.map(String) : [];
    const style = textStyle(theme, node.density === "compact" ? "bullet-compact" : "bullet", "paragraph");
    const title = typeof node.title === "string" && node.title.trim() ? node.title.trim() : "";
    return {
        type: "text",
        id: ids.nextId++,
        name: nodeLabel(node),
        xfrm: xfrm(rect),
        paragraphs: [
            ...(title ? [{
                    runs: [{ text: title, sizeHalfPt: theme.text["card-title"].fontSize * 2, bold: true, color: color(theme, "brand.primary"), fontFace: containsCjk(title) ? theme.fonts.cjk : theme.fonts.latin, cjk: true }],
                    spaceAfterHalfPt: 6,
                }] : []),
            ...items.map((item) => ({
                bullet: { auto: true },
                runs: [{ text: item, sizeHalfPt: style.fontSize * 2, color: color(theme, node.color, style.color), fontFace: containsCjk(item) ? theme.fonts.cjk : theme.fonts.latin, cjk: true }],
                spaceAfterHalfPt: node.density === "compact" ? 4 : 10,
            })),
        ],
        margin: { l: cm(0.2), r: cm(0.1), t: cm(0.08), b: cm(0.08) },
    };
}
function presetShape(theme, node, rect, ids) {
    const preset = node.preset === "line" ? "line" : node.preset === "ellipse" ? "ellipse" : node.preset === "roundRect" ? "roundRect" : "rect";
    return {
        type: "shape",
        id: ids.nextId++,
        name: nodeLabel(node),
        preset,
        xfrm: xfrm(rect),
        fill: typeof node.fill === "string" ? { type: "solid", color: color(theme, node.fill) } : { type: "none" },
        line: typeof node.line === "string" ? { color: color(theme, node.line), width: cm(0.02) } : undefined,
    };
}
function dividerShape(theme, node, rect, ids) {
    const orientation = node.orientation === "horizontal" || node.orientation === "vertical"
        ? node.orientation
        : rect.w >= rect.h ? "horizontal" : "vertical";
    const thickness = pxToCm(numberProp(node, "thickness", 1));
    const lineRect = orientation === "horizontal"
        ? { x: rect.x, y: rect.y + rect.h / 2, w: rect.w, h: Math.max(0.01, thickness) }
        : { x: rect.x + rect.w / 2, y: rect.y, w: Math.max(0.01, thickness), h: rect.h };
    return {
        type: "shape",
        id: ids.nextId++,
        name: nodeLabel(node),
        preset: "line",
        xfrm: xfrm(lineRect),
        fill: { type: "none" },
        line: { color: color(theme, node.line, "divider"), width: cm(Math.max(0.01, thickness)) },
    };
}
function tableShape(theme, node, rect, ids) {
    const headers = Array.isArray(node.headers) ? node.headers.map(String) : [];
    const rows = Array.isArray(node.rows) ? node.rows.map((row) => Array.isArray(row) ? row.map(String) : []) : [];
    const allRows = headers.length > 0 ? [headers, ...rows] : rows;
    const colCount = Math.max(1, ...allRows.map((row) => row.length));
    const rowCount = Math.max(1, allRows.length);
    const colWidths = Array.from({ length: colCount }, () => cm(rect.w / colCount));
    const rowHeights = Array.from({ length: rowCount }, () => cm(rect.h / rowCount));
    const cells = allRows.map((row, rowIndex) => Array.from({ length: colCount }, (_, colIndex) => {
        const text = row[colIndex] || "";
        const kind = rowIndex === 0 && headers.length > 0 ? "table-header" : "table-cell";
        const style = textStyle(theme, kind, "table-cell");
        return {
            runs: [{ text, sizeHalfPt: style.fontSize * 2, bold: style.weight === "bold", color: color(theme, undefined, style.color), fontFace: containsCjk(text) ? theme.fonts.cjk : theme.fonts.latin, cjk: true }],
            fill: rowIndex === 0 && headers.length > 0 ? { type: "solid", color: color(theme, "surface.subtle") } : undefined,
            align: rowIndex === 0 && headers.length > 0 ? "center" : "left",
            valign: "middle",
        };
    }));
    return {
        type: "table",
        id: ids.nextId++,
        name: nodeLabel(node),
        xfrm: xfrm(rect),
        colWidths,
        rowHeights,
        cells,
        firstRowHeader: headers.length > 0,
        borderColor: color(theme, "divider"),
        borderWidth: cm(0.01),
    };
}
function chartShape(theme, node, rect, ids) {
    const labels = Array.isArray(node.labels) ? node.labels.map(String) : [];
    const series = normalizeChartSeries(node.series);
    return {
        type: "chart",
        id: ids.nextId++,
        name: nodeLabel(node),
        xfrm: xfrm(rect),
        chartType: chartType(node.chartType),
        labels,
        series,
        colors: [color(theme, "brand.primary"), "60A5FA", "94A3B8"],
        showLegend: series.length > 1,
        showValues: Boolean(node.showValues),
        title: typeof node.title === "string" ? node.title : undefined,
    };
}
function imageShape(node, rect, ids) {
    const src = stringProp(node, "src", "");
    if (!src)
        return [];
    return [{
            type: "image",
            id: ids.nextId++,
            name: nodeLabel(node),
            xfrm: xfrm(rect),
            src,
            altText: stringProp(node, "alt", nodeLabel(node)),
            fit: node.fit === "cover" || node.fit === "fill" ? node.fit : "contain",
        }];
}
function captionedShapes(theme, node, rect, ids, renderBody) {
    const caption = typeof node.caption === "string" && node.caption.trim() ? node.caption.trim() : "";
    if (!caption)
        return renderBody(rect);
    const { bodyRect, captionRect } = captionLayout(rect);
    return [
        ...renderBody(bodyRect),
        textShape(theme, {
            id: `${node.id}.caption`,
            type: "text",
            text: caption,
            style: "figure-caption",
            align: "center",
        }, captionRect, ids),
    ];
}
function captionLayout(rect) {
    const captionHeight = Math.min(0.72, Math.max(0.48, rect.h * 0.14));
    const gap = 0.1;
    const bodyRect = { ...rect, h: Math.max(0.2, rect.h - captionHeight - gap) };
    return {
        bodyRect,
        captionRect: { x: rect.x, y: bodyRect.y + bodyRect.h + gap, w: rect.w, h: captionHeight },
    };
}
function textRuns(theme, node, style) {
    const content = node.content;
    if (Array.isArray(content)) {
        return content.map((raw) => {
            const record = raw && typeof raw === "object" ? raw : {};
            const text = typeof record.text === "string" ? record.text : "";
            const marks = Array.isArray(record.marks) ? record.marks.map(String) : [];
            return {
                text,
                sizeHalfPt: style.fontSize * 2,
                bold: style.weight === "bold" || marks.includes("bold") || marks.includes("emphasis"),
                italic: marks.includes("italic"),
                underline: marks.includes("underline"),
                color: color(theme, record.color, style.color),
                fontFace: marks.includes("code") ? theme.fonts.mono : containsCjk(text) ? theme.fonts.cjk : theme.fonts.latin,
                cjk: true,
                mono: marks.includes("code"),
                hyperlink: typeof record.link === "string" ? record.link : undefined,
                breakLine: record.breakLine === true,
            };
        });
    }
    const text = stringProp(node, "text", typeof content === "string" ? content : "");
    return [{
            text,
            sizeHalfPt: style.fontSize * 2,
            bold: style.weight === "bold",
            color: color(theme, node.color, style.color),
            fontFace: containsCjk(text) ? theme.fonts.cjk : theme.fonts.latin,
            cjk: true,
            mono: textStyleKey(node) === "code",
        }];
}
function rectForNode(theme, node, parent) {
    const area = stringProp(node, "area", "");
    if (node.type === "text" && textStyleKey(node) === "slide-title")
        return { x: theme.layout.pageMarginX, y: theme.layout.titleTop, w: theme.layout.slideWidthCm - theme.layout.pageMarginX * 2, h: theme.layout.titleHeight };
    if (node.type === "image" && node.position === "bottom-right") {
        const w = pxToCm(numberProp(node, "width", 96));
        const h = pxToCm(numberProp(node, "height", 40));
        return { x: theme.layout.slideWidthCm - w - 0.7, y: theme.layout.slideHeightCm - h - 0.55, w, h };
    }
    if (node.type === "image" && node.position === "top-right") {
        const w = pxToCm(numberProp(node, "width", 96));
        const h = pxToCm(numberProp(node, "height", 40));
        return { x: theme.layout.slideWidthCm - w - 0.7, y: 0.55, w, h };
    }
    if (area === "content")
        return { x: theme.layout.pageMarginX, y: theme.layout.contentTop, w: theme.layout.slideWidthCm - theme.layout.pageMarginX * 2, h: theme.layout.slideHeightCm - theme.layout.contentTop - theme.layout.contentBottom };
    return parent;
}
function measureNode(theme, node, rect, output) {
    const ownRect = rectForNode(theme, node, rect);
    const caption = typeof node.caption === "string" && node.caption.trim() ? node.caption.trim() : "";
    if (caption && (node.type === "image" || node.type === "table" || node.type === "chart")) {
        const { bodyRect, captionRect } = captionLayout(ownRect);
        output.push({ id: node.id, type: node.type, rect: bodyRect });
        output.push({ id: `${node.id}.caption`, type: "text", rect: captionRect });
        return;
    }
    output.push({ id: node.id, type: node.type, rect: ownRect });
    if (node.type === "slide") {
        for (const child of node.children || [])
            measureNode(theme, child, ownRect, output);
        return;
    }
    if (node.type === "stack") {
        measureStack(theme, node, ownRect, output);
        return;
    }
    if (node.type === "grid") {
        measureGrid(theme, node, ownRect, output);
    }
}
function materializeNode(node, slideId, logo) {
    const expanded = node.type === "component" ? expandComponent(slideId, node, logo) : node;
    return {
        ...expanded,
        children: expanded.children?.map((child) => materializeNode(child, slideId, logo)),
    };
}
function measureStack(theme, node, rect, output) {
    layoutStackChildren(theme, node, contentRect(theme, node, rect)).forEach(({ node: child, rect: childRect }) => measureNode(theme, child, childRect, output));
}
function measureGrid(theme, node, rect, output) {
    const children = node.children || [];
    if (children.length === 0)
        return;
    const columns = Math.max(1, numberProp(node, "columns", 2));
    const rows = Math.ceil(children.length / columns);
    const gap = pxToCm(numberProp(node, "gap", theme.layout.defaultGap));
    layoutGridChildren(theme, node, contentRect(theme, node, rect), columns, rows, gap).forEach(({ node: child, rect: childRect }) => measureNode(theme, child, childRect, output));
}
function containerBackgroundShape(theme, node, rect, ids) {
    const style = componentStyle(theme, node);
    const fillToken = typeof node.fill === "string" ? node.fill : style.fill;
    const lineToken = typeof node.line === "string" ? node.line : style.line;
    if (!fillToken && !lineToken)
        return [];
    return [{
            type: "shape",
            id: ids.nextId++,
            name: `${nodeLabel(node)}-background`,
            preset: "roundRect",
            xfrm: xfrm(rect),
            fill: fillToken ? { type: "solid", color: color(theme, fillToken) } : { type: "none" },
            line: lineToken ? { color: color(theme, lineToken), width: cm(0.02) } : undefined,
            cornerRadius: 0.08,
        }];
}
function contentRect(theme, node, rect) {
    const style = componentStyle(theme, node);
    const pad = pxToCm(numberProp(node, "padding", style.padding ?? 0));
    if (pad <= 0)
        return rect;
    return {
        x: rect.x + pad,
        y: rect.y + pad,
        w: Math.max(0, rect.w - pad * 2),
        h: Math.max(0, rect.h - pad * 2),
    };
}
function layoutStackChildren(theme, node, rect) {
    const children = node.children || [];
    if (children.length === 0)
        return [];
    const gap = gapCm(theme, node);
    const direction = node.direction === "horizontal" ? "horizontal" : "vertical";
    const mainSize = direction === "horizontal" ? rect.w : rect.h;
    const crossSize = direction === "horizontal" ? rect.h : rect.w;
    const availableMain = Math.max(0, mainSize - gap * (children.length - 1));
    const childSizes = resolveMainSizes(theme, children, direction, availableMain, crossSize);
    let cursor = direction === "horizontal" ? rect.x : rect.y;
    return children.map((child, index) => {
        const size = childSizes[index];
        const childRect = direction === "horizontal"
            ? { x: cursor, y: rect.y, w: size, h: rect.h }
            : { x: rect.x, y: cursor, w: rect.w, h: size };
        cursor += size + gap;
        return { node: child, rect: childRect };
    });
}
function layoutGridChildren(theme, node, rect, columns, rows, gap) {
    const children = node.children || [];
    const availableWidth = Math.max(0, rect.w - gap * (columns - 1));
    const availableHeight = Math.max(0, rect.h - gap * (rows - 1));
    const columnWeights = weightsFromProp(node.columnWeights, columns);
    const colX = positions(rect.x, availableWidth, gap, columnWeights);
    const rowHeights = resolveGridRowHeights(theme, children, columns, rows, availableHeight, colX.map((col) => col.size), node.rowWeights);
    const rowY = positionsFromSizes(rect.y, gap, rowHeights);
    return children.map((child, index) => {
        const col = index % columns;
        const row = Math.floor(index / columns);
        return { node: child, rect: { x: colX[col].start, y: rowY[row].start, w: colX[col].size, h: rowY[row].size } };
    });
}
function resolveMainSizes(theme, children, direction, availableMain, crossSize) {
    return solveSizes(children.map((child) => childMainSpec(theme, child, direction, crossSize)), availableMain);
}
function childMainSpec(theme, node, direction, crossSize) {
    const fixed = optionalNumberProp(node, direction === "horizontal" ? "fixedWidth" : "fixedHeight");
    const intrinsic = intrinsicMainSize(theme, node, direction, crossSize);
    const min = optionalNumberProp(node, direction === "horizontal" ? "minWidth" : "minHeight") ?? intrinsicMinSize(theme, node, direction, crossSize);
    const max = optionalNumberProp(node, direction === "horizontal" ? "maxWidth" : "maxHeight") ?? Number.POSITIVE_INFINITY;
    const hasExplicitWeight = optionalNumberProp(node, "layoutWeight") !== undefined;
    const fixedSize = fixed === undefined ? undefined : Math.max(0, fixed);
    return {
        basis: fixedSize ?? clamp(intrinsic, min, max),
        min: fixedSize ?? Math.max(0, min),
        max: fixedSize ?? Math.max(min, max),
        weight: Math.max(0.0001, numberProp(node, "layoutWeight", node.type === "image" ? 2 : 1)),
        grow: fixed === undefined && (hasExplicitWeight || canGrow(node)),
        fixed: fixed !== undefined,
    };
}
function solveSizes(specs, availableMain) {
    if (specs.length === 0)
        return [];
    const available = Math.max(0, availableMain);
    const sizes = specs.map((spec) => clamp(spec.basis, spec.min, spec.max));
    const total = sizes.reduce((sum, size) => sum + size, 0);
    if (total > available)
        return shrinkSizes(specs, sizes, available);
    if (total < available)
        return growSizes(specs, sizes, available - total);
    return sizes;
}
function shrinkSizes(specs, sizes, available) {
    let overflow = sizes.reduce((sum, size) => sum + size, 0) - available;
    const shrinkable = specs.map((spec, index) => ({ spec, index })).filter(({ spec, index }) => !spec.fixed && sizes[index] > spec.min);
    while (overflow > 0.0001 && shrinkable.some(({ spec, index }) => sizes[index] > spec.min + 0.0001)) {
        const capacities = shrinkable.map(({ spec, index }) => Math.max(0, sizes[index] - spec.min));
        const totalCapacity = capacities.reduce((sum, capacity) => sum + capacity, 0);
        if (totalCapacity <= 0)
            break;
        shrinkable.forEach(({ spec, index }, listIndex) => {
            const reduction = Math.min(sizes[index] - spec.min, overflow * (capacities[listIndex] / totalCapacity));
            sizes[index] -= reduction;
        });
        overflow = sizes.reduce((sum, size) => sum + size, 0) - available;
    }
    if (overflow > 0.0001)
        return fitToAvailable(sizes, available);
    return sizes;
}
function growSizes(specs, sizes, extra) {
    let remaining = extra;
    let growIndexes = specs.map((spec, index) => spec.grow && sizes[index] < spec.max ? index : -1).filter((index) => index >= 0);
    while (remaining > 0.0001 && growIndexes.length > 0) {
        const weights = normalizeWeights(growIndexes.map((index) => specs[index].weight));
        let consumed = 0;
        growIndexes.forEach((index, weightIndex) => {
            const room = specs[index].max - sizes[index];
            const addition = Math.min(room, remaining * weights[weightIndex]);
            sizes[index] += addition;
            consumed += addition;
        });
        if (consumed <= 0.0001)
            break;
        remaining -= consumed;
        growIndexes = growIndexes.filter((index) => sizes[index] < specs[index].max - 0.0001);
    }
    return sizes;
}
function intrinsicMainSize(theme, node, direction, crossSize) {
    const fixed = optionalNumberProp(node, direction === "horizontal" ? "fixedWidth" : "fixedHeight");
    if (fixed !== undefined)
        return fixed;
    if (direction === "horizontal") {
        if (node.type === "image")
            return Math.min(12, Math.max(6, crossSize * 0.9));
        if (node.type === "text")
            return textIntrinsicWidth(theme, node);
        if (node.type === "divider")
            return pxToCm(numberProp(node, "thickness", 1)) + 0.02;
        if (node.type === "stack" && node.direction === "horizontal")
            return horizontalStackIntrinsicWidth(theme, node, crossSize);
        return 3.2;
    }
    if (node.type === "text")
        return textIntrinsicHeight(theme, node, crossSize);
    if (node.type === "bullets")
        return bulletsIntrinsicHeight(theme, node, crossSize);
    if (node.type === "spacer")
        return direction === "vertical" ? 0.4 : 0.6;
    if (node.type === "divider")
        return pxToCm(numberProp(node, "thickness", 1)) + 0.02;
    if (node.type === "image")
        return Math.min(10, Math.max(4, crossSize * 0.62));
    if (node.type === "stack")
        return stackIntrinsicHeight(theme, node, crossSize);
    if (node.type === "grid")
        return gridIntrinsicHeight(theme, node, crossSize);
    return 2;
}
function intrinsicMinSize(theme, node, direction, crossSize) {
    const explicit = optionalNumberProp(node, direction === "horizontal" ? "minWidth" : "minHeight");
    if (explicit !== undefined)
        return explicit;
    if (direction === "horizontal")
        return Math.min(intrinsicMainSize(theme, node, direction, crossSize), node.type === "divider" ? 0.02 : 0.45);
    if (node.type === "text")
        return singleLineTextHeight(theme, node);
    if (node.type === "bullets")
        return 0.8;
    if (node.type === "divider")
        return pxToCm(numberProp(node, "thickness", 1)) + 0.02;
    if (node.type === "spacer")
        return 0;
    return Math.min(intrinsicMainSize(theme, node, direction, crossSize), 0.9);
}
function canGrow(node) {
    return node.type === "image" || node.type === "grid" || node.type === "stack" || node.type === "table" || node.type === "chart" || node.type === "shape" || node.type === "spacer" || node.fill === true;
}
function stackIntrinsicHeight(theme, node, crossSize) {
    const children = node.children || [];
    if (children.length === 0)
        return 0;
    const gap = gapCm(theme, node);
    const pad = paddingCm(theme, node);
    const innerWidth = Math.max(0, crossSize - pad * 2);
    if (node.direction === "horizontal") {
        const availableWidth = Math.max(0, innerWidth - gap * Math.max(0, children.length - 1));
        const widths = resolveMainSizes(theme, children, "horizontal", availableWidth, 10);
        const childHeights = children.map((child, index) => intrinsicMainSize(theme, child, "vertical", widths[index] || innerWidth));
        return Math.max(0, ...childHeights) + pad * 2;
    }
    const fixed = children.reduce((sum, child) => sum + intrinsicMainSize(theme, child, "vertical", innerWidth), 0);
    return fixed + gap * Math.max(0, children.length - 1) + pad * 2;
}
function horizontalStackIntrinsicWidth(theme, node, heightCm) {
    const children = node.children || [];
    if (children.length === 0)
        return 0;
    const gap = gapCm(theme, node);
    const pad = paddingCm(theme, node);
    return children.reduce((sum, child) => sum + intrinsicMainSize(theme, child, "horizontal", heightCm), 0) + gap * Math.max(0, children.length - 1) + pad * 2;
}
function gridIntrinsicHeight(theme, node, widthCm) {
    const children = node.children || [];
    if (children.length === 0)
        return 0;
    const columns = Math.max(1, numberProp(node, "columns", 2));
    const rows = Math.ceil(children.length / columns);
    const gap = gapCm(theme, node);
    const columnWeights = weightsFromProp(node.columnWeights, columns);
    const contentWidth = contentRect(theme, node, { x: 0, y: 0, w: widthCm, h: 10 }).w;
    const availableWidth = Math.max(0, contentWidth - gap * (columns - 1));
    const colWidths = columnWeights.map((weight) => availableWidth * weight);
    let total = 0;
    for (let row = 0; row < rows; row++) {
        let rowHeight = 0;
        for (let col = 0; col < columns; col++) {
            const child = children[row * columns + col];
            if (!child)
                continue;
            rowHeight = Math.max(rowHeight, intrinsicMainSize(theme, child, "vertical", colWidths[col] || availableWidth / columns));
        }
        total += rowHeight;
    }
    return total + gap * Math.max(0, rows - 1);
}
function resolveGridRowHeights(theme, children, columns, rows, availableHeight, colWidths, rowWeightsValue) {
    const rowWeights = weightsFromProp(rowWeightsValue, rows);
    const specs = [];
    for (let row = 0; row < rows; row++) {
        let basis = 0;
        let min = 0.4;
        for (let col = 0; col < columns; col++) {
            const child = children[row * columns + col];
            if (!child)
                continue;
            const width = colWidths[col] || colWidths[0] || 1;
            basis = Math.max(basis, intrinsicMainSize(theme, child, "vertical", width));
            min = Math.max(min, intrinsicMinSize(theme, child, "vertical", width));
        }
        specs.push({ basis, min, max: Number.POSITIVE_INFINITY, weight: rowWeights[row] || 1, grow: true, fixed: false });
    }
    return solveSizes(specs, availableHeight);
}
function textIntrinsicHeight(theme, node, widthCm) {
    const style = textStyle(theme, textStyleKey(node), "paragraph");
    const fontPt = style.fontSize;
    const text = stringProp(node, "text", typeof node.content === "string" ? node.content : "");
    const charWidthCm = fontPt * 0.018;
    const charsPerLine = Math.max(8, Math.floor(widthCm / charWidthCm));
    const lines = Math.max(1, Math.ceil(weightedTextLength(text) / charsPerLine));
    const boxPadding = typeof node.fill === "string" || typeof node.line === "string" ? 0.28 : 0.18;
    return Math.min(8, Math.max(fontPt * 0.0353 * style.lineHeight + boxPadding, lines * fontPt * 0.0353 * style.lineHeight + boxPadding));
}
function componentStyle(theme, node) {
    return typeof node.role === "string" ? theme.component[node.role] || {} : {};
}
function gapCm(theme, node) {
    return pxToCm(numberProp(node, "gap", theme.layout.defaultGap));
}
function paddingCm(theme, node) {
    const style = componentStyle(theme, node);
    return pxToCm(numberProp(node, "padding", style.padding ?? 0));
}
function textIntrinsicWidth(theme, node) {
    const style = textStyle(theme, textStyleKey(node), "paragraph");
    const text = stringProp(node, "text", typeof node.content === "string" ? node.content : "");
    const weighted = weightedTextLength(text.replace(/\n/g, " "));
    const width = weighted * style.fontSize * 0.018 + 0.35;
    return Math.min(8, Math.max(0.45, width));
}
function bulletsIntrinsicHeight(theme, node, widthCm) {
    const items = Array.isArray(node.items) ? node.items.map(String) : [""];
    const style = textStyle(theme, node.density === "compact" ? "bullet-compact" : "bullet", "paragraph");
    const charWidthCm = style.fontSize * 0.0175;
    const charsPerLine = Math.max(8, Math.floor(widthCm / charWidthCm));
    const lineCount = items.reduce((sum, item) => sum + Math.max(1, Math.ceil(weightedTextLength(item) / charsPerLine)), 0);
    const lineHeight = style.fontSize * 0.0353 * style.lineHeight;
    const paragraphGap = node.density === "compact" ? 0.12 : 0.2;
    const titleHeight = typeof node.title === "string" && node.title.trim() ? 0.62 : 0;
    return Math.max(1.05, titleHeight + lineCount * lineHeight + Math.max(0, items.length - 1) * paragraphGap + 0.35);
}
function singleLineTextHeight(theme, node) {
    const style = textStyle(theme, textStyleKey(node), "paragraph");
    return style.fontSize * 0.0353 * style.lineHeight + 0.16;
}
function textStyleKey(node) {
    if (typeof node.style === "string" && node.style.trim())
        return node.style;
    return inferTextKind(node).kind;
}
function nodeLabel(node) {
    return node.id;
}
function weightedTextLength(text) {
    let length = 0;
    for (const char of text)
        length += /[\u4e00-\u9fff]/.test(char) ? 1.05 : 0.58;
    return length;
}
function fitToAvailable(sizes, availableMain) {
    const total = sizes.reduce((sum, size) => sum + size, 0);
    if (total <= 0)
        return sizes.map(() => availableMain / sizes.length);
    if (total <= availableMain)
        return sizes;
    const scale = availableMain / total;
    return sizes.map((size) => size * scale);
}
function weightsFromProp(value, count) {
    if (Array.isArray(value) && value.length === count) {
        return normalizeWeights(value.map((item) => typeof item === "number" && Number.isFinite(item) && item > 0 ? item : 1));
    }
    return normalizeWeights(Array.from({ length: count }, () => 1));
}
function normalizeWeights(values) {
    const total = values.reduce((sum, value) => sum + Math.max(value, 0), 0);
    if (total <= 0)
        return values.map(() => 1 / values.length);
    return values.map((value) => Math.max(value, 0) / total);
}
function positions(start, availableSize, gap, weights) {
    let cursor = start;
    return weights.map((weight) => {
        const size = availableSize * weight;
        const item = { start: cursor, size };
        cursor += size + gap;
        return item;
    });
}
function positionsFromSizes(start, gap, sizes) {
    let cursor = start;
    return sizes.map((size) => {
        const item = { start: cursor, size };
        cursor += size + gap;
        return item;
    });
}
function fullRect(theme) {
    return { x: 0, y: 0, w: theme.layout.slideWidthCm, h: theme.layout.slideHeightCm };
}
function xfrm(rect) {
    return { x: cm(rect.x), y: cm(rect.y), cx: cm(rect.w), cy: cm(rect.h) };
}
function cm(value) {
    return Math.round(value * EMU_PER_CM);
}
function pxToCm(value) {
    return value / PX_PER_CM;
}
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
function stringProp(node, key, fallback) {
    const value = node[key];
    return typeof value === "string" ? value : fallback;
}
function numberProp(node, key, fallback) {
    const value = node[key];
    return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function optionalNumberProp(node, key) {
    const value = node[key];
    return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}
function alignProp(node) {
    return node.align === "center" || node.align === "right" ? node.align : "left";
}
function valignProp(node) {
    return node.valign === "top" || node.valign === "bottom" ? node.valign : "middle";
}
function containsCjk(text) {
    return /[\u4e00-\u9fff]/.test(text);
}
function chartType(value) {
    if (value === "line" || value === "pie" || value === "doughnut" || value === "area")
        return value;
    return "bar";
}
function normalizeChartSeries(value) {
    if (!Array.isArray(value))
        return [];
    const output = [];
    value.forEach((item, index) => {
        if (!item || typeof item !== "object")
            return null;
        const record = item;
        const values = Array.isArray(record.values) ? record.values.map((v) => Number(v)).filter(Number.isFinite) : [];
        if (values.length > 0)
            output.push({ name: typeof record.name === "string" ? record.name : `Series ${index + 1}`, values });
    });
    return output;
}
