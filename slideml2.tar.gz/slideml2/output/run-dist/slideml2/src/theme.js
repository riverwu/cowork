export function buildTheme(brand = {}, themeName = "default") {
    const brandPrimary = normalizeHex(brand.primary || "2563EB");
    const base = baseTheme(themeName, brandPrimary);
    return {
        ...base,
        colors: {
            ...base.colors,
            "brand.primary": brandPrimary,
        },
    };
}
export function listThemes() {
    return ["default", "enterprise-light", "technical-blue"];
}
export function textStyle(theme, kindOrVariant, fallback = "paragraph") {
    const key = typeof kindOrVariant === "string" && kindOrVariant.trim() ? kindOrVariant.trim() : fallback;
    return theme.text[key] || theme.text[fallback] || theme.text.paragraph;
}
export function color(theme, value, fallback = "text.primary") {
    const raw = typeof value === "string" && value.trim() ? value.trim() : fallback;
    if (/^[0-9A-Fa-f]{6}$/.test(raw))
        return raw.toUpperCase();
    return theme.colors[raw] || theme.colors[fallback] || "111827";
}
function baseTheme(themeName, brandPrimary) {
    const common = commonText();
    const base = {
        name: themeName === "simple" ? "default" : themeName,
        colors: {
            "brand.primary": brandPrimary,
            background: "FFFFFF",
            surface: "F8FAFC",
            "surface.subtle": "F1F5F9",
            "brand.tint": "EFF6FF",
            "text.primary": "111827",
            "text.inverse": "FFFFFF",
            "text.muted": "64748B",
            divider: "E2E8F0",
            success: "15803D",
            "success.tint": "ECFDF3",
            warning: "B45309",
            "warning.tint": "FFFBEB",
            danger: "B91C1C",
            "danger.tint": "FEF2F2",
        },
        text: common,
        component: {
            "metric-card": { fill: "surface", line: "divider", padding: 8, radius: 0.06 },
            callout: { fill: "brand.tint", line: "divider", accent: "brand.primary", padding: 8, radius: 0.06 },
            "comparison-card": { fill: "surface", line: "divider", padding: 8, radius: 0.06 },
            "step-card": { fill: "surface", line: "divider", padding: 8, radius: 0.06 },
            "quote-card": { fill: "surface", line: "divider", accent: "brand.primary", padding: 12, radius: 0.08 },
            "definition-card": { fill: "surface", line: "divider", padding: 10, radius: 0.08 },
            "table-card": { fill: "surface", line: "divider", padding: 10, radius: 0.08 },
            "chart-card": { fill: "surface", line: "divider", padding: 10, radius: 0.08 },
            "code-card": { fill: "surface.subtle", line: "divider", padding: 10, radius: 0.08 },
        },
        tone: {
            neutral: { fg: "text.primary", bg: "surface", line: "divider" },
            positive: { fg: "success", bg: "success.tint", line: "success" },
            warning: { fg: "warning", bg: "warning.tint", line: "warning" },
            danger: { fg: "danger", bg: "danger.tint", line: "danger" },
            brand: { fg: "brand.primary", bg: "brand.tint", line: "brand.primary" },
        },
        fonts: {
            latin: "Aptos",
            cjk: "PingFang SC",
            mono: "Menlo",
        },
        fontFace: "Aptos",
        layout: {
            slideWidthCm: 25.4,
            slideHeightCm: 14.2875,
            pageMarginX: 1.4,
            titleTop: 0.58,
            titleHeight: 0.98,
            contentTop: 2.0,
            contentBottom: 0.78,
            defaultGap: 9,
            columnGap: 16,
            cardPadding: 8,
        },
        chrome: {
            brandMark: "none",
            pageNumber: false,
            footerLine: false,
        },
    };
    if (themeName === "enterprise-light") {
        return {
            ...base,
            colors: {
                ...base.colors,
                background: "FFFFFF",
                surface: "F8FAFC",
                "surface.subtle": "F1F5F9",
                "brand.tint": "EEF4FF",
                "text.primary": "0F172A",
                "text.muted": "64748B",
                divider: "CBD5E1",
            },
            layout: { ...base.layout, pageMarginX: 1.4, contentTop: 2.0, defaultGap: 9, columnGap: 16, cardPadding: 8 },
            chrome: { brandMark: "bottom-right", pageNumber: true, footerLine: true },
        };
    }
    if (themeName === "technical-blue") {
        return {
            ...base,
            colors: {
                ...base.colors,
                background: "F7FBFF",
                surface: "FFFFFF",
                "surface.subtle": "EAF3FF",
                "brand.tint": "E0F2FE",
                "text.primary": "102033",
                "text.muted": "52677F",
                divider: "B9D7F3",
            },
            text: {
                ...common,
                "slide-title": { ...common["slide-title"], color: "brand.primary" },
                "metric-value": { ...common["metric-value"], fontSize: 30 },
                code: { fontSize: 10.5, color: "text.primary", lineHeight: 1.18 },
            },
            layout: { ...base.layout, pageMarginX: 1.4, contentTop: 2.0, defaultGap: 9, columnGap: 16 },
            chrome: { brandMark: "bottom-right", pageNumber: true, footerLine: true },
        };
    }
    return base;
}
function commonText() {
    return {
        "deck-title": { fontSize: 42, weight: "bold", color: "text.inverse", lineHeight: 1.08 },
        "slide-title": { fontSize: 27, weight: "bold", color: "text.primary", lineHeight: 1.1 },
        "section-title": { fontSize: 21, weight: "bold", color: "text.primary", lineHeight: 1.12 },
        "card-title": { fontSize: 13, weight: "bold", color: "text.primary", lineHeight: 1.14 },
        label: { fontSize: 9, color: "text.muted", lineHeight: 1.1 },
        lead: { fontSize: 15, color: "text.primary", lineHeight: 1.26 },
        paragraph: { fontSize: 12.8, color: "text.primary", lineHeight: 1.26 },
        article: { fontSize: 12.5, color: "text.primary", lineHeight: 1.34 },
        caption: { fontSize: 8.8, color: "text.muted", lineHeight: 1.16 },
        "figure-caption": { fontSize: 9.5, color: "text.muted", lineHeight: 1.22 },
        footnote: { fontSize: 8.5, color: "text.muted", lineHeight: 1.16 },
        bullet: { fontSize: 12.8, color: "text.primary", lineHeight: 1.22 },
        "bullet-compact": { fontSize: 11.5, color: "text.primary", lineHeight: 1.14 },
        "numbered-step": { fontSize: 9, weight: "bold", color: "brand.primary", lineHeight: 1.0 },
        "metric-value": { fontSize: 24, weight: "bold", color: "brand.primary", lineHeight: 1.0 },
        "metric-label": { fontSize: 8.8, color: "text.muted", lineHeight: 1.12 },
        "table-header": { fontSize: 10.5, weight: "bold", color: "text.primary", lineHeight: 1.12 },
        "table-cell": { fontSize: 10, color: "text.primary", lineHeight: 1.18 },
        "axis-label": { fontSize: 8.5, color: "text.muted", lineHeight: 1.0 },
        "legend-label": { fontSize: 9, color: "text.muted", lineHeight: 1.0 },
        callout: { fontSize: 14.5, color: "brand.primary", lineHeight: 1.18 },
        quote: { fontSize: 18, color: "text.primary", lineHeight: 1.3 },
        "quote-source": { fontSize: 10, color: "text.muted", lineHeight: 1.15 },
        badge: { fontSize: 9, weight: "bold", color: "brand.primary", lineHeight: 1.0 },
        tag: { fontSize: 9, color: "text.muted", lineHeight: 1.0 },
        code: { fontSize: 10.5, color: "text.primary", lineHeight: 1.18 },
        "code-caption": { fontSize: 9, color: "text.muted", lineHeight: 1.15 },
        hero: { fontSize: 42, weight: "bold", color: "text.inverse", lineHeight: 1.08 },
        title: { fontSize: 30, weight: "bold", color: "text.primary", lineHeight: 1.12 },
        body: { fontSize: 18, color: "text.primary", lineHeight: 1.3 },
    };
}
function normalizeHex(value) {
    const cleaned = value.replace(/^#/, "");
    return /^[0-9A-Fa-f]{6}$/.test(cleaned) ? cleaned.toUpperCase() : "2563EB";
}
