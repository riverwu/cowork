export function buildDom(source) {
    return {
        deck: {
            size: source.deck.size || "16x9",
            theme: source.deck.theme || "simple",
            brand: source.deck.brand || {},
        },
        slides: source.slides.map((slide) => ({
            id: slide.id,
            layout: slide.layout,
            dom: renderLayout(slide, source.deck.brand || {}),
        })),
    };
}
function renderLayout(slide, brand) {
    if (slide.layout === "cover")
        return cover(slide, brand || {});
    if (slide.layout === "title-and-content")
        return titleAndContent(slide, brand || {});
    if (slide.layout === "image-and-text")
        return imageAndText(slide, brand || {});
    throw new Error(`Unknown layout: ${slide.layout}`);
}
function baseSlide(slide, children, overrides = {}) {
    return {
        id: `${slide.id}.root`,
        type: "slide",
        background: "background",
        ...overrides,
        children,
    };
}
function cover(slide, brand) {
    const title = stringProp(slide, "title", "Untitled");
    const subtitle = stringProp(slide, "subtitle", "");
    const children = [
        {
            id: `${slide.id}.hero`,
            type: "stack",
            area: "content",
            direction: "vertical",
            gap: 16,
            align: "center",
            children: [
                {
                    id: `${slide.id}.title`,
                    type: "text",
                    text: title,
                    style: "hero",
                    align: "center",
                    color: "text.inverse",
                },
                {
                    id: `${slide.id}.subtitle`,
                    type: "text",
                    text: subtitle,
                    style: "body",
                    align: "center",
                    color: "text.inverse",
                },
            ],
        },
    ];
    if (brand.logo)
        children.push(brandLogo(slide.id, brand.logo));
    return baseSlide(slide, children);
}
function titleAndContent(slide, brand) {
    const title = stringProp(slide, "title", "Untitled");
    const body = stringArrayProp(slide, "items", []);
    const children = [
        {
            id: `${slide.id}.title`,
            type: "text",
            text: title,
            style: "slide-title",
            align: "left",
        },
        {
            id: `${slide.id}.content`,
            type: "stack",
            area: "content",
            direction: "vertical",
            gap: 14,
            align: "start",
            children: body.length > 0
                ? [{ id: `${slide.id}.bullets`, type: "bullets", items: body, density: "comfortable" }]
                : [],
        },
    ];
    if (brand.logo)
        children.push(brandLogo(slide.id, brand.logo));
    return baseSlide(slide, children);
}
function imageAndText(slide, brand) {
    const title = stringProp(slide, "title", "Untitled");
    const image = stringProp(slide, "image", "");
    const text = stringProp(slide, "text", "");
    const children = [
        { id: `${slide.id}.title`, type: "text", text: title, style: "slide-title" },
        {
            id: `${slide.id}.columns`,
            type: "grid",
            area: "content",
            columns: 2,
            gap: 22,
            children: [
                { id: `${slide.id}.image`, type: "image", src: image, fit: "cover", alt: title },
                { id: `${slide.id}.text`, type: "text", text, style: "body" },
            ],
        },
    ];
    if (brand.logo)
        children.push(brandLogo(slide.id, brand.logo));
    return baseSlide(slide, children);
}
function brandLogo(slideId, src) {
    return {
        id: `${slideId}.brandLogo`,
        type: "image",
        src,
        alt: "Brand logo",
        position: "top-right",
        width: 96,
        height: 40,
        fit: "contain",
    };
}
function stringProp(slide, key, fallback) {
    const value = slide[key];
    return typeof value === "string" ? value : fallback;
}
function stringArrayProp(slide, key, fallback) {
    const value = slide[key];
    return Array.isArray(value) ? value.map(String) : fallback;
}
export function getSlide(deck, slideId) {
    const slide = deck.slides.find((item) => item.id === slideId);
    if (!slide)
        throw new Error(`Slide not found: ${slideId}`);
    return slide;
}
