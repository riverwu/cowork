import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { createSourceDeck, normalizeSlide } from "./source-deck.js";
import { renderSourceDeckToPptx } from "./render.js";
import { validateDeck } from "./validate.js";
export async function createDeck(deckPath, options = {}) {
    const deck = createSourceDeck(options);
    await writeDeck(deckPath, deck);
    return summary(deck, { ok: true });
}
export async function setDeckProps(deckPath, props) {
    const deck = await readDeck(deckPath);
    const { slides: _slides, ...allowed } = props;
    deck.deck = { ...deck.deck, ...allowed };
    await writeDeck(deckPath, deck);
    return summary(deck, { ok: true });
}
export async function appendSlide(deckPath, slide) {
    const deck = await readDeck(deckPath);
    deck.slides.push(normalizeSlide(slide));
    await writeDeck(deckPath, deck);
    return summary(deck, { ok: true, insertedAt: deck.slides.length - 1 });
}
export async function insertSlide(deckPath, at, slide) {
    const deck = await readDeck(deckPath);
    const index = Math.max(0, Math.min(at, deck.slides.length));
    deck.slides.splice(index, 0, normalizeSlide(slide));
    await writeDeck(deckPath, deck);
    return summary(deck, { ok: true, insertedAt: index });
}
export async function replaceSlide(deckPath, slideIdOrIndex, slide) {
    const deck = await readDeck(deckPath);
    const index = findSlideIndex(deck, slideIdOrIndex);
    if (index < 0)
        return summary(deck, { ok: false, error: `Slide not found: ${slideIdOrIndex}` });
    deck.slides[index] = normalizeSlide(slide);
    await writeDeck(deckPath, deck);
    return summary(deck, { ok: true, replacedAt: index });
}
export async function deleteSlide(deckPath, slideIdOrIndex) {
    const deck = await readDeck(deckPath);
    const index = findSlideIndex(deck, slideIdOrIndex);
    if (index < 0)
        return summary(deck, { ok: false, error: `Slide not found: ${slideIdOrIndex}` });
    deck.slides.splice(index, 1);
    await writeDeck(deckPath, deck);
    return summary(deck, { ok: true, deletedAt: index });
}
export async function validateDeckPath(deckPath) {
    return validateDeck(await readDeck(deckPath));
}
export async function renderDeck(deckPath, outputPath) {
    const deck = await readDeck(deckPath);
    const validation = validateDeck(deck);
    const rendered = await renderSourceDeckToPptx(deck, outputPath);
    return { ...rendered, validation };
}
export async function readDeck(deckPath) {
    const parsed = JSON.parse(await readFile(deckPath, "utf8"));
    if (parsed.slideml2 !== 2)
        throw new Error(`Expected SlideML2 source deck with slideml2: 2 at ${deckPath}`);
    return parsed;
}
export async function writeDeck(deckPath, deck) {
    await mkdir(dirname(deckPath), { recursive: true });
    await writeFile(deckPath, JSON.stringify(deck, null, 2), "utf8");
}
function summary(deck, extra) {
    return {
        ok: extra.ok ?? true,
        error: extra.error,
        slideCount: deck.slides.length,
        insertedAt: extra.insertedAt,
        replacedAt: extra.replacedAt,
        deletedAt: extra.deletedAt,
        slides: deck.slides.map((slide, index) => ({ index, id: slide.id, title: slide.title })),
    };
}
function findSlideIndex(deck, slideIdOrIndex) {
    if (typeof slideIdOrIndex === "number")
        return slideIdOrIndex >= 0 && slideIdOrIndex < deck.slides.length ? slideIdOrIndex : -1;
    return deck.slides.findIndex((slide) => slide.id === slideIdOrIndex);
}
