export function createSourceDeck(options = {}) {
    return {
        slideml2: 2,
        deck: {
            size: "16x9",
            theme: options.theme || "default",
            brand: options.brand || { name: options.title, primary: "2563EB" },
            metadata: options.title ? { title: options.title } : {},
        },
        slides: [],
    };
}
export function sourceToRenderedDeck(source) {
    return {
        deck: {
            size: source.deck.size || "16x9",
            theme: source.deck.theme || "default",
            brand: source.deck.brand || {},
        },
        slides: source.slides.flatMap(expandArticleSlide).map(sourceSlideToRendered),
    };
}
export function sourceSlideToRendered(slide) {
    return {
        id: slide.id,
        layout: "title-and-content",
        dom: {
            id: `${slide.id}.root`,
            type: "slide",
            background: slide.background || "background",
            notes: slide.notes,
            children: [
                ...(slide.title ? [{
                        id: `${slide.id}.title`,
                        type: "component",
                        component: "slide-title",
                        text: slide.title,
                        align: "left",
                    }] : []),
                ...ensureContentArea(slide.id, slide.children),
            ],
        },
    };
}
export function normalizeSlide(slide) {
    return {
        ...slide,
        children: slide.children.map((node, index) => normalizeNode(slide.id, node, `${slide.id}.node-${index + 1}`)),
    };
}
function ensureContentArea(slideId, children) {
    if (children.some((node) => node.area === "content"))
        return children;
    return [{
            id: `${slideId}.content`,
            type: "stack",
            area: "content",
            direction: "vertical",
            gap: 14,
            children,
        }];
}
function normalizeNode(slideId, node, fallbackId) {
    const raw = node;
    const id = node.id || fallbackId;
    return {
        ...node,
        id,
        children: node.children?.map((child, index) => normalizeNode(slideId, child, `${id}.${index + 1}`)),
    };
}
function expandArticleSlide(slide) {
    const article = findArticle(slide.children);
    if (!article)
        return [slide];
    const paragraphs = articleParagraphs(article);
    if (paragraphs.length === 0)
        return [slide];
    const chunks = paginateArticle(paragraphs);
    const articleTitle = typeof article.title === "string" && article.title.trim() ? article.title.trim() : slide.title;
    return chunks.map((chunk, index) => ({
        id: `${slide.id}${index === 0 ? "" : `-${index + 1}`}`,
        title: chunks.length > 1 && articleTitle ? `${articleTitle} (${index + 1}/${chunks.length})` : articleTitle,
        background: slide.background,
        notes: slide.notes,
        metadata: { ...slide.metadata, articleSourceSlideId: slide.id, articlePage: index + 1, articlePageCount: chunks.length },
        children: [{
                id: `${slide.id}.article.${index + 1}.content`,
                type: "stack",
                area: "content",
                direction: "vertical",
                gap: 9,
                children: [
                    ...chunk.map((text, paragraphIndex) => ({
                        id: `${slide.id}.article.${index + 1}.p${paragraphIndex + 1}`,
                        type: "text",
                        style: "article",
                        text,
                    })),
                    ...(index === chunks.length - 1 && typeof article.source === "string" && article.source.trim()
                        ? [{ id: `${slide.id}.article.source`, type: "component", component: "source-note", text: article.source.trim() }]
                        : []),
                ],
            }],
    }));
}
function findArticle(nodes) {
    for (const node of nodes) {
        if (node.type === "component" && node.component === "article")
            return node;
        const nested = node.children ? findArticle(node.children) : null;
        if (nested)
            return nested;
    }
    return null;
}
function articleParagraphs(node) {
    if (Array.isArray(node.paragraphs))
        return node.paragraphs.map(String).map((item) => item.trim()).filter(Boolean);
    if (typeof node.text === "string")
        return node.text.split(/\n\s*\n/g).map((item) => item.trim()).filter(Boolean);
    return [];
}
function paginateArticle(paragraphs) {
    const pages = [];
    let current = [];
    let currentWeight = 0;
    const pageWeight = 950;
    for (const paragraph of paragraphs) {
        const weight = weightedTextLength(paragraph) + 80;
        if (current.length > 0 && currentWeight + weight > pageWeight) {
            pages.push(current);
            current = [];
            currentWeight = 0;
        }
        if (weight > pageWeight) {
            const split = splitLongParagraph(paragraph, pageWeight);
            for (const part of split) {
                if (current.length > 0) {
                    pages.push(current);
                    current = [];
                    currentWeight = 0;
                }
                pages.push([part]);
            }
            continue;
        }
        current.push(paragraph);
        currentWeight += weight;
    }
    if (current.length > 0)
        pages.push(current);
    return pages;
}
function splitLongParagraph(text, limit) {
    const sentences = text.split(/(?<=[。.!?？])\s*/).filter(Boolean);
    const parts = [];
    let current = "";
    for (const sentence of sentences.length > 1 ? sentences : text.match(/.{1,420}/g) || [text]) {
        if (current && weightedTextLength(current + sentence) > limit) {
            parts.push(current.trim());
            current = "";
        }
        current += sentence;
    }
    if (current.trim())
        parts.push(current.trim());
    return parts;
}
function weightedTextLength(text) {
    let length = 0;
    for (const char of text)
        length += /[\u4e00-\u9fff]/.test(char) ? 1.05 : 0.58;
    return length;
}
