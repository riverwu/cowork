import { readFile, writeFile } from "node:fs/promises";
import { comparisonCard, insightCallout, metricCard, stepCard } from "../components.js";
import { renderToPptx } from "../render.js";
export async function generateWithComponentAgent(markdownPath, outputPath, logo, config = llmConfigFromEnv()) {
    const markdown = await readFile(markdownPath, "utf8");
    const plan = await planWithComponentAgent(markdown, logo, config);
    const deck = deckFromComponentPlan(plan, logo);
    const planPath = `${outputPath}.component-plan.json`;
    const slideml2Path = `${outputPath}.slideml2.json`;
    await writeFile(planPath, JSON.stringify(plan, null, 2), "utf8");
    await writeFile(slideml2Path, JSON.stringify(deck, null, 2), "utf8");
    const rendered = await renderToPptx(deck, outputPath);
    return { plan, deck, outputPath, planPath, slideml2Path, domPath: rendered.domPath };
}
export async function planWithComponentAgent(markdown, logo, config = llmConfigFromEnv()) {
    const response = await callComponentAgent(markdown, config);
    try {
        return normalizeComponentPlan(JSON.parse(extractJsonObject(response)), markdown, logo);
    }
    catch (error) {
        const repaired = await repairJson(response, config);
        return normalizeComponentPlan(JSON.parse(extractJsonObject(repaired)), markdown, logo);
    }
}
export function deckFromComponentPlan(plan, logo) {
    return {
        deck: { size: "16x9", theme: "simple", brand: { ...plan.brand, logo } },
        slides: plan.slides.map((slide) => slideFromComponentPlan(slide, logo)),
    };
}
function slideFromComponentPlan(plan, logo) {
    const contentChildren = plan.children.map((child, index) => expandAgentNode(plan.id, child, `${plan.id}.content.${index + 1}`, logo));
    const hasContentArea = contentChildren.some((child) => child.area === "content");
    return {
        id: plan.id,
        layout: "title-and-content",
        dom: {
            id: `${plan.id}.root`,
            type: "slide",
            background: "background",
            children: [
                {
                    id: `${plan.id}.title`,
                    type: "text",
                    text: plan.title,
                    style: "slide-title",
                    align: "left",
                },
                ...(hasContentArea
                    ? contentChildren
                    : [{
                            id: `${plan.id}.content`,
                            type: "stack",
                            area: "content",
                            direction: "vertical",
                            gap: 14,
                            children: contentChildren,
                        }]),
            ],
        },
    };
}
function expandAgentNode(slideId, node, fallbackId, logo) {
    if (node.type === "component")
        return expandComponentNode(slideId, node, fallbackId, logo);
    const children = "children" in node && Array.isArray(node.children)
        ? node.children.map((child, index) => expandAgentNode(slideId, child, `${fallbackId}.${index + 1}`, logo))
        : undefined;
    const { children: _children, ...fields } = node;
    return {
        ...sanitizeFields(fields),
        id: scopedId(slideId, node.id || fallbackId),
        type: node.type,
        children,
    };
}
function expandComponentNode(slideId, node, fallbackId, logo) {
    const id = scopedId(slideId, node.id || fallbackId);
    const localId = id.startsWith(`${slideId}.`) ? id.slice(slideId.length + 1) : id;
    if (node.component === "metric-card") {
        const unit = stringValue(node.unit, "");
        return mergeRootFields(node, { ...metricCard(slideId, localId, `${stringValue(node.value, "")}${unit}`, stringValue(node.label, "")), id });
    }
    if (node.component === "step-card") {
        return mergeRootFields(node, { ...stepCard(slideId, localId, stringValue(node.step, stringValue(node.number, "")), stringValue(node.title, stringValue(node.label, "")), stringValue(node.body, stringValue(node.description, stringValue(node.status, stringValue(node.subtitle, stringArray(node.steps).join("\n")))))), id });
    }
    if (node.component === "comparison-card") {
        return mergeRootFields(node, { ...comparisonCard(slideId, localId, stringValue(node.title, ""), comparisonPoints(node).slice(0, 5)), id });
    }
    return mergeRootFields(node, { ...insightCallout(slideId, localId, stringValue(node.text, "")), id });
}
async function callComponentAgent(markdown, config) {
    const response = await fetch(`${normalizeAnthropicBaseURL(config.baseURL)}/v1/messages`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": config.apiKey,
            "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
            model: config.model,
            max_tokens: config.maxTokens ?? 12000,
            system: componentAgentPrompt(),
            messages: [{ role: "user", content: `请根据下面 markdown 生成 SlideML2 component deck JSON。\n\n${markdown}` }],
            stream: false,
        }),
    });
    if (!response.ok)
        throw new Error(`Component agent failed ${response.status}: ${await response.text()}`);
    const json = await response.json();
    const text = json.content?.map((part) => part.text || "").join("\n").trim();
    if (!text)
        throw new Error("Component agent returned empty content");
    return text;
}
async function repairJson(broken, config) {
    const response = await fetch(`${normalizeAnthropicBaseURL(config.baseURL)}/v1/messages`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": config.apiKey,
            "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
            model: config.model,
            max_tokens: Math.min(config.maxTokens ?? 6000, 6000),
            system: "你是 JSON 修复器。只输出修复后的 JSON，不要解释，不要 markdown 代码块。",
            messages: [{ role: "user", content: `修复下面的 SlideML2 JSON。保持原有内容，删除无法修复的尾部不完整对象也可以，但必须输出合法 JSON。\n\n${broken}` }],
            stream: false,
        }),
    });
    if (!response.ok)
        throw new Error(`Component JSON repair failed ${response.status}: ${await response.text()}`);
    const json = await response.json();
    const text = json.content?.map((part) => part.text || "").join("\n").trim();
    if (!text)
        throw new Error("Component JSON repair returned empty content");
    return text;
}
function componentAgentPrompt() {
    return [
        "你是 SlideML2 component agent。你的任务是从 markdown 生成 PPT 的语义 component tree。",
        "只输出 JSON，不要输出 markdown 代码块，不要解释。",
        "只生成正文内容页，不要生成封面页、目录页、章节页、结束页、谢谢页、数据来源页。",
        "总页数控制在 5-7 页；每页最多 3 个直接子节点；每个 grid 最多 4 列。",
        "不要使用页面级 layout 名称；不要输出 cover、section、dashboard、product-matrix、risk-list、recommendation-list 这类页面级 component。",
        "你可以使用 primitive node：stack、grid、text、bullets、image。",
        "你可以使用基础 component：metric-card、step-card、comparison-card、callout。",
        "注意 bullets 是 primitive node：{type:'bullets'}，不是 component。",
        "如果需要表格信息，改写为少量 comparison-card、metric-card 或 bullets，不要输出完整表格网格。",
        "不要使用 emoji，避免影响字体和版面。",
        "每页 children 中应优先放一个带 area:'content' 的 stack 或 grid 作为主内容区域。",
        "用 stack/grid 自己组织页面：direction、columns、columnWeights、rowWeights、gap、fixedHeight、layoutWeight、padding、fill、line 都可以设置。",
        "所有节点字段都是扁平字段；不要输出 name 或 props。",
        "每页信息要克制，内容太多时拆成多页。每页需要 title、structure、children。",
        "不要臆造事实，只能压缩、重组 markdown 中的信息。",
        "JSON 结构：",
        JSON.stringify({
            title: "deck title",
            brand: { name: "brand or topic", primary: "2563EB" },
            slides: [{
                    id: "slide-1",
                    title: "页面标题",
                    structure: "说明 agent 使用 stack/grid/component 形成的结构",
                    children: [{
                            type: "stack",
                            id: "main-content",
                            area: "content",
                            direction: "vertical",
                            gap: 14,
                            children: [
                                { type: "component", component: "callout", id: "key-message", text: "一句主结论" },
                                { type: "grid", id: "metric-row", columns: 3, gap: 12, fixedHeight: 1.85, children: [
                                        { type: "component", component: "metric-card", id: "metric-1", value: "30%+", label: "智能眼镜 CAGR" },
                                    ] },
                            ],
                        }],
                }],
        }, null, 2),
    ].join("\n");
}
function normalizeComponentPlan(raw, markdown, logo) {
    const record = isRecord(raw) ? raw : {};
    const brand = isRecord(record.brand) ? record.brand : {};
    const slides = Array.isArray(record.slides) ? record.slides : [];
    const normalizedSlides = slides.map((slide, index) => normalizeSlide(slide, index)).filter((slide) => Boolean(slide));
    if (normalizedSlides.length === 0)
        throw new Error("Component agent did not return valid slides");
    return {
        title: stringValue(record.title, firstHeading(markdown) || "SlideML2 Component Deck"),
        brand: {
            name: stringValue(brand.name, firstHeading(markdown) || "SlideML2"),
            primary: normalizeHex(stringValue(brand.primary, "2563EB")),
            logo,
        },
        slides: normalizedSlides.slice(0, 12),
    };
}
function normalizeSlide(raw, index) {
    if (!isRecord(raw))
        return null;
    const children = Array.isArray(raw.children) ? raw.children.map(normalizeAgentNode).filter((node) => Boolean(node)) : [];
    if (children.length === 0)
        return null;
    return {
        id: slugId(stringValue(raw.id, `slide-${index + 1}`), index),
        title: stringValue(raw.title, `页面 ${index + 1}`),
        structure: stringValue(raw.structure, "agent-composed component tree"),
        children,
    };
}
function normalizeAgentNode(raw) {
    if (!isRecord(raw))
        return null;
    if ("name" in raw || "props" in raw)
        return null;
    const type = raw.type;
    const id = safeName(stringValue(raw.id, String(type || "node")), "node");
    const fields = sanitizeFields(raw);
    if (type === "component") {
        const component = raw.component;
        if (component !== "metric-card" && component !== "step-card" && component !== "comparison-card" && component !== "callout")
            return null;
        return { ...fields, type, component, id };
    }
    if (type === "stack" || type === "grid") {
        const children = Array.isArray(raw.children) ? raw.children.map(normalizeAgentNode).filter((node) => Boolean(node)) : [];
        return { ...fields, type, id, children };
    }
    if (type === "text")
        return { ...fields, type, id, text: stringValue(fields.text, stringValue(fields.content, "")), style: stringValue(fields.style, stringValue(fields.kind, "paragraph")) };
    if (type === "bullets")
        return { ...fields, type, id, items: stringArray(fields.items).slice(0, 8) };
    if (type === "image")
        return { ...fields, type, id };
    return null;
}
function sanitizeFields(fields) {
    return Object.fromEntries(Object.entries(fields).filter(([key, value]) => (key !== "children" &&
        key !== "props" &&
        key !== "name" &&
        (typeof value === "string" ||
            typeof value === "number" ||
            typeof value === "boolean" ||
            Array.isArray(value)))));
}
function scopedId(slideId, id) {
    return id.startsWith(`${slideId}.`) ? id : `${slideId}.${safeName(id, "node")}`;
}
function mergeRootFields(source, expanded) {
    const rootFields = sanitizeFields(source);
    delete rootFields.type;
    delete rootFields.component;
    delete rootFields.id;
    return { ...expanded, ...rootFields };
}
function extractJsonObject(text) {
    const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    const source = fenced?.[1] || text;
    const start = source.indexOf("{");
    const end = source.lastIndexOf("}");
    if (start < 0 || end < start)
        throw new Error(`Component agent did not return JSON: ${text.slice(0, 200)}`);
    return source.slice(start, end + 1);
}
function llmConfigFromEnv() {
    const apiKey = process.env.LLM_API_KEY || process.env.MINIMAX_API_KEY || "";
    const baseURL = process.env.LLM_API || process.env.MINIMAX_API || "";
    const model = process.env.LLM_MODEL || "MiniMax-M2.7-highspeed";
    if (!apiKey || !baseURL)
        throw new Error("Component agent requires LLM_API and LLM_API_KEY");
    return { apiKey, baseURL, model };
}
function normalizeAnthropicBaseURL(raw) {
    return raw.replace(/\/+$/, "").replace(/\/v1$/, "");
}
function firstHeading(markdown) {
    return markdown.match(/^#\s+(.+)$/m)?.[1]?.trim() || null;
}
function stringValue(value, fallback) {
    return typeof value === "string" && value.trim() ? value.trim() : fallback;
}
function stringArray(value) {
    return Array.isArray(value) ? value.map(String).map((item) => item.trim()).filter(Boolean) : [];
}
function comparisonPoints(fields) {
    const points = stringArray(fields.points);
    if (points.length > 0)
        return points;
    const items = stringArray(fields.items);
    if (items.length > 0)
        return items;
    const derived = [
        stringValue(fields.subtitle, ""),
        stringValue(fields.body, ""),
        stringValue(fields.leftLabel, "") && stringValue(fields.leftValue, "") ? `${stringValue(fields.leftLabel, "")}: ${stringValue(fields.leftValue, "")}` : "",
        stringValue(fields.rightLabel, "") && stringValue(fields.rightValue, "") ? `${stringValue(fields.rightLabel, "")}: ${stringValue(fields.rightValue, "")}` : "",
    ].filter(Boolean);
    return derived.length > 0 ? derived : [stringValue(fields.title, "")].filter(Boolean);
}
function styleToKind(style) {
    if (style === "subtitle")
        return "card-title";
    if (style === "small")
        return "caption";
    if (style === "large")
        return "section-title";
    return "paragraph";
}
function safeName(value, fallback) {
    const cleaned = value.trim().replace(/[^a-zA-Z0-9\u4e00-\u9fff_-]+/g, "-").replace(/^-+|-+$/g, "");
    return cleaned || fallback;
}
function slugId(value, index) {
    const cleaned = value.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g, "-").replace(/^-+|-+$/g, "");
    return cleaned || `slide-${index + 1}`;
}
function normalizeHex(value) {
    const cleaned = value.replace(/^#/, "");
    return /^[0-9A-Fa-f]{6}$/.test(cleaned) ? cleaned.toUpperCase() : "2563EB";
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
