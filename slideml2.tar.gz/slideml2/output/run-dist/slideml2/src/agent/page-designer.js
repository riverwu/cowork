import { comparisonCard, imageWithCaptionPanel, insightCallout, metricCard, paragraphText, stepCard, titleText } from "../components.js";
export function designSlideFromBrief(brief) {
    return {
        id: brief.slideId,
        layout: "image-and-text",
        dom: {
            id: `${brief.slideId}.root`,
            type: "slide",
            background: "background",
            children: [
                titleText(brief.slideId, "slide-title", brief.title),
                {
                    id: `${brief.slideId}.contentLayout`,
                    type: "grid",
                    area: "content",
                    columns: 2,
                    columnWeights: [0.54, 0.46],
                    gap: 22,
                    role: "text-image-layout",
                    children: [
                        {
                            id: `${brief.slideId}.textPanel`,
                            type: "stack",
                            direction: "vertical",
                            gap: 12,
                            children: [
                                { ...paragraphText(brief.slideId, "body-text", brief.body), valign: "top" },
                            ],
                        },
                        imageWithCaptionPanel(brief.slideId, brief.imageSrc, brief.imageTitle),
                    ],
                },
            ],
        },
    };
}
export function designDeckFromBrief(brand, brief) {
    return {
        deck: { size: "16x9", theme: "simple", brand },
        slides: [designSlideFromBrief(brief)],
    };
}
export function designDashboardSlide(brief) {
    return {
        id: brief.slideId,
        layout: "title-and-content",
        dom: {
            id: `${brief.slideId}.root`,
            type: "slide",
            background: "background",
            children: [
                titleText(brief.slideId, "slide-title", brief.title),
                {
                    id: `${brief.slideId}.dashboard`,
                    type: "stack",
                    area: "content",
                    direction: "vertical",
                    gap: 14,
                    children: [
                        insightCallout(brief.slideId, "dashboard-summary", brief.summary),
                        {
                            id: `${brief.slideId}.metricStrip`,
                            type: "grid",
                            columns: 3,
                            gap: 12,
                            fixedHeight: 1.85,
                            children: brief.metrics.map((metric) => metricCard(brief.slideId, metric.name, metric.value, metric.label)),
                        },
                        {
                            id: `${brief.slideId}.detailGrid`,
                            type: "grid",
                            columns: 2,
                            columnWeights: [0.46, 0.54],
                            gap: 18,
                            layoutWeight: 1,
                            children: [
                                {
                                    id: `${brief.slideId}.bulletPanel`,
                                    type: "stack",
                                    direction: "vertical",
                                    gap: 10,
                                    fill: "surface",
                                    line: "divider",
                                    padding: 10,
                                    children: [
                                        { id: `${brief.slideId}.bulletHeading`, type: "text", text: "关键判断", style: "card-title", color: "brand.primary", fixedHeight: 0.65 },
                                        { id: `${brief.slideId}.bulletList`, type: "bullets", items: brief.bullets, density: "compact", layoutWeight: 1 },
                                    ],
                                },
                                imageWithCaptionPanel(brief.slideId, brief.imageSrc, brief.imageTitle),
                            ],
                        },
                    ],
                },
            ],
        },
    };
}
export function designTimelineSlide(brief) {
    return {
        id: brief.slideId,
        layout: "title-and-content",
        dom: {
            id: `${brief.slideId}.root`,
            type: "slide",
            background: "background",
            children: [
                titleText(brief.slideId, "slide-title", brief.title),
                {
                    id: `${brief.slideId}.timelineLayout`,
                    type: "stack",
                    area: "content",
                    direction: "vertical",
                    gap: 16,
                    children: [
                        { ...paragraphText(brief.slideId, "timeline-intro", brief.intro), fixedHeight: 1.05, valign: "top" },
                        {
                            id: `${brief.slideId}.steps`,
                            type: "grid",
                            columns: brief.steps.length,
                            gap: 12,
                            fixedHeight: 6.2,
                            children: brief.steps.map((step, index) => stepCard(brief.slideId, `step-${index + 1}`, `0${index + 1}`, step.title, step.body)),
                        },
                    ],
                },
            ],
        },
    };
}
export function designComparisonSlide(brief) {
    return {
        id: brief.slideId,
        layout: "title-and-content",
        dom: {
            id: `${brief.slideId}.root`,
            type: "slide",
            background: "background",
            children: [
                titleText(brief.slideId, "slide-title", brief.title),
                {
                    id: `${brief.slideId}.comparisonLayout`,
                    type: "stack",
                    area: "content",
                    direction: "vertical",
                    gap: 14,
                    children: [
                        insightCallout(brief.slideId, "comparison-thesis", brief.thesis),
                        {
                            id: `${brief.slideId}.comparisonGrid`,
                            type: "grid",
                            columns: brief.columns.length,
                            gap: 14,
                            fixedHeight: 6.35,
                            children: brief.columns.map((column, index) => comparisonCard(brief.slideId, `comparison-${index + 1}`, column.title, column.points)),
                        },
                    ],
                },
            ],
        },
    };
}
export function designComplexDeck(brand, briefs) {
    return {
        deck: { size: "16x9", theme: "simple", brand },
        slides: [
            designDashboardSlide(briefs.dashboard),
            designTimelineSlide(briefs.timeline),
            designComparisonSlide(briefs.comparison),
        ],
    };
}
