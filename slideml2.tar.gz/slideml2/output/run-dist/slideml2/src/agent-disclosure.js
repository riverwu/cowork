import { describeComponent, listComponents } from "./component-registry.js";
function rankComponentsForIntent(intent, limit = 4) {
    const text = intent.toLowerCase();
    const scored = listComponents().map((component) => {
        const haystack = [component.name, component.purpose].join(" ").toLowerCase();
        let score = 0;
        for (const term of intentTerms(text)) {
            if (haystack.includes(term))
                score += 2;
        }
        score += heuristicComponentScore(component.name, text);
        return { name: component.name, score };
    });
    const selected = scored
        .filter((item) => item.score > 0)
        .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
        .map((item) => item.name)
        .slice(0, limit);
    return selected.length > 0 ? selected : ["callout", "comparison-card", "metric-card"].slice(0, limit);
}
export function buildAgentPromptPack(options = {}) {
    const components = unique(["stack", "grid", ...(options.components?.length ? options.components : rankComponentsForIntent(options.intent || "", 3))]);
    const lines = [
        "SlideML2 compact guide:",
        "- Output exactly one slide JSON: {id,title,children}.",
        "- Discover with listComponents(), then describeComponent(name) only for selected components.",
        "- Use flat component nodes: {id,type:'component',component:'image',...fields}.",
        "- Use exactly one top-level stack/grid with area:'content'; stack/grid must include non-empty children.",
        "- Component nodes are flat; do not wrap fields in props.",
        "- Avoid page-level components: cover, section, dashboard, product-matrix, risk-list.",
        "- Minimal shape: {\"id\":\"s1\",\"title\":\"Title\",\"children\":[{\"id\":\"s1.content\",\"type\":\"component\",\"component\":\"stack\",\"area\":\"content\",\"gap\":12,\"children\":[{\"id\":\"s1.lead\",\"type\":\"component\",\"component\":\"text\",\"text\":\"One insight\"}]}]}",
        "",
        "Component schemas:",
        ...components.map((name) => compactComponentSchema(name, Boolean(options.includeExamples))).filter(Boolean),
    ];
    return lines.join("\n");
}
export function getAgentSystemPrompt() {
    return [
        "You are a SlideML2 agent.",
        "Use progressive disclosure: keep context small, list capabilities before requesting full details.",
        "Only append/replace whole slides; do not edit individual nodes.",
        "Return strict JSON only, without markdown fences or explanation.",
    ].join("\n");
}
function compactComponentSchema(name, includeExample) {
    const definition = describeComponent(name);
    if (!definition)
        return "";
    const fields = Object.entries(definition.fields).slice(0, 8).map(([key, prop]) => `${key}${prop.required ? "*" : ""}:${prop.type}`).join(", ");
    const shouldIncludeExample = includeExample || definition.children.required;
    const example = shouldIncludeExample && definition.examples[0] ? ` example=${JSON.stringify(definition.examples[0])}` : "";
    const parent = definition.layoutBehavior?.preferredParent || "any";
    const children = definition.children.allowed
        ? ` children=${definition.children.required ? "required" : "optional"}`
        : " children=none";
    return `- ${definition.name}: ${definition.purpose} parent=${parent}${children} fields={component:'${definition.name}', ${fields}}${example}`;
}
function intentTerms(text) {
    return text.split(/[^a-z0-9\u4e00-\u9fff%]+/).map((item) => item.trim()).filter((item) => item.length >= 2);
}
function heuristicComponentScore(name, text) {
    if (name === "stack" && /layout|column|row|section|布局|区域|纵向|横向/.test(text))
        return 5;
    if (name === "grid" && /grid|columns|cards|matrix|网格|分栏|矩阵|卡片/.test(text))
        return 5;
    if (name === "spacer" && /space|gap|breath|留白|间距|空白/.test(text))
        return 4;
    if (name === "divider" && /divider|rule|split|separator|分割|分隔|线/.test(text))
        return 4;
    if (name === "image" && /image|photo|logo|visual|图片|图像|照片|视觉|logo/.test(text))
        return 6;
    if (name === "table" && /table|rows|columns|data|表格|行|列|数据/.test(text))
        return 6;
    if (name === "chart" && /chart|bar|line|pie|trend|图表|柱状|折线|饼图|趋势/.test(text))
        return 6;
    if (name === "metric-card" && /metric|kpi|growth|market|revenue|规模|增长|营收|比例|百分|cagr|%/.test(text))
        return 6;
    if (name === "callout" && /insight|thesis|highlight|summary|结论|洞察|摘要|建议|判断/.test(text))
        return 5;
    if (name === "lead" && /summary|thesis|opening|摘要|开篇|主结论|核心判断/.test(text))
        return 5;
    if (name === "article" && /article|passage|prose|reading|long-form|长文|文章|阅读|段落|原文/.test(text))
        return 6;
    if (name === "text" && /text|paragraph|body|explain|正文|说明|解释/.test(text))
        return 4;
    if (name === "code" && /code|api|config|json|代码|接口|配置/.test(text))
        return 6;
    if (name === "source-note" && /source|citation|disclaimer|出处|来源|数据来源|免责声明/.test(text))
        return 5;
    if (name === "label" && /status|badge|priority|tag|category|状态|标签|优先级|分类/.test(text))
        return 4;
    if (name === "comparison-card" && /compare|vendor|product|option|竞争|对比|比较|厂商|产品/.test(text))
        return 5;
    if (name === "step-card" && /timeline|roadmap|process|stage|步骤|阶段|路线|流程/.test(text))
        return 5;
    if (name === "definition-card" && /definition|concept|term|定义|概念|术语/.test(text))
        return 4;
    return 0;
}
function unique(items) {
    return Array.from(new Set(items));
}
