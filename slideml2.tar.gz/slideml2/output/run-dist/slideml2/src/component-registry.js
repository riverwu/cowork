import { comparisonCard, insightCallout, metricCard, stepCard } from "./components.js";
import { listNodeTypes } from "./node-types.js";
const PRIMITIVE_COMPONENT_TYPES = ["stack", "grid", "spacer", "divider", "bullets", "image", "table", "chart", "shape"];
export const COMPONENT_DEFINITIONS = [
    textComponent("deck-title", "Whole-deck title text.", "deck-title"),
    textComponent("slide-title", "Slide title slot text, usually generated from slide.title.", "slide-title"),
    textComponent("h1", "Primary heading inside the slide content area.", "section-title"),
    textComponent("h2", "Secondary heading inside a group, panel, or card.", "card-title"),
    textComponent("lead", "Lead sentence or thesis.", "lead"),
    textComponent("text", "Normal single-slide body text.", "paragraph"),
    articleComponent(),
    textComponent("source-note", "Data source, citation, or disclaimer note.", "footnote"),
    textComponent("label", "Short label, badge, or tag text.", "label", {
        variant: { type: "enum", enum: ["plain", "badge", "tag"], description: "Optional visual variant." },
        tone: { type: "enum", enum: ["neutral", "brand", "positive", "warning", "danger"], description: "Optional semantic tone." },
    }),
    textComponent("code", "Code snippet text.", "code", {
        title: { type: "string", description: "Optional code block title." },
        language: { type: "string", description: "Optional language label." },
        caption: { type: "string", description: "Optional code caption." },
    }),
    component("metric-card", "Show one headline metric.", {
        value: { type: "string", required: true, semantic: "metric-value", description: "Short numeric or ranked value." },
        label: { type: "string", required: true, semantic: "metric-label", description: "Short metric label." },
        unit: { type: "string", description: "Optional unit appended to value." },
        trend: { type: "enum", enum: ["up", "down", "flat"], description: "Optional trend intent." },
    }, "stack(text.metric-value, text.metric-label)", "grid"),
    component("callout", "Highlight one key message.", {
        text: { type: "string", required: true, semantic: "callout", description: "One concise insight." },
        tone: { type: "enum", enum: ["neutral", "brand", "positive", "warning", "danger"], description: "Semantic tone." },
    }, "text.callout with styled surface", "stack"),
    component("comparison-card", "Summarize one compared object.", {
        title: { type: "string", required: true, semantic: "card-title", description: "Object title." },
        subtitle: { type: "string", semantic: "label", description: "Optional subtitle." },
        points: { type: "array", semantic: "bullet", description: "Short supporting points." },
        items: { type: "array", semantic: "bullet", description: "Alias for points." },
    }, "stack(text.card-title, bullets)", "grid"),
    component("step-card", "Represent one stage or step.", {
        step: { type: "string", semantic: "numbered-step", description: "Optional step label." },
        title: { type: "string", required: true, semantic: "card-title", description: "Step title." },
        body: { type: "string", semantic: "paragraph", description: "Step body." },
        steps: { type: "array", semantic: "bullet", description: "Alias used when a step has multiple short details." },
    }, "stack(text.numbered-step, text.card-title, text.paragraph)", "grid"),
    component("definition-card", "Define a term.", {
        term: { type: "string", required: true, semantic: "card-title", description: "Term." },
        definition: { type: "string", required: true, semantic: "paragraph", description: "Definition." },
    }, "stack(text.card-title, text.paragraph)", "grid"),
];
export function listComponents() {
    return [
        ...primitiveComponentDescriptions().map(({ name, purpose }) => ({ name, purpose })),
        ...COMPONENT_DEFINITIONS.map(({ name, purpose }) => ({ name, purpose })),
    ];
}
export function describeComponent(name) {
    const primitive = primitiveComponentDescription(name);
    if (primitive)
        return primitive;
    return COMPONENT_DEFINITIONS.find((item) => item.name === name) || null;
}
export function isComponentName(name) {
    return typeof name === "string" && Boolean(describeComponent(name));
}
export function expandComponent(slideId, node, logo = "") {
    const componentName = String(node.component || "");
    const primitiveType = primitiveComponentType(componentName);
    if (primitiveType)
        return primitiveComponentNode(slideId, primitiveType, node);
    const name = componentLocalId(slideId, node.id);
    const textStyle = semanticTextStyle(componentName);
    if (textStyle)
        return withComponentRoot(node, textComponentNode(slideId, name, stringValue(node.text, ""), textStyle, node));
    if (componentName === "metric-card") {
        const unit = stringValue(node.unit, "");
        return withComponentRoot(node, metricCard(slideId, name, `${stringValue(node.value, "")}${unit}`, stringValue(node.label, "")));
    }
    if (componentName === "callout") {
        const toneProps = tonePropsFrom(node.tone);
        const expanded = insightCallout(slideId, name, stringValue(node.text, ""));
        return withComponentRoot(node, { ...expanded, ...toneProps });
    }
    if (componentName === "comparison-card")
        return withComponentRoot(node, comparisonCard(slideId, name, stringValue(node.title, ""), comparisonPoints(node).slice(0, 6)));
    if (componentName === "step-card") {
        return withComponentRoot(node, stepCard(slideId, name, stringValue(node.step, stringValue(node.number, "")), stringValue(node.title, stringValue(node.label, "")), stringValue(node.body, stringValue(node.description, stringArray(node.steps).join("\n")))));
    }
    if (componentName === "article")
        return withComponentRoot(node, articleFallback(slideId, name, node));
    if (componentName === "definition-card")
        return withComponentRoot(node, definitionCard(slideId, name, stringValue(node.term, ""), stringValue(node.definition, "")));
    return withComponentRoot(node, { id: node.id, type: "stack", direction: "vertical", children: [] });
}
function primitiveComponentDescriptions() {
    return PRIMITIVE_COMPONENT_TYPES.map((type) => primitiveComponentDescription(type)).filter((item) => Boolean(item));
}
function primitiveComponentDescription(name) {
    const primitiveType = primitiveComponentType(name);
    if (!primitiveType)
        return null;
    const node = listNodeTypes().find((item) => item.type === primitiveType);
    if (!node)
        return null;
    return {
        name: primitiveType,
        purpose: node.use,
        fields: primitiveFields(primitiveType, node.fields),
        children: {
            allowed: Boolean(node.acceptsChildren?.length),
            accepts: node.acceptsChildren,
            required: primitiveType === "stack" || primitiveType === "grid",
        },
        examples: [primitiveExample(primitiveType)],
        layoutBehavior: primitiveLayoutBehavior(primitiveType),
        renderBehavior: {
            expandsTo: primitiveType,
            themeTokens: primitiveThemeTokens(primitiveType),
        },
    };
}
function primitiveComponentType(name) {
    return PRIMITIVE_COMPONENT_TYPES.includes(name) ? name : null;
}
function primitiveComponentNode(slideId, type, node) {
    const { component: _component, ...rest } = node;
    return {
        ...rest,
        id: node.id || `${slideId}.${type}`,
        type,
    };
}
function componentLocalId(slideId, id) {
    const prefix = `${slideId}.`;
    return id.startsWith(prefix) ? id.slice(prefix.length) : id;
}
function withComponentRoot(source, expanded) {
    return {
        ...expanded,
        ...layoutProps(source),
        id: source.id || expanded.id,
    };
}
function layoutProps(node) {
    const output = {};
    for (const key of [
        "area",
        "fixedWidth",
        "fixedHeight",
        "minWidth",
        "minHeight",
        "maxWidth",
        "maxHeight",
        "layoutWeight",
        "fill",
        "line",
        "padding",
        "role",
        "align",
        "valign",
    ]) {
        if (node[key] !== undefined)
            output[key] = node[key];
    }
    return output;
}
function primitiveFields(type, fields) {
    return Object.fromEntries(Object.entries(fields).map(([key, description]) => [
        key,
        {
            type: propTypeFromDescription(key, description),
            required: primitiveRequiredField(type, key),
            description,
        },
    ]));
}
function primitiveRequiredField(type, field) {
    if (type === "bullets")
        return field === "items";
    if (type === "image")
        return field === "src";
    if (type === "chart")
        return field === "chartType" || field === "labels" || field === "series";
    return false;
}
function propTypeFromDescription(field, description) {
    if (field === "src")
        return "image-ref";
    if (field === "rows" || field === "headers")
        return "table";
    if (field === "series" || field === "chartType" || field === "labels")
        return "chart";
    if (description.includes("number") || description.includes("cm") || description.includes("px"))
        return "number";
    if (description.includes("boolean"))
        return "boolean";
    if (description.includes("[]") || description.includes("array"))
        return "array";
    if (description.includes("|"))
        return "enum";
    if (description.includes("object"))
        return "object";
    return "string";
}
function primitiveExample(type) {
    if (type === "stack") {
        return {
            id: "example.stack",
            type: "component",
            component: "stack",
            direction: "vertical",
            gap: 12,
            children: [
                { id: "example.stack.text", type: "component", component: "text", text: "One key message" },
            ],
        };
    }
    if (type === "grid") {
        return {
            id: "example.grid",
            type: "component",
            component: "grid",
            columns: 2,
            gap: 12,
            children: [
                { id: "example.grid.left", type: "component", component: "callout", text: "Left insight" },
                { id: "example.grid.right", type: "component", component: "callout", text: "Right insight" },
            ],
        };
    }
    if (type === "spacer")
        return { id: "example.spacer", type: "component", component: "spacer", fixedHeight: 0.5 };
    if (type === "divider")
        return { id: "example.divider", type: "component", component: "divider", orientation: "horizontal" };
    if (type === "bullets")
        return { id: "example.bullets", type: "component", component: "bullets", items: ["Point one", "Point two"] };
    if (type === "image")
        return { id: "example.image", type: "component", component: "image", src: "/absolute/path/image.png", alt: "Image", caption: "Optional caption" };
    if (type === "table")
        return { id: "example.table", type: "component", component: "table", headers: ["A", "B"], rows: [["1", "2"]], caption: "Optional caption" };
    if (type === "chart")
        return { id: "example.chart", type: "component", component: "chart", chartType: "bar", labels: ["Q1", "Q2"], series: [{ name: "Revenue", values: [1, 2] }] };
    return { id: "example.shape", type: "component", component: "shape", preset: "rect", fill: "surface" };
}
function primitiveLayoutBehavior(type) {
    if (type === "stack" || type === "grid")
        return { intrinsicSize: "collection", canGrow: true };
    if (type === "image" || type === "chart")
        return { intrinsicSize: "media", canGrow: true, preferredParent: "grid" };
    if (type === "table")
        return { intrinsicSize: "collection", canGrow: true, preferredParent: "stack" };
    if (type === "spacer" || type === "divider" || type === "shape")
        return { intrinsicSize: "fill", canGrow: true };
    return { intrinsicSize: "text", canGrow: false, preferredParent: "stack" };
}
function primitiveThemeTokens(type) {
    if (type === "divider" || type === "shape")
        return ["surface", "divider", "brand.primary"];
    if (type === "table" || type === "chart")
        return ["text.primary", "text.muted", "brand.primary", "surface", "divider"];
    return ["text.primary", "text.muted"];
}
function component(name, purpose, fields, expandsTo, preferredParent) {
    return {
        name,
        category: "content",
        purpose,
        fields,
        children: { allowed: false },
        layoutBehavior: { intrinsicSize: "card", canGrow: true, preferredParent },
        renderBehavior: { expandsTo, themeTokens: ["surface", "divider", "brand.primary", "text.primary", "text.muted"] },
        examples: [{ type: "component", component: name, ...Object.fromEntries(Object.entries(fields).filter(([, prop]) => prop.required).map(([key]) => [key, key])) }],
    };
}
function textComponent(name, purpose, style, extraFields = {}) {
    return {
        name,
        category: "content",
        purpose,
        fields: {
            text: { type: "string", required: true, description: "Text content." },
            align: { type: "enum", enum: ["left", "center", "right"], description: "Optional alignment." },
            ...extraFields,
        },
        children: { allowed: false },
        layoutBehavior: { intrinsicSize: "text", canGrow: false, preferredParent: "stack" },
        renderBehavior: { expandsTo: `text.${style}`, themeTokens: ["text.primary", "text.muted", "brand.primary"] },
        examples: [{ type: "component", component: name, text: "Text" }],
    };
}
function articleComponent() {
    return {
        name: "article",
        category: "collection",
        purpose: "Flow one long article across as many slides as needed.",
        fields: {
            title: { type: "string", description: "Optional article title. Falls back to slide title." },
            text: { type: "string", description: "Full article text. Paragraphs may be separated by blank lines." },
            paragraphs: { type: "array", description: "Optional array of paragraph strings." },
            source: { type: "string", description: "Optional source note rendered on the last generated page." },
        },
        children: { allowed: false },
        layoutBehavior: { intrinsicSize: "collection", canGrow: true, preferredParent: "stack" },
        renderBehavior: { expandsTo: "multiple slides with internal text.article nodes", themeTokens: ["text.primary", "text.muted"] },
        examples: [{ type: "component", component: "article", title: "Reading Passage", paragraphs: ["Paragraph one.", "Paragraph two."], source: "Source note" }],
    };
}
function semanticTextStyle(componentName) {
    if (componentName === "deck-title")
        return "deck-title";
    if (componentName === "slide-title")
        return "slide-title";
    if (componentName === "h1")
        return "section-title";
    if (componentName === "h2")
        return "card-title";
    if (componentName === "lead")
        return "lead";
    if (componentName === "text")
        return "paragraph";
    if (componentName === "source-note")
        return "footnote";
    if (componentName === "label")
        return "label";
    if (componentName === "code")
        return "code";
    return "";
}
function articleFallback(slideId, name, node) {
    const paragraphs = articleParagraphs(node).slice(0, 3);
    return {
        id: `${slideId}.${name}.fallback`,
        type: "stack",
        direction: "vertical",
        gap: 9,
        children: paragraphs.map((text, index) => ({
            id: `${slideId}.${name}.p${index + 1}`,
            type: "text",
            text,
            style: "article",
        })),
    };
}
function articleParagraphs(node) {
    if (Array.isArray(node.paragraphs))
        return node.paragraphs.map(String).map((item) => item.trim()).filter(Boolean);
    if (typeof node.text === "string")
        return node.text.split(/\n\s*\n/g).map((item) => item.trim()).filter(Boolean);
    return [];
}
function textComponentNode(slideId, name, text, style, fields) {
    const caption = stringValue(fields.caption, "");
    const title = style === "code" ? stringValue(fields.title, stringValue(fields.language, "")) : "";
    const visualStyle = style === "label" && (fields.variant === "badge" || fields.variant === "tag") ? String(fields.variant) : style;
    if (!caption && !title) {
        return {
            id: `${slideId}.${name}`,
            type: "text",
            text,
            style: visualStyle,
            align: fields.align,
            color: fields.color || fields.tone,
            fixedHeight: fields.fixedHeight,
            layoutWeight: fields.layoutWeight,
        };
    }
    return {
        id: `${slideId}.${name}`,
        type: "stack",
        direction: "vertical",
        gap: 5,
        fixedHeight: fields.fixedHeight,
        layoutWeight: fields.layoutWeight,
        children: [
            ...(title ? [{
                    id: `${slideId}.${name}.title`,
                    type: "text",
                    text: title,
                    style: "card-title",
                    fixedHeight: 0.5,
                }] : []),
            {
                id: `${slideId}.${name}.text`,
                type: "text",
                text,
                style: visualStyle,
                align: fields.align,
                color: fields.color || fields.tone,
                layoutWeight: caption ? 1 : fields.layoutWeight,
            },
            ...(caption ? [{
                    id: `${slideId}.${name}.caption`,
                    type: "text",
                    text: caption,
                    style: "code-caption",
                    align: fields.align || "left",
                    fixedHeight: 0.42,
                }] : []),
        ],
    };
}
function definitionCard(slideId, name, term, definition) {
    return {
        id: `${slideId}.${name}`,
        type: "stack",
        direction: "vertical",
        gap: 7,
        role: "definition-card",
        fill: "surface",
        line: "divider",
        padding: 10,
        children: [
            { id: `${slideId}.${name}.term`, type: "text", text: term, style: "card-title", color: "brand.primary" },
            { id: `${slideId}.${name}.definition`, type: "text", text: definition, style: "paragraph" },
        ],
    };
}
function comparisonPoints(fields) {
    const points = stringArray(fields.points);
    if (points.length > 0)
        return points;
    const items = stringArray(fields.items);
    if (items.length > 0)
        return items;
    return [stringValue(fields.subtitle, ""), stringValue(fields.body, "")].filter(Boolean);
}
function tonePropsFrom(tone) {
    if (tone === "positive" || tone === "warning" || tone === "danger" || tone === "brand") {
        return { fill: `${tone}.tint`, line: tone, color: tone };
    }
    return {};
}
function stringValue(value, fallback) {
    return typeof value === "string" && value.trim() ? value.trim() : fallback;
}
function stringArray(value) {
    return Array.isArray(value) ? value.map(String).map((item) => item.trim()).filter(Boolean) : [];
}
