# SlideML2 MVP

SlideML2 is an isolated experiment. It is not registered in Cowork's tool
registry and is not mentioned in Cowork's system prompt.

The MVP validates one idea: a deck can be generated from a simple layout spec,
inspected as a semantic DOM, edited with semantic operations, audited, and
rendered to PPTX.

## Scope

Source documents stay small:

```json
{
  "slideml2": 1,
  "deck": {
    "theme": "simple",
    "brand": { "primary": "E60012", "logo": "/logo.png" }
  },
  "slides": [
    {
      "id": "cover",
      "layout": "cover",
      "props": {
        "title": "Youdao",
        "subtitle": "AI education"
      }
    }
  ]
}
```

SlideML2 v2 source slides use a semantic DOM with flat nodes:

```ts
{ id, type, children?, ...semanticFields }
```

There is no separate `name` field. `id` is the stable semantic identifier.
There is no `props` wrapper; component and layout fields live directly on the
node:

```json
{
  "id": "market.metrics",
  "type": "grid",
  "columns": 3,
  "gap": 12,
  "children": [
    {
      "id": "market.size",
      "type": "component",
      "component": "metric-card",
      "value": "500亿+",
      "label": "全球规模"
    }
  ]
}
```

## MVP Layouts

- `cover`
- `title-and-content`
- `image-and-text`

## MVP Node Types

- `slide`
- `stack`
- `grid`
- `text`
- `bullets`
- `image`
- `table`
- `chart`
- `shape`
- `component`

## Default Theme

SlideML2 has an unnamed default theme. When a deck does not request a named
theme, the renderer still receives a complete quality baseline:

- slide size and page margins
- title/content regions
- default gaps and card padding
- font families
- semantic text styles
- surface, divider, brand, and text colors

Agents can override layout parameters such as `direction`, `gap`,
`columnWeights`, `fixedHeight`, `minHeight`, and `layoutWeight`. The renderer
only infers missing values; explicit agent choices win.

## Text Semantics

Text semantics should be expressed as components when the distinction matters:

- `deck-title`
- `slide-title`
- `h1`
- `h2`
- `lead`
- `text`
- `source-note`

Primitive `text` nodes may use `style` internally after component expansion,
but agents should normally choose a semantic component instead of setting text
style fields directly. The renderer can still adjust the final size from the
node's depth and parent layout.

`slide-title` is the slide-level title slot and is usually generated from
`slide.title`; it is not the same thing as a content heading. Use `h1` for the
primary heading inside the slide content area, `h2` for a secondary heading
inside a group/panel/card, and `lead` for an introductory thesis sentence.

## Article Flow

`article` is not a text style. It is a cross-page flow component. Agents provide
one article node, and SlideML2 expands it into multiple rendered slides before
PPTX output:

```json
{
  "id": "reading.article",
  "type": "component",
  "component": "article",
  "title": "Reading Passage",
  "paragraphs": ["Paragraph one...", "Paragraph two..."],
  "source": "Source: demo"
}
```

Generated article pages contain internal `text` nodes with article styling. Use
the `text` component for normal single-slide explanatory copy; use `article` for a whole
reading passage or long source text that may need pagination.

## MVP Edit Ops

- `setSlideProp`
- `setNodeProp`
- `insertNode` with optional `first`, `last`, `before`, `after`, or numeric
  index placement
- `deleteNode`

## Component Layout Experiment

The MVP also includes a small component catalog. Components are just DOM node
factories, not a second rendering system. Primitive nodes remain separate from
components:

- use primitive nodes such as `image`, `table`, and `chart` when the requested
  content is direct
- use semantic components such as `text`, `source-note`, `label`, or `code`
  when text meaning matters
- use composite components such as `metric-card`, `callout`,
  `comparison-card`, `step-card`, and `definition-card` when a structured
  block is useful

The catalog avoids interchangeable names. Generic `caption`, `figure-caption`,
and `footnote` components are not exposed. Captions are optional properties on
`image`, `table`, and `chart`; standalone sources, citations, and disclaimers
use `source-note`.

This lets the isolated agent loop prove a second capability: starting from a
plain slide, it can delete a weak generated content region and insert a more
purposeful layout tree composed from semantic components.

## Markdown Planning Experiment

The markdown pipeline tests a fuller generation loop:

1. read markdown input
2. generate a page plan
3. generate SlideML2 JSON from the plan
4. render the deck to PPTX

The deterministic planner is the default for local tests. A real LLM planner is
available through `planPagesFromMarkdownWithLlm` and the CLI flag
`--markdown-llm`. It reads `LLM_API`, `LLM_API_KEY`, and `LLM_MODEL` from the
environment.

The real LLM test is intentionally opt-in because it requires network access:

```bash
RUN_SLIDEML2_REAL_LLM=1 pnpm --filter slideml2 test
```

Without that flag, `pnpm --filter slideml2 check` runs the local deterministic
suite and skips the network-dependent integration case.

## Progressive Agent Disclosure

SlideML2 should not fill an agent context with every component, theme, text
kind, and schema. Agents start with a compact guide and ask for details only
when needed:

1. `getAgentQuickStart()` returns the contract, primitives, and workflow.
2. `listAgentCapabilities()` returns indexes only: node names, component names,
   and theme names.
3. `selectComponentsForIntent(intent)` suggests a small component subset for
   the current page.
4. `describeAgentCapability(kind, name)` returns the full schema for a single
   node/component/text kind/theme.
5. `buildAgentPromptPack({ intent })` creates a compact per-slide prompt pack
   containing only relevant schemas.

The batch agent uses this path when generating a slide from an outline. The
planning call can see the markdown, but each slide-generation call only sees
the outline plus a small prompt pack. This keeps each LLM output small enough
to reduce malformed JSON and makes schema mistakes easier to validate and
repair through whole-slide replacement.

## Test Goal

The agent-loop test intentionally starts with a deck missing a brand-red cover
background, logo placement, and a business bullet list. A tiny deterministic
agent loop inspects/audits the DOM, applies semantic edits, re-renders, and
passes audit.
