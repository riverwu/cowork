import type { DomNode } from "./types.js";

export function titleText(slideId: string, id: string, text: string): DomNode {
  return { id: `${slideId}.${id}`, type: "slide-title", text, align: "left" };
}

export function paragraphText(slideId: string, id: string, text: string): DomNode {
  return { id: `${slideId}.${id}`, type: "text", text, align: "left", style: "paragraph" };
}

export function bulletList(slideId: string, id: string, items: string[], density: "comfortable" | "compact" = "comfortable"): DomNode {
  return { id: `${slideId}.${id}`, type: "bullets", items, density };
}

export function imageBlock(slideId: string, id: string, src: string, alt: string, fit: "cover" | "contain" | "fill" = "cover"): DomNode {
  return { id: `${slideId}.${id}`, type: "image", src, alt, fit };
}

export function imageWithCaptionPanel(slideId: string, imageSrc: string, imageTitle: string): DomNode {
  const image = { ...imageBlock(slideId, "brief-image", imageSrc, imageTitle, "contain"), caption: imageTitle };
  return {
    id: `${slideId}.visualPanel`,
    type: "stack",
    direction: "vertical",
    gap: 0.3,
    role: "image-with-caption",
    children: [
      { ...image, layoutWeight: 1, minHeight: 6.8 },
    ],
  };
}

export function metricCard(
  slideId: string,
  id: string,
  value: string,
  label: string,
  options: { unit?: string; trend?: "up" | "down" | "flat" } = {},
): DomNode {
  const trend = options.trend;
  const unit = options.unit && options.unit.trim() ? options.unit.trim() : "";
  const valueRow = trend || unit ? buildMetricValueRow(slideId, id, value, unit, trend) : {
    id: `${slideId}.${id}.value`,
    type: "text" as const,
    text: value,
    style: "metric-value",
    align: "center",
    valign: "bottom",
    layoutWeight: 2,
  };
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.15,
    role: "metric-card",
    children: [
      valueRow,
      { id: `${slideId}.${id}.label`, type: "text", text: label, style: "metric-label", align: "center", valign: "top", layoutWeight: 1 },
    ],
  };
}

function buildMetricValueRow(slideId: string, id: string, value: string, unit: string, trend?: "up" | "down" | "flat"): DomNode {
  const trendChar = trend === "up" ? "▲" : trend === "down" ? "▼" : trend === "flat" ? "■" : "";
  const trendColor = trend === "up" ? "success" : trend === "down" ? "danger" : trend === "flat" ? "text.muted" : undefined;
  const children: DomNode[] = [
    { id: `${slideId}.${id}.value`, type: "text", text: value, style: "metric-value", align: "right", valign: "bottom", layoutWeight: 5 },
  ];
  if (unit) {
    children.push({ id: `${slideId}.${id}.unit`, type: "text", text: unit, style: "metric-label", align: "left", valign: "bottom", layoutWeight: 2 });
  }
  if (trendChar) {
    children.push({ id: `${slideId}.${id}.trend`, type: "text", text: trendChar, style: "card-title", color: trendColor, align: "left", valign: "middle", layoutWeight: 1, fixedWidth: 0.7 });
  }
  return {
    id: `${slideId}.${id}.value-row`,
    type: "stack",
    direction: "horizontal",
    gap: 0.15,
    layoutWeight: 2,
    align: "center",
    valign: "bottom",
    children,
  };
}

export function stepCard(slideId: string, id: string, step: string, title: string, body: string): DomNode {
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.25,
    role: "step-card",
    children: [
      { id: `${slideId}.${id}.step`, type: "text", text: step, style: "numbered-step", color: "brand.primary", fixedHeight: 0.55 },
      { id: `${slideId}.${id}.title`, type: "text", text: title, style: "card-title", fixedHeight: 0.9 },
      { id: `${slideId}.${id}.body`, type: "text", text: body, style: "caption", valign: "top" },
    ],
  };
}

export function comparisonCard(slideId: string, id: string, title: string, points: string[]): DomNode {
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.25,
    role: "comparison-card",
    children: [
      { id: `${slideId}.${id}.title`, type: "text", text: title, style: "card-title", color: "brand.primary", fixedHeight: 0.85 },
      bulletList(slideId, `${id}-points`, points, "compact"),
    ],
  };
}

export function insightCallout(slideId: string, id: string, text: string): DomNode {
  return { id: `${slideId}.${id}`, type: "text", text, style: "callout", role: "callout", fixedHeight: 1.45 };
}

export function numberedList(slideId: string, id: string, items: string[], density: "comfortable" | "compact" = "comfortable"): DomNode {
  return { id: `${slideId}.${id}`, type: "bullets", items, density, numbered: true };
}

export function quoteBlock(slideId: string, id: string, text: string, source?: string): DomNode {
  const children: DomNode[] = [
    { id: `${slideId}.${id}.text`, type: "text", text: `\u201C${text}\u201D`, style: "quote", align: "left", valign: "middle" },
  ];
  if (source && source.trim()) {
    children.push({ id: `${slideId}.${id}.source`, type: "text", text: `\u2014 ${source.trim()}`, style: "quote-source", align: "left", fixedHeight: 0.6 });
  }
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.3,
    role: "quote",
    children,
  };
}

export function iconText(slideId: string, id: string, options: { icon: string; text: string; iconColor?: string; iconBackground?: string; tone?: string }): DomNode {
  const iconPreset = options.icon || "ellipse";
  const iconColor = options.iconColor || "brand.primary";
  const iconBackground = options.iconBackground || "brand.tint";
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "horizontal",
    gap: 0.4,
    role: "icon-text",
    align: "start",
    valign: "middle",
    children: [
      {
        id: `${slideId}.${id}.icon`,
        type: "shape",
        preset: iconPreset,
        fill: iconBackground,
        line: iconColor,
        fixedWidth: 1.15,
        fixedHeight: 1.15,
      },
      { id: `${slideId}.${id}.text`, type: "text", text: options.text, style: "card-title", align: "left", valign: "middle", color: options.tone || "text.primary" },
    ],
  };
}

export function timelineBlock(slideId: string, id: string, options: {
  items: Array<{ time?: string; title: string; body?: string }>;
  direction?: "horizontal" | "vertical";
}): DomNode {
  const direction = options.direction === "horizontal" ? "horizontal" : "vertical";
  if (direction === "horizontal") {
    return {
      id: `${slideId}.${id}`,
      type: "grid",
      columns: Math.max(1, options.items.length),
      gap: 0.4,
      role: "timeline",
      children: options.items.map((item, index) => timelineStep(slideId, id, index, item, "horizontal")),
    };
  }
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.35,
    role: "timeline",
    children: options.items.map((item, index) => timelineStep(slideId, id, index, item, "vertical")),
  };
}

function timelineStep(slideId: string, id: string, index: number, item: { time?: string; title: string; body?: string }, direction: "horizontal" | "vertical"): DomNode {
  const headerStyle = direction === "horizontal" ? "card-title" : "card-title";
  const children: DomNode[] = [];
  if (item.time && item.time.trim()) {
    children.push({ id: `${slideId}.${id}.${index}.time`, type: "text", text: item.time.trim(), style: "label", color: "brand.primary", fixedHeight: 0.55 });
  }
  children.push({ id: `${slideId}.${id}.${index}.title`, type: "text", text: item.title, style: headerStyle, fixedHeight: 0.85 });
  if (item.body && item.body.trim()) {
    children.push({ id: `${slideId}.${id}.${index}.body`, type: "text", text: item.body.trim(), style: "caption", valign: "top" });
  }
  return {
    id: `${slideId}.${id}.${index}`,
    type: "stack",
    direction: "vertical",
    gap: 0.18,
    role: "timeline-step",
    children,
  };
}

export function profileCard(slideId: string, id: string, options: { image: string; name: string; role?: string; bio?: string }): DomNode {
  const children: DomNode[] = [
    { id: `${slideId}.${id}.photo`, type: "image", src: options.image, alt: options.name, clip: "circle", fit: "cover", fixedWidth: 2.8, fixedHeight: 2.8 },
    { id: `${slideId}.${id}.name`, type: "text", text: options.name, style: "card-title", align: "center", fixedHeight: 0.85 },
  ];
  if (options.role && options.role.trim()) {
    children.push({ id: `${slideId}.${id}.role`, type: "text", text: options.role.trim(), style: "label", color: "brand.primary", align: "center", fixedHeight: 0.55 });
  }
  if (options.bio && options.bio.trim()) {
    children.push({ id: `${slideId}.${id}.bio`, type: "text", text: options.bio.trim(), style: "caption", align: "center", valign: "top" });
  }
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.25,
    role: "profile-card",
    align: "center",
    children,
  };
}

export function kpiGrid(slideId: string, id: string, metrics: Array<{ name?: string; value: string; label: string; unit?: string; trend?: "up" | "down" | "flat" }>, columns?: number): DomNode {
  const cols = Math.max(1, columns || Math.min(4, metrics.length));
  return {
    id: `${slideId}.${id}`,
    type: "grid",
    columns: cols,
    gap: 0.5,
    role: "kpi-grid",
    children: metrics.map((m, index) => metricCard(slideId, m.name || `${id}-m${index + 1}`, m.value, m.label, { unit: m.unit, trend: m.trend })),
  };
}

export function sectionBreak(slideId: string, id: string, options: { title: string; subtitle?: string; accent?: string }): DomNode {
  const children: DomNode[] = [];
  if (options.accent && options.accent.trim()) {
    children.push({ id: `${slideId}.${id}.accent`, type: "text", text: options.accent.trim(), style: "label", color: "brand.primary", align: "left", fixedHeight: 0.6 });
  }
  children.push({ id: `${slideId}.${id}.title`, type: "text", text: options.title, style: "deck-title", align: "left", color: "text.primary" });
  if (options.subtitle && options.subtitle.trim()) {
    children.push({ id: `${slideId}.${id}.subtitle`, type: "text", text: options.subtitle.trim(), style: "lead", align: "left", color: "text.muted" });
  }
  return {
    id: `${slideId}.${id}`,
    type: "stack",
    direction: "vertical",
    gap: 0.4,
    role: "section-break",
    area: "content",
    valign: "middle",
    align: "start",
    children,
  };
}

export function swotMatrix(slideId: string, id: string, options: { strengths: string[]; weaknesses: string[]; opportunities: string[]; threats: string[] }): DomNode {
  const quadrant = (qid: string, title: string, points: string[], color: string) => ({
    id: `${slideId}.${id}.${qid}`,
    type: "stack" as const,
    direction: "vertical" as const,
    gap: 0.22,
    role: "swot-quadrant",
    children: [
      { id: `${slideId}.${id}.${qid}.title`, type: "text" as const, text: title, style: "card-title", color, fixedHeight: 0.7 },
      bulletList(slideId, `${id}-${qid}`, points, "compact"),
    ],
  });
  return {
    id: `${slideId}.${id}`,
    type: "grid",
    columns: 2,
    gap: 0.5,
    role: "swot-matrix",
    children: [
      quadrant("strengths", "Strengths", options.strengths, "success"),
      quadrant("weaknesses", "Weaknesses", options.weaknesses, "warning"),
      quadrant("opportunities", "Opportunities", options.opportunities, "brand.primary"),
      quadrant("threats", "Threats", options.threats, "danger"),
    ],
  };
}

export function ctaButton(slideId: string, id: string, options: { text: string; tone?: "brand" | "neutral" | "positive" | "warning" | "danger"; link?: string }): DomNode {
  const tone = options.tone || "brand";
  const fill = tone === "neutral" ? "surface" : tone === "brand" ? "brand.primary" : tone;
  const fg = tone === "neutral" ? "text.primary" : "text.inverse";
  const content = options.link
    ? [{ text: options.text, link: options.link }]
    : undefined;
  return {
    id: `${slideId}.${id}`,
    type: "text",
    text: options.text,
    style: "card-title",
    align: "center",
    valign: "middle",
    fill,
    color: fg,
    cornerRadius: 0.3,
    fixedHeight: 1.15,
    role: "cta",
    ...(content ? { content } : {}),
  };
}

export function companyOverviewLayout(options: {
  slideId: string;
  visualSrc: string;
  summary: string;
  businessLines: string[];
  metrics: Array<{ name: string; value: string; label: string }>;
}): DomNode {
  return {
    id: `${options.slideId}.overviewLayout`,
    type: "grid",
    area: "content",
    columns: 2,
    gap: 0.55,
    role: "company-overview-layout",
    children: [
      {
        id: `${options.slideId}.narrativeColumn`,
        type: "stack",
        direction: "vertical",
        gap: 0.3,
        children: [
          paragraphText(options.slideId, "company-summary", options.summary),
          bulletList(options.slideId, "business-lines", options.businessLines, "compact"),
        ],
      },
      {
        id: `${options.slideId}.visualColumn`,
        type: "stack",
        direction: "vertical",
        gap: 0.35,
        children: [
          imageBlock(options.slideId, "hero-visual", options.visualSrc, "Company visual", "cover"),
          {
            id: `${options.slideId}.metricGrid`,
            type: "grid",
            columns: 3,
            gap: 0.25,
            children: options.metrics.map((metric) => metricCard(options.slideId, metric.name, metric.value, metric.label)),
          },
        ],
      },
    ],
  };
}
