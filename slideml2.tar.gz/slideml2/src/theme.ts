import type { BrandSpec } from "./types.js";

export interface SimpleTheme {
  name: string;
  colors: Record<string, string>;
  text: Record<string, TextStyle>;
  component: Record<string, ComponentStyle>;
  tone: Record<string, { fg: string; bg: string; line: string }>;
  fontFace: string;
  fonts: {
    latin: string[];
    cjk: string[];
    mono: string[];
  };
  layout: {
    slideWidthCm: number;
    slideHeightCm: number;
    pageMarginX: number;
    titleTop: number;
    titleHeight: number;
    contentTop: number;
    contentBottom: number;
    defaultGap: number;
    columnGap: number;
    cardPadding: number;
  };
  chart: {
    series: string[];
  };
  chrome: {
    brandMark: "none" | "top-right" | "bottom-right";
    pageNumber: boolean;
    footerLine: boolean;
    footerHeight: number;
    footerPadding: number;
  };
  imageGrowWeight: number;
}

export interface TextStyle {
  fontSize: number;
  weight?: "normal" | "bold";
  color: string;
  lineHeight: number;
  margin?: { l?: number; r?: number; t?: number; b?: number };
}

export interface ComponentStyle {
  fill?: string;
  line?: string;
  accent?: string;
  padding?: number;
  radius?: number;
}

export type ThemeFactory = (brandPrimary: string) => SimpleTheme;

const themeRegistry: Map<string, ThemeFactory> = new Map();

export function registerTheme(name: string, factory: ThemeFactory): void {
  themeRegistry.set(name, factory);
}

export function listThemes(): string[] {
  return Array.from(themeRegistry.keys()).filter((name) => name !== "simple");
}

export function listColorWarnings(): string[] {
  return Array.from(colorWarnings);
}

export function clearColorWarnings(): void {
  colorWarnings.clear();
}

const colorWarnings = new Set<string>();

export function buildTheme(brand: BrandSpec = {}, themeName = "default"): SimpleTheme {
  const brandPrimary = normalizeHex(brand.primary || "2563EB");
  const factory = themeRegistry.get(themeName) || themeRegistry.get("default")!;
  const theme = factory(brandPrimary);
  return {
    ...theme,
    colors: {
      ...theme.colors,
      ...derivedBrandPalette(brandPrimary),
    },
  };
}

export function textStyle(theme: SimpleTheme, kindOrVariant: unknown, fallback = "paragraph"): TextStyle {
  const key = typeof kindOrVariant === "string" && kindOrVariant.trim() ? kindOrVariant.trim() : fallback;
  return theme.text[key] || theme.text[fallback] || theme.text.paragraph;
}

export function color(theme: SimpleTheme, value: unknown, fallback = "text.primary"): string {
  const raw = typeof value === "string" && value.trim() ? value.trim() : fallback;
  if (/^[0-9A-Fa-f]{6}$/.test(raw)) return raw.toUpperCase();
  if (theme.colors[raw]) return theme.colors[raw]!;
  if (raw !== fallback) colorWarnings.add(raw);
  return theme.colors[fallback] || "111827";
}

function commonText(): Record<string, TextStyle> {
  return {
    "deck-title": { fontSize: 44, weight: "bold", color: "text.inverse", lineHeight: 1.1 },
    "slide-title": { fontSize: 30, weight: "bold", color: "text.primary", lineHeight: 1.14 },
    "section-title": { fontSize: 22, weight: "bold", color: "text.primary", lineHeight: 1.18 },
    "card-title": { fontSize: 15, weight: "bold", color: "text.primary", lineHeight: 1.2 },
    label: { fontSize: 10, color: "text.muted", lineHeight: 1.16 },
    lead: { fontSize: 17, color: "text.primary", lineHeight: 1.32 },
    paragraph: { fontSize: 13.5, color: "text.primary", lineHeight: 1.36 },
    article: { fontSize: 13, color: "text.primary", lineHeight: 1.42 },
    caption: { fontSize: 10, color: "text.muted", lineHeight: 1.26 },
    "figure-caption": { fontSize: 10.5, color: "text.muted", lineHeight: 1.28 },
    footnote: { fontSize: 9.5, color: "text.muted", lineHeight: 1.2 },
    bullet: { fontSize: 13.5, color: "text.primary", lineHeight: 1.34 },
    "bullet-compact": { fontSize: 12, color: "text.primary", lineHeight: 1.24 },
    "numbered-step": { fontSize: 11, weight: "bold", color: "brand.primary", lineHeight: 1.0 },
    "metric-value": { fontSize: 30, weight: "bold", color: "brand.primary", lineHeight: 1.0 },
    "metric-label": { fontSize: 11.5, color: "text.muted", lineHeight: 1.2 },
    "table-header": { fontSize: 11, weight: "bold", color: "text.primary", lineHeight: 1.18 },
    "table-cell": { fontSize: 10.5, color: "text.primary", lineHeight: 1.24 },
    "axis-label": { fontSize: 9.5, color: "text.muted", lineHeight: 1.0 },
    "legend-label": { fontSize: 10, color: "text.muted", lineHeight: 1.0 },
    callout: { fontSize: 16, color: "brand.primary", lineHeight: 1.28 },
    quote: { fontSize: 22, color: "text.primary", lineHeight: 1.36 },
    "quote-source": { fontSize: 11, color: "text.muted", lineHeight: 1.24 },
    badge: { fontSize: 10, weight: "bold", color: "brand.primary", lineHeight: 1.0 },
    tag: { fontSize: 10, color: "text.muted", lineHeight: 1.0 },
    code: { fontSize: 11.5, color: "text.primary", lineHeight: 1.28 },
    "code-caption": { fontSize: 10, color: "text.muted", lineHeight: 1.22 },
    hero: { fontSize: 46, weight: "bold", color: "text.inverse", lineHeight: 1.08 },
    title: { fontSize: 32, weight: "bold", color: "text.primary", lineHeight: 1.14 },
    body: { fontSize: 18, color: "text.primary", lineHeight: 1.36 },
  };
}

function defaultBase(brandPrimary: string): SimpleTheme {
  return {
    name: "default",
    colors: {
      "brand.primary": brandPrimary,
      background: "FFFFFF",
      surface: "F8FAFC",
      "surface.subtle": "F1F5F9",
      "brand.tint": "EFF6FF",
      "text.primary": "111827",
      "text.inverse": "FFFFFF",
      "text.muted": "64748B",
      divider: "E2E8F0",
      success: "15803D",
      "success.tint": "ECFDF3",
      warning: "B45309",
      "warning.tint": "FFFBEB",
      danger: "B91C1C",
      "danger.tint": "FEF2F2",
    },
    text: commonText(),
    component: {
      "metric-card": { fill: "surface", line: "divider", padding: 0.3, radius: 0.06 },
      callout: { fill: "brand.tint", line: "divider", accent: "brand.primary", padding: 0.5, radius: 0.06 },
      "comparison-card": { fill: "surface", line: "divider", padding: 0.45, radius: 0.06 },
      "step-card": { fill: "surface", line: "divider", padding: 0.45, radius: 0.06 },
      "definition-card": { fill: "surface", line: "divider", padding: 0.5, radius: 0.08 },
      quote: { fill: "surface.subtle", line: "divider", padding: 0.6, radius: 0.08 },
      "timeline-step": { fill: "surface", line: "divider", padding: 0.4, radius: 0.06 },
      "profile-card": { fill: "surface", line: "divider", padding: 0.4, radius: 0.08 },
      "swot-quadrant": { fill: "surface", line: "divider", padding: 0.45, radius: 0.06 },
      cta: { fill: "brand.primary", padding: 0.35, radius: 0.3 },
      "icon-text": { padding: 0 },
      "section-break": { padding: 0 },
      "kpi-grid": { padding: 0 },
      timeline: { padding: 0 },
      "swot-matrix": { padding: 0 },
    },
    tone: {
      neutral: { fg: "text.primary", bg: "surface", line: "divider" },
      positive: { fg: "success", bg: "success.tint", line: "success" },
      warning: { fg: "warning", bg: "warning.tint", line: "warning" },
      danger: { fg: "danger", bg: "danger.tint", line: "danger" },
      brand: { fg: "brand.primary", bg: "brand.tint", line: "brand.primary" },
    },
    fonts: {
      latin: ["Aptos", "Calibri", "Arial"],
      cjk: ["PingFang SC", "Microsoft YaHei", "SimHei"],
      mono: ["Menlo", "Consolas", "Courier New"],
    },
    fontFace: "Aptos",
    layout: {
      slideWidthCm: 25.4,
      slideHeightCm: 14.2875,
      pageMarginX: 1.6,
      titleTop: 0.85,
      titleHeight: 1.2,
      contentTop: 2.45,
      contentBottom: 0.95,
      defaultGap: 0.5,
      columnGap: 0.75,
      cardPadding: 0.45,
    },
    chart: {
      series: ["brand.primary", "brand.primary.shade", "brand.primary.tint", "success", "warning", "danger"],
    },
    chrome: {
      brandMark: "none",
      pageNumber: false,
      footerLine: false,
      footerHeight: 0.55,
      footerPadding: 0.5,
    },
    imageGrowWeight: 2,
  };
}

function enterpriseLight(brandPrimary: string): SimpleTheme {
  const base = defaultBase(brandPrimary);
  return {
    ...base,
    name: "enterprise-light",
    colors: {
      ...base.colors,
      background: "FFFFFF",
      surface: "F8FAFC",
      "surface.subtle": "F1F5F9",
      "brand.tint": "EEF4FF",
      "text.primary": "0F172A",
      "text.muted": "64748B",
      divider: "CBD5E1",
    },
    chrome: { ...base.chrome, brandMark: "bottom-right", pageNumber: true, footerLine: true },
  };
}

function technicalBlue(brandPrimary: string): SimpleTheme {
  const base = defaultBase(brandPrimary);
  const common = commonText();
  return {
    ...base,
    name: "technical-blue",
    colors: {
      ...base.colors,
      background: "F7FBFF",
      surface: "FFFFFF",
      "surface.subtle": "EAF3FF",
      "brand.tint": "E0F2FE",
      "text.primary": "102033",
      "text.muted": "52677F",
      divider: "B9D7F3",
    },
    text: {
      ...common,
      "slide-title": { ...common["slide-title"], color: "brand.primary" },
      "section-title": { ...common["section-title"], color: "brand.primary" },
      "metric-value": { ...common["metric-value"], fontSize: 32 },
    },
    chrome: { ...base.chrome, brandMark: "bottom-right", pageNumber: true, footerLine: true },
  };
}

registerTheme("default", defaultBase);
registerTheme("enterprise-light", enterpriseLight);
registerTheme("technical-blue", technicalBlue);
registerTheme("simple", defaultBase);

function normalizeHex(value: string): string {
  const cleaned = value.replace(/^#/, "");
  return /^[0-9A-Fa-f]{6}$/.test(cleaned) ? cleaned.toUpperCase() : "2563EB";
}

function derivedBrandPalette(primary: string): Record<string, string> {
  const tint = mixHex(primary, "FFFFFF", 0.85);
  const shade = mixHex(primary, "000000", 0.75);
  return {
    "brand.primary": primary,
    "brand.primary.tint": tint,
    "brand.primary.shade": shade,
  };
}

function mixHex(a: string, b: string, weight: number): string {
  const hex = (input: string) => [parseInt(input.slice(0, 2), 16), parseInt(input.slice(2, 4), 16), parseInt(input.slice(4, 6), 16)] as const;
  const [ar, ag, ab] = hex(a);
  const [br, bg, bb] = hex(b);
  const blend = (x: number, y: number) => Math.round(x * weight + y * (1 - weight));
  const toHex = (n: number) => Math.max(0, Math.min(255, n)).toString(16).padStart(2, "0").toUpperCase();
  return `${toHex(blend(ar, br))}${toHex(blend(ag, bg))}${toHex(blend(ab, bb))}`;
}

export function fontFamilyChain(theme: SimpleTheme, kind: "latin" | "cjk" | "mono"): string {
  return theme.fonts[kind].join(", ");
}

export function preferredFont(theme: SimpleTheme, kind: "latin" | "cjk" | "mono"): string {
  return theme.fonts[kind][0] || theme.fontFace;
}
