import { mkdtemp, readFile, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { describe, expect, it } from "vitest";
import {
  applyEdits,
  auditDeck,
  buildDom,
  buildAgentPromptPack,
  companyOverviewLayout,
  appendSlide,
  createDeck,
  createSourceDeck,
  deckFromComponentPlan,
  deleteSlide,
  describeComponents,
  describeDeck,
  designComplexDeck,
  designDeckFromBrief,
  describeNodeType,
  findNodeForTest,
  generateDeckWithBatchAgent,
  generateOneSlideWithLlm,
  generateFromMarkdown,
  generateWithComponentAgent,
  insertSlide,
  listNodeTypesForTest,
  listComponents,
  listTextKinds,
  listThemes,
  measureDeck,
  planPagesFromMarkdown,
  planPagesFromMarkdownWithLlm,
  renderToAst,
  renderToPptx,
  replaceSlide,
  runSimpleAgentLoop,
  setDeckProps,
  sourceToRenderedDeck,
  validateDeck,
  validateDeckPath,
  validateSlide,
  type AgentTask,
  type Slideml2Deck,
} from "./test-support.js";

const runRealLlmTest = process.env.RUN_SLIDEML2_REAL_LLM === "1" && process.env.LLM_API && process.env.LLM_API_KEY && process.env.LLM_MODEL;

describe("slideml2 MVP", () => {
  it("describes the available semantic node types", () => {
    expect(listNodeTypesForTest().map((item) => item.type)).toEqual(["slide", "stack", "grid", "spacer", "divider", "text", "bullets", "image", "table", "chart", "shape", "component"]);
    expect(describeNodeType("bullets").fields.items).toContain("string[]");
  });

  it("builds semantic DOM from simple layout specs", () => {
    const deck = buildDom(sampleSource());
    const cover = deck.slides.find((slide) => slide.id === "cover");
    expect(cover?.dom.id).toBe("cover.root");
    expect(findNodeForTest(cover!.dom, "cover.title")?.text).toBe("Youdao Company");
    expect(findNodeForTest(cover!.dom, "cover.brandLogo")?.position).toBe("top-right");
  });

  it("applies the four primitive edit operations to the DOM", () => {
    const deck = buildDom(sampleSource());
    const edited = applyEdits(deck, [
      { op: "setSlideProp", slideId: "cover", prop: "background", value: "brand.primary" },
      { op: "setNodeProp", slideId: "cover", nodeName: "cover.brandLogo", prop: "position", value: "bottom-right" },
      {
        op: "insertNode",
        slideId: "business",
        parentName: "business.content",
        node: {
          id: "business.businessLines",
          type: "bullets",
          items: ["Learning services", "Smart devices"],
          density: "compact",
        },
      },
      { op: "deleteNode", slideId: "business", nodeName: "business.bullets" },
    ]);

    expect(edited.slides.find((slide) => slide.id === "cover")?.dom.background).toBe("brand.primary");
    expect(findNodeForTest(edited.slides[0]!.dom, "cover.brandLogo")?.position).toBe("bottom-right");
    expect(findNodeForTest(edited.slides[1]!.dom, "business.businessLines")?.items).toHaveLength(2);
    expect(findNodeForTest(edited.slides[1]!.dom, "business.bullets")).toBeNull();
  });

  it("edits text, bullets, images, containers, and nested node order in one slide", () => {
    const deck = buildDom(sampleSource());
    const edited = applyEdits(deck, [
      { op: "setNodeProp", slideId: "business", nodeName: "business.title", prop: "text", value: "Updated business model" },
      { op: "setNodeProp", slideId: "business", nodeName: "business.bullets", prop: "items", value: ["Learning services", "Smart hardware", "Marketing"] },
      { op: "setNodeProp", slideId: "business", nodeName: "business.content", prop: "gap", value: 8 },
      {
        op: "insertNode",
        slideId: "business",
        parentName: "business.content",
        position: "first",
        node: { id: "business.lead", type: "text", text: "Three engines support growth.", style: "body" },
      },
      {
        op: "insertNode",
        slideId: "business",
        parentName: "business.content",
        position: { after: "business.bullets" },
        node: { id: "business.productImage", type: "image", src: sampleLogo(), alt: "Product", fit: "contain" },
      },
    ]);

    const content = findNodeForTest(edited.slides[1]!.dom, "business.content");
    expect(findNodeForTest(edited.slides[1]!.dom, "business.title")?.text).toBe("Updated business model");
    expect(findNodeForTest(edited.slides[1]!.dom, "business.bullets")?.items).toHaveLength(3);
    expect(findNodeForTest(edited.slides[1]!.dom, "business.productImage")?.fit).toBe("contain");
    expect(content?.gap).toBe(8);
    expect(content?.children?.map((node) => node.id)).toEqual(["business.lead", "business.bullets", "business.productImage"]);
  });

  it("builds a reasonable page layout directly from semantic components", () => {
    const layout = companyOverviewLayout({
      slideId: "overview",
      visualSrc: sampleLogo(),
      summary: "A concise company overview.",
      businessLines: ["Learning services", "Smart devices", "Online marketing"],
      metrics: [
        { name: "metric-revenue", value: "56.3亿", label: "2024 revenue" },
        { name: "metric-profit", value: "首次", label: "Annual profit" },
        { name: "metric-users", value: "2.8亿+", label: "Monthly active users" },
      ],
    });

    expect(layout.type).toBe("grid");
    expect(layout.columns).toBe(2);
    expect(layout.children?.map((node) => node.id)).toEqual(["overview.narrativeColumn", "overview.visualColumn"]);
    const metricGrid = findNodeForTest(layout, "overview.metricGrid");
    expect(metricGrid?.columns).toBe(3);
    expect(metricGrid?.children?.map((node) => node.role)).toEqual(["metric-card", "metric-card", "metric-card"]);
  });

  it("lets the simple agent replace a weak content region with a component-designed layout", () => {
    const source = sampleSource();
    source.slides.push({ id: "overview", layout: "title-and-content", title: "Company overview", items: ["Too generic"] });
    const initial = buildDom(source);
    const task: AgentTask = { requireCompanyOverviewLayout: { slideId: "overview" } };
    expect(auditDeck(initial, task).ok).toBe(false);

    const result = runSimpleAgentLoop(initial, task);
    const overviewSlide = result.deck.slides.find((slide) => slide.id === "overview")!;
    const rootChildren = overviewSlide.dom.children?.map((node) => node.id);
    expect(auditDeck(result.deck, task).ok).toBe(true);
    expect(result.appliedOps.map((op) => op.op)).toEqual(expect.arrayContaining(["deleteNode", "insertNode"]));
    expect(rootChildren).toEqual(["overview.title", "overview.overviewLayout", "overview.brandLogo"]);
    expect(findNodeForTest(overviewSlide.dom, "overview.metricGrid")?.columns).toBe(3);
  });

  it("designs a correct title, paragraph, image, and caption page from a brief", async () => {
    const deck = designDeckFromBrief(
      { name: "Youdao", primary: "E8382C", logo: sampleLogo() },
      {
        slideId: "brief",
        title: "有道智能学习业务",
        body: "有道围绕学习服务、智能硬件和在线营销构建业务组合，依托教育大模型和网易生态提升产品体验。",
        imageSrc: sampleLogo(),
        imageTitle: "有道品牌与智能学习产品",
      },
    );
    const slide = deck.slides[0]!;
    const rootChildren = slide.dom.children?.map((node) => node.id);
    expect(rootChildren).toEqual(["brief.slide-title", "brief.contentLayout"]);
    expect(findNodeForTest(slide.dom, "brief.contentLayout")?.columnWeights).toEqual([0.54, 0.46]);
    expect(findNodeForTest(slide.dom, "brief.visualPanel")?.role).toBe("image-with-caption");
    expect(findNodeForTest(slide.dom, "brief.brief-image")?.fit).toBe("contain");

    const measured = measureDeck(deck)[0]!.nodes;
    const title = rectOf(measured, "brief.slide-title");
    const body = rectOf(measured, "brief.body-text");
    const image = rectOf(measured, "brief.brief-image");
    const caption = rectOf(measured, "brief.brief-image.caption");
    expect(title.y).toBeLessThan(body.y);
    expect(body.x).toBeLessThan(image.x);
    expect(image.y).toBeCloseTo(body.y, 1);
    expect(caption.y).toBeGreaterThan(image.y + image.h);
    expect(caption.x).toBeCloseTo(image.x, 1);
    expect(caption.w).toBeCloseTo(image.w, 1);
    expect(body.w).toBeGreaterThan(10);
    expect(body.h).toBeLessThan(4);
    expect(image.w).toBeGreaterThan(8);
    expect(image.h).toBeGreaterThan(7);
    expect(caption.h).toBeGreaterThan(0.6);
    expect(caption.y + caption.h).toBeLessThan(13.55);
    expect(overlaps(body, image)).toBe(false);
    expect(overlaps(image, caption)).toBe(false);

    const dir = await mkdtemp(join(tmpdir(), "slideml2-brief-"));
    const rendered = await renderToPptx(deck, join(dir, "brief-layout.pptx"));
    expect((await stat(rendered.outputPath)).size).toBeGreaterThan(1000);
  });

  it("keeps emitted shapes inside the actual PPTX 16x9 page bounds", () => {
    const deck = designDeckFromBrief(
      { name: "Youdao", primary: "E8382C", logo: sampleLogo() },
      {
        slideId: "brief",
        title: "有道智能学习业务",
        body: "有道围绕学习服务、智能硬件和在线营销构建业务组合，依托教育大模型和网易生态提升产品体验。",
        imageSrc: sampleLogo(),
        imageTitle: "有道品牌与智能学习产品",
      },
    );
    const ast = renderToAst(deck);
    const slideWidth = 9_144_000;
    const slideHeight = 5_143_500;
    for (const shape of ast.slides[0]!.shapes) {
      expect(shape.xfrm.x, shape.name).toBeGreaterThanOrEqual(0);
      expect(shape.xfrm.y, shape.name).toBeGreaterThanOrEqual(0);
      expect(shape.xfrm.x + shape.xfrm.cx, shape.name).toBeLessThanOrEqual(slideWidth);
      expect(shape.xfrm.y + shape.xfrm.cy, shape.name).toBeLessThanOrEqual(slideHeight);
    }
  });

  it("uses kind semantics from the default theme for text styling", () => {
    const deck = designDeckFromBrief(
      { name: "Youdao", primary: "E8382C", logo: sampleLogo() },
      {
        slideId: "brief",
        title: "有道智能学习业务",
        body: "有道围绕学习服务、智能硬件和在线营销构建业务组合，依托教育大模型和网易生态提升产品体验。",
        imageSrc: sampleLogo(),
        imageTitle: "有道品牌与智能学习产品",
      },
    );
    const ast = renderToAst(deck);
    const title = ast.slides[0]!.shapes.find((shape) => shape.name === "brief.slide-title");
    const body = ast.slides[0]!.shapes.find((shape) => shape.name === "brief.body-text");
    const caption = ast.slides[0]!.shapes.find((shape) => shape.name === "brief.brief-image.caption");
    expect(title?.type).toBe("text");
    expect(body?.type).toBe("text");
    expect(caption?.type).toBe("text");
    if (title?.type !== "text" || body?.type !== "text" || caption?.type !== "text") throw new Error("Expected text shapes");
    expect(title.paragraphs[0]!.runs[0]!.sizeHalfPt).toBe(60);
    expect(body.paragraphs[0]!.runs[0]!.sizeHalfPt).toBe(27);
    expect(caption.paragraphs[0]!.runs[0]!.sizeHalfPt).toBe(21);
  });

  it("prefers explicit layout props and uses default theme only when omitted", () => {
    const deck = {
      deck: { size: "16x9" as const, theme: "simple", brand: { primary: "E8382C" } },
      slides: [{
        id: "explicit",
        layout: "title-and-content" as const,
        dom: {
          id: "explicit.root",
          type: "slide" as const,
          background: "background",
          children: [{
            id: "explicit.stack",
            type: "stack" as const,
            area: "content",
            direction: "horizontal",
            gap: 1,
            children: [
              { id: "explicit.a", type: "text" as const, text: "左侧", style: "paragraph", fixedWidth: 4, fixedHeight: 1 },
              { id: "explicit.b", type: "text" as const, text: "右侧", style: "paragraph", fixedWidth: 5, fixedHeight: 1 },
            ],
          }],
        },
      }],
    };
    const measured = measureDeck(deck)[0]!.nodes;
    const left = rectOf(measured, "explicit.a");
    const right = rectOf(measured, "explicit.b");
    expect(left.w).toBeCloseTo(4, 2);
    expect(right.w).toBeCloseTo(5, 2);
    expect(right.x - (left.x + left.w)).toBeCloseTo(1, 2);
  });

  it("solves stack sizes from fixed, intrinsic, and flexible constraints", () => {
    const deck = {
      deck: { size: "16x9" as const, theme: "simple", brand: { primary: "E8382C" } },
      slides: [{
        id: "sizing",
        layout: "title-and-content" as const,
        dom: {
          id: "sizing.root",
          type: "slide" as const,
          background: "background",
          children: [{
            id: "sizing.content",
            type: "stack" as const,
            area: "content",
            direction: "vertical",
            gap: 0,
            children: [
              { id: "sizing.fixed", type: "text" as const, text: "Fixed region", style: "paragraph", fixedHeight: 3 },
              {
                id: "sizing.flex",
                type: "bullets" as const,
                density: "comfortable",
                layoutWeight: 1,
                items: Array.from({ length: 18 }, (_, index) => `Long flexible item ${index + 1} with enough text to wrap and require compression`),
              },
            ],
          }],
        },
      }],
    };

    const measured = measureDeck(deck)[0]!.nodes;
    const content = rectOf(measured, "sizing.content");
    const fixed = rectOf(measured, "sizing.fixed");
    const flex = rectOf(measured, "sizing.flex");
    expect(fixed.h).toBeCloseTo(3, 2);
    expect(flex.h).toBeCloseTo(content.h - fixed.h, 2);
    expect(flex.y).toBeCloseTo(fixed.y + fixed.h, 2);
  });

  it("sizes grid rows from row content before distributing spare space", () => {
    const deck = {
      deck: { size: "16x9" as const, theme: "simple", brand: { primary: "E8382C" } },
      slides: [{
        id: "gridRows",
        layout: "title-and-content" as const,
        dom: {
          id: "gridRows.root",
          type: "slide" as const,
          background: "background",
          children: [{
            id: "gridRows.content",
            type: "stack" as const,
            area: "content",
            direction: "vertical",
            gap: 0,
            children: [{
              id: "gridRows.grid",
              type: "grid" as const,
              columns: 2,
              gap: 0,
              fixedHeight: 5.2,
              children: [
                { id: "gridRows.longA", type: "text" as const, text: "Long row text ".repeat(45), style: "paragraph" },
                { id: "gridRows.longB", type: "text" as const, text: "Another long row text ".repeat(40), style: "paragraph" },
                { id: "gridRows.shortA", type: "text" as const, text: "Short", style: "paragraph" },
                { id: "gridRows.shortB", type: "text" as const, text: "Short", style: "paragraph" },
              ],
            }],
          }],
        },
      }],
    };

    const measured = measureDeck(deck)[0]!.nodes;
    expect(rectOf(measured, "gridRows.longA").h).toBeGreaterThan(rectOf(measured, "gridRows.shortA").h);
    expect(rectOf(measured, "gridRows.longA").y).toBeCloseTo(rectOf(measured, "gridRows.longB").y, 2);
    expect(rectOf(measured, "gridRows.shortA").y).toBeGreaterThan(rectOf(measured, "gridRows.longA").y);
  });

  it("applies theme component defaults to semantic role containers", () => {
    const deck = {
      deck: { size: "16x9" as const, theme: "simple", brand: { primary: "E8382C" } },
      slides: [{
        id: "themeDefaults",
        layout: "title-and-content" as const,
        dom: {
          id: "themeDefaults.root",
          type: "slide" as const,
          background: "background",
          children: [{
            id: "themeDefaults.card",
            type: "stack" as const,
            area: "content",
            role: "definition-card",
            direction: "vertical",
            children: [
              { id: "themeDefaults.term", type: "text" as const, text: "Theme default padding", style: "card-title" },
            ],
          }],
        },
      }],
    };

    const measured = measureDeck(deck)[0]!.nodes;
    const card = rectOf(measured, "themeDefaults.card");
    const term = rectOf(measured, "themeDefaults.term");
    expect(term.x).toBeGreaterThan(card.x);
    expect(term.y).toBeGreaterThan(card.y);
    expect(term.w).toBeLessThan(card.w);
  });

  it("keeps component-root layout and style fields after expansion", () => {
    const deck = {
      deck: { size: "16x9" as const, theme: "simple", brand: { primary: "E8382C" } },
      slides: [{
        id: "componentRoot",
        layout: "title-and-content" as const,
        dom: {
          id: "componentRoot.root",
          type: "slide" as const,
          background: "background",
          children: [{
            id: "componentRoot.content",
            type: "stack" as const,
            area: "content",
            direction: "vertical",
            gap: 0,
            children: [
              { id: "componentRoot.fixedCallout", type: "component" as const, component: "callout", text: "Root fields survive expansion", fixedHeight: 2, fill: "brand.tint", line: "brand.primary", padding: 18 },
              { id: "componentRoot.flex", type: "text" as const, text: "Body", style: "paragraph", layoutWeight: 1 },
            ],
          }],
        },
      }],
    };

    const measured = measureDeck(deck)[0]!.nodes;
    const callout = rectOf(measured, "componentRoot.fixedCallout");
    const calloutText = rectOf(measured, "componentRoot.fixedCallout");
    expect(callout.h).toBeCloseTo(2, 2);
    expect(calloutText.h).toBeCloseTo(2, 2);
    const shape = renderToAst(deck).slides[0]!.shapes.find((item) => item.name === "componentRoot.fixedCallout");
    expect(shape?.type).toBe("text");
    if (shape?.type !== "text") throw new Error("Expected expanded callout text shape");
    expect(shape.fill?.type).toBe("solid");
    expect(shape.line?.color).toBe("E8382C");
  });

  it("accepts common LLM aliases for step-card fields", () => {
    const deck = sourceToRenderedDeck({
      slideml2: 2,
      deck: { size: "16x9", theme: "simple", brand: { primary: "E8382C" } },
      slides: [{
        id: "aliases",
        title: "Aliases",
        children: [{
          id: "aliases.steps",
          type: "grid",
          area: "content",
          columns: 1,
          children: [{
            id: "aliases.step",
            type: "component",
            component: "step-card",
            number: "1",
            title: "词典入口",
            description: "用高频工具建立用户基础",
          }],
        }],
      }],
    });

    const rendered = renderToAst(deck);
    const texts = rendered.slides[0]!.shapes
      .filter((shape) => shape.type === "text")
      .flatMap((shape) => shape.type === "text" ? shape.paragraphs.flatMap((p) => p.runs.map((run) => run.text)) : []);
    expect(texts).toEqual(expect.arrayContaining(["1", "词典入口", "用高频工具建立用户基础"]));
  });

  it("designs more complex semantic pages without overflow", async () => {
    const deck = designComplexDeck(
      { name: "Youdao", primary: "E8382C", logo: sampleLogo() },
      {
        dashboard: {
          slideId: "dashboard",
          title: "业务经营概览",
          summary: "学习服务、智能硬件与在线营销形成互补组合，增长质量取决于 AI 能力和硬件入口的协同。",
          metrics: [
            { name: "metric-revenue", value: "56.3亿", label: "2024年营收" },
            { name: "metric-profit", value: "首次", label: "全年盈利" },
            { name: "metric-users", value: "2.8亿+", label: "月活用户" },
          ],
          bullets: ["硬件承担高频学习入口", "大模型提升学习服务体验", "营销业务提供现金流支撑"],
          imageSrc: sampleLogo(),
          imageTitle: "品牌入口与学习场景",
        },
        timeline: {
          slideId: "timeline",
          title: "从工具到 AI 学习平台",
          intro: "页面需要同时容纳阶段说明和四个演进节点，自动布局要保留标题、导语和卡片间距。",
          steps: [
            { title: "词典入口", body: "用高频工具建立用户基础。" },
            { title: "内容服务", body: "扩展课程、翻译和学习资源。" },
            { title: "智能硬件", body: "用词典笔等设备进入学习现场。" },
            { title: "AI Agent", body: "把大模型能力嵌入学习流程。" },
          ],
        },
        comparison: {
          slideId: "comparison",
          title: "三类业务的角色分工",
          thesis: "复杂页面不应该把所有信息挤成一组均分文本框，而应保留主结论和并列比较区。",
          columns: [
            { title: "学习服务", points: ["内容和订阅承接需求", "AI 提升个性化体验", "适合做长期留存"] },
            { title: "智能硬件", points: ["形成场景入口", "具备品牌可见度", "推动软硬件协同"] },
            { title: "在线营销", points: ["贡献现金流", "依托用户规模", "支持业务投入"] },
          ],
        },
      },
    );

    expect(deck.slides.map((slide) => slide.id)).toEqual(["dashboard", "timeline", "comparison"]);
    for (const slide of deck.slides) {
      expect(findNodeForTest(slide.dom, `${slide.id}.slide-title`)).toBeTruthy();
    }
    expect(findNodeForTest(deck.slides[0]!.dom, "dashboard.metricStrip")?.children).toHaveLength(3);
    expect(findNodeForTest(deck.slides[1]!.dom, "timeline.steps")?.children).toHaveLength(4);
    expect(findNodeForTest(deck.slides[2]!.dom, "comparison.comparisonGrid")?.children).toHaveLength(3);

    const measured = measureDeck(deck);
    const dashboardImage = rectOf(measured[0]!.nodes, "dashboard.brief-image");
    const dashboardCaption = rectOf(measured[0]!.nodes, "dashboard.brief-image.caption");
    expect(dashboardCaption.y).toBeGreaterThan(dashboardImage.y + dashboardImage.h);
    expect(dashboardCaption.y + dashboardCaption.h).toBeLessThan(13.55);
    for (const slide of measured) {
      for (const node of slide.nodes) {
        expect(node.rect.x, `${slide.slideId}:${node.id}`).toBeGreaterThanOrEqual(0);
        expect(node.rect.y, `${slide.slideId}:${node.id}`).toBeGreaterThanOrEqual(0);
        expect(node.rect.x + node.rect.w, `${slide.slideId}:${node.id}`).toBeLessThanOrEqual(25.4);
        expect(node.rect.y + node.rect.h, `${slide.slideId}:${node.id}`).toBeLessThanOrEqual(14.2875);
      }
    }
    assertShapeBounds(renderToAst(deck));

    const dir = await mkdtemp(join(tmpdir(), "slideml2-complex-"));
    const rendered = await renderToPptx(deck, join(dir, "complex-layouts.pptx"));
    expect((await stat(rendered.outputPath)).size).toBeGreaterThan(1000);
  });

  it("runs the isolated agent loop from audit failure to rendered outputs", async () => {
    const task: AgentTask = {
      requireCoverBrandBackground: true,
      requireBrandLogoBottomRight: true,
      requireBusinessBullets: true,
    };
    const initial = buildDom(sampleSource());
    const before = auditDeck(initial, task);
    expect(before.ok).toBe(false);
    expect(before.issues.map((issue) => issue.code)).toEqual(expect.arrayContaining(["COVER_BACKGROUND", "BRAND_LOGO_POSITION", "MISSING_BUSINESS_BULLETS"]));

    const result = runSimpleAgentLoop(initial, task);
    expect(result.rounds).toBeGreaterThan(0);
    expect(result.appliedOps.map((op) => op.op)).toEqual(expect.arrayContaining(["setSlideProp", "setNodeProp", "insertNode"]));
    expect(auditDeck(result.deck, task).ok).toBe(true);

    const dir = await mkdtemp(join(tmpdir(), "slideml2-"));
    const output = join(dir, "mvp.pptx");
    const rendered = await renderToPptx(result.deck, output);
    expect((await stat(rendered.outputPath)).size).toBeGreaterThan(1000);
    const sidecar = JSON.parse(await readFile(rendered.domPath, "utf8")) as { slides: unknown[] };
    expect(sidecar.slides).toHaveLength(2);
  });

  it("plans pages from markdown, writes SlideML2 JSON, and renders", async () => {
    const markdown = `# 有道智能学习业务分析

品牌色：#E8382C

## 业务经营概览

学习服务、智能硬件与在线营销形成互补组合，增长质量取决于 AI 能力和硬件入口的协同。

### 指标

- 2024年营收：56.3亿
- 全年盈利：首次
- 月活用户：2.8亿+

### 关键判断

- 硬件承担高频学习入口
- 大模型提升学习服务体验
- 营销业务提供现金流支撑

### 图片

图题：品牌入口与学习场景

## 从工具到 AI 学习平台

页面需要同时容纳阶段说明和四个演进节点，自动布局要保留标题、导语和卡片间距。

### 阶段

1. 词典入口：用高频工具建立用户基础。
2. 内容服务：扩展课程、翻译和学习资源。
3. 智能硬件：用词典笔等设备进入学习现场。
4. AI Agent：把大模型能力嵌入学习流程。

## 三类业务的角色分工

复杂页面不应该把所有信息挤成一组均分文本框，而应保留主结论和并列比较区。

### 学习服务

- 内容和订阅承接需求
- AI 提升个性化体验

### 智能硬件

- 形成场景入口
- 具备品牌可见度

### 在线营销

- 贡献现金流
- 依托用户规模
`;
    const plan = planPagesFromMarkdown(markdown, sampleLogo());
    expect(plan.pages.map((page) => page.kind)).toEqual(["dashboard", "timeline", "comparison"]);
    expect(plan.pages.map((page) => page.structure)).toEqual([
      "标题 + 主结论 + 三指标条 + 左侧关键判断 + 右侧图片与图题",
      "标题 + 导语 + 横向阶段卡片",
      "标题 + 主结论 + 并列比较卡片",
    ]);

    const dir = await mkdtemp(join(tmpdir(), "slideml2-md-"));
    const markdownPath = join(dir, "input.md");
    const outputPath = join(dir, "markdown-demo.pptx");
    await writeFile(markdownPath, markdown, "utf8");
    const result = await generateFromMarkdown(markdownPath, outputPath, sampleLogo());
    expect(result.deck.slides).toHaveLength(3);
    expect((await stat(result.outputPath)).size).toBeGreaterThan(1000);
    expect(JSON.parse(await readFile(result.planPath, "utf8")).pages).toHaveLength(3);
    expect(JSON.parse(await readFile(result.slideml2Path, "utf8")).slides).toHaveLength(3);
    assertShapeBounds(renderToAst(result.deck));
  });

  it.skipIf(!runRealLlmTest)("plans pages from markdown with a real LLM", async () => {
    const markdown = await readFile("examples/youdao_ai_learning.md", "utf8");
    const plan = await planPagesFromMarkdownWithLlm(markdown, sampleLogo());
    expect(plan.pages.length).toBeGreaterThanOrEqual(3);
    expect(plan.pages.map((page) => page.kind)).toEqual(expect.arrayContaining(["dashboard", "timeline", "comparison"]));
    for (const page of plan.pages) {
      expect(page.title).toBeTruthy();
      expect(page.structure).toBeTruthy();
    }
  }, 120_000);

  it("expands an agent component tree into renderable SlideML2 DOM", async () => {
    const deck = deckFromComponentPlan({
      title: "智能穿戴硬件新品调查报告",
      brand: { name: "AI Wearables", primary: "2563EB", logo: sampleLogo() },
      slides: [{
        id: "market-summary",
        title: "市场概览与关键判断",
        structure: "stack content with callout, metric grid, and two-column details",
        children: [{
          type: "stack",
          id: "main-content",
          area: "content",
          direction: "vertical",
          gap: 0.4,
          children: [
            { type: "component", component: "callout", id: "core-finding", text: "2026年是 AI 穿戴设备爆发的元年，智能眼镜成为最大增长点。" },
            {
              type: "grid",
              id: "metric-row",
              columns: 3,
              gap: 0.3,
              fixedHeight: 1.85,
              children: [
                { type: "component", component: "metric-card", id: "market-size", value: "500亿美元+", label: "全球市场规模预测" },
                { type: "component", component: "metric-card", id: "glasses-growth", value: "30%+", label: "智能眼镜 CAGR" },
                { type: "component", component: "metric-card", id: "ai-chip", value: "50%+", label: "AI 芯片需求增长" },
              ],
            },
            {
              type: "grid",
              id: "detail-grid",
              columns: 2,
              columnWeights: [0.52, 0.48],
              gap: 0.45,
              layoutWeight: 1,
              children: [
                { type: "bullets", id: "market-drivers", items: ["多模态 AI 交互成为新标准", "健康功能持续增强", "可穿戴设备成为时尚配饰"], density: "compact" },
                { type: "component", component: "comparison-card", id: "winner-card", title: "最成功案例", points: ["Meta Ray-Ban 销量破百万", "Gen 2 在48小时内售罄", "开放 Horizon OS 建立生态"] },
              ],
            },
          ],
        }],
      }],
    }, sampleLogo());

    expect(deck.slides[0]!.dom.children?.map((node) => node.id)).toEqual(["market-summary.title", "market-summary.main-content"]);
    expect(findNodeForTest(deck.slides[0]!.dom, "market-summary.market-size.value")?.text).toBe("500亿美元+");
    const measured = measureDeck(deck)[0]!.nodes;
    for (const node of measured) {
      expect(node.rect.x, node.id).toBeGreaterThanOrEqual(0);
      expect(node.rect.y, node.id).toBeGreaterThanOrEqual(0);
      expect(node.rect.x + node.rect.w, node.id).toBeLessThanOrEqual(25.4);
      expect(node.rect.y + node.rect.h, node.id).toBeLessThanOrEqual(14.2875);
    }
    assertShapeBounds(renderToAst(deck));
    const dir = await mkdtemp(join(tmpdir(), "slideml2-component-agent-"));
    const rendered = await renderToPptx(deck, join(dir, "component-agent.pptx"));
    expect((await stat(rendered.outputPath)).size).toBeGreaterThan(1000);
  });

  it("exposes complete component, text kind, and theme registries", () => {
    expect(listThemes()).toEqual(["default", "enterprise-light", "technical-blue"]);
    expect(listTextKinds().map((item) => item.kind)).toEqual(expect.arrayContaining(["slide-title", "lead", "metric-value", "table-cell", "code"]));
    const componentNames = listComponents().map((item) => item.name);
    expect(componentNames).toEqual(expect.arrayContaining([
      "stack",
      "grid",
      "spacer",
      "divider",
      "image",
      "table",
      "chart",
      "lead",
      "text",
      "article",
      "code",
      "source-note",
      "label",
      "metric-card",
      "callout",
      "comparison-card",
      "step-card",
      "definition-card",
    ]));
    expect(componentNames).not.toEqual(expect.arrayContaining([
      "caption",
      "figure-caption",
      "footnote",
      "paragraph",
      "code-caption",
      "body-small",
      "axis-label",
      "legend-label",
      "table-card",
      "table-head",
      "table-cell",
      "quote",
      "quote-source",
      "quote-card",
      "badge",
      "tag",
      "image-with-caption",
      "chart-card",
      "code-card",
    ]));
    expect(listComponents().every((item) => !("tier" in item))).toBe(true);
    expect(listComponents().every((item) => Object.keys(item).sort().join(",") === "name,purpose")).toBe(true);
    expect(describeNodeType("image").fields.caption).toContain("optional");
    expect(describeNodeType("chart").fields.caption).toContain("optional");
    expect(describeNodeType("chart").fields.axis).toContain("optional");
    expect(describeNodeType("chart").fields.legend).toContain("optional");
    expect(describeNodeType("table").fields.caption).toContain("optional");
    const described = describeComponents(["metric-card", "image"]);
    expect(described.missing).toEqual([]);
    const metric = described.found["metric-card"];
    expect(metric?.fields.value.required).toBe(true);
    expect(metric?.renderBehavior?.expandsTo).toContain("metric-value");
    const image = described.found["image"];
    expect(image?.fields.src.required).toBe(true);
    expect(image?.fields.caption.description).toContain("optional");
    expect(describeComponents(["unknown-component"]).missing).toEqual(["unknown-component"]);
  });

  it("discloses deck-level brand, chrome, and aesthetic principles", () => {
    const deck = describeDeck();
    expect(deck.size.value).toBe("16x9");
    expect(deck.size.slideWidthCm).toBeGreaterThan(20);
    expect(deck.contentArea.contentHeight).toBeGreaterThan(8);
    expect(deck.themes.available).toEqual(expect.arrayContaining(["default", "enterprise-light", "technical-blue"]));
    expect(deck.brand.fields.primary).toMatchObject({ type: "string" });
    expect(deck.chrome.fields.brandMark.enum).toEqual(["none", "top-right", "bottom-right"]);
    expect(deck.colorTokens.tokens).toEqual(expect.arrayContaining(["brand.primary", "surface", "text.primary"]));
    expect(deck.textStyles.styles).toEqual(expect.arrayContaining(["slide-title", "card-title", "paragraph"]));
    expect(deck.layoutPrinciples.length).toBeGreaterThan(3);
    expect(deck.consistencyPrinciples.length).toBeGreaterThan(3);
    expect(deck.componentChoiceGuidelines.length).toBeGreaterThan(3);
    expect(deck.textHygiene.some((rule) => rule.includes("CJK"))).toBe(true);
    expect(deck.doNot.some((rule) => rule.includes("fontSize"))).toBe(true);
    const pack = buildAgentPromptPack({ intent: "比较三个产品", includeDeckGuide: true });
    expect(pack).toContain("Deck principles");
    expect(pack).toContain("Component choice");
    const slim = buildAgentPromptPack({ intent: "比较三个产品", includeDeckGuide: false });
    expect(slim).not.toContain("Deck principles");
  });

  it("discloses components through a compact list and detailed describe API", () => {
    const list = listComponents();
    const promptPack = buildAgentPromptPack({ intent: "用三个指标和一个市场结论说明增长机会" });

    expect(list.map((item) => item.name)).toEqual(expect.arrayContaining(["stack", "grid", "image", "table", "chart", "metric-card"]));
    expect(list.every((item) => !("category" in item) && !("kind" in item) && !("useWhen" in item) && !("avoidWhen" in item))).toBe(true);
    const allDescribed = describeComponents(["metric-card", "stack", "image"]);
    expect(allDescribed.missing).toEqual([]);
    expect(allDescribed.found["metric-card"]).toMatchObject({
      name: "metric-card",
      fields: { value: { required: true }, label: { required: true } },
    });
    expect(allDescribed.found["stack"]).toMatchObject({
      name: "stack",
      children: { allowed: true, required: true },
    });
    expect(allDescribed.found["image"]?.examples[0]).toMatchObject({ type: "image" });
    expect(validateSlide({
      id: "primitive-components",
      children: [{
        id: "primitive-components.content",
        type: "component",
        component: "stack",
        area: "content",
        children: [{
          id: "primitive-components.image",
          type: "component",
          component: "image",
          src: sampleLogo(),
          alt: "Logo",
        }],
      }],
    }).ok).toBe(true);
    const emptyContainer = validateSlide({
      id: "empty-container",
      children: [{
        id: "empty-container.content",
        type: "component",
        component: "stack",
        area: "content",
      }],
    });
    expect(emptyContainer.ok).toBe(false);
    expect(emptyContainer.errors.map((item) => item.code)).toContain("EMPTY_CONTAINER_COMPONENT");
    const duplicateContent = validateSlide({
      id: "duplicate-content",
      children: [
        { id: "duplicate-content.a", type: "component", component: "stack", area: "content", children: [{ id: "duplicate-content.a.text", type: "component", component: "text", text: "A" }] },
        { id: "duplicate-content.b", type: "component", component: "stack", area: "content", children: [{ id: "duplicate-content.b.text", type: "component", component: "text", text: "B" }] },
      ],
    });
    expect(duplicateContent.ok).toBe(false);
    expect(duplicateContent.errors.map((item) => item.code)).toContain("MULTIPLE_CONTENT_AREAS");
    expect(promptPack).toContain("metric-card");
    expect(promptPack).toContain("callout");
    expect(promptPack).toContain("type:'stack'");
    expect(promptPack).toContain("children=required");
    expect(promptPack).toContain("example=");
    expect(promptPack).not.toContain("code-card");
    expect(promptPack).not.toContain("image-with-caption");
    expect(promptPack.length).toBeLessThan(2400);
  });

  it("supports deck-level props and whole-slide operations only", async () => {
    const dir = await mkdtemp(join(tmpdir(), "slideml2-ops-"));
    const deckPath = join(dir, "deck.slideml2.json");
    await createDeck(deckPath, { title: "Ops deck", theme: "default", brand: { name: "Ops", primary: "2563EB" } });
    await setDeckProps(deckPath, { theme: "technical-blue", chrome: { brandMark: "bottom-right", pageNumber: true } });
    await appendSlide(deckPath, sourceSlide("summary", "执行摘要"));
    await insertSlide(deckPath, 0, sourceSlide("opening", "开篇判断"));
    await replaceSlide(deckPath, "summary", sourceSlide("summary", "更新后的摘要"));
    await deleteSlide(deckPath, "opening");
    const validation = await validateDeckPath(deckPath);
    expect(validation.ok).toBe(true);
    expect(validation.errors).toHaveLength(0);
  });

  it("validates source slides with actionable component errors", () => {
    const deck = createSourceDeck({ title: "Validation", theme: "enterprise-light" });
    deck.slides.push({
      id: "bad",
      title: "Bad slide",
      children: [{
        id: "bad.c",
        type: "component",
        component: "unknown-card",
      }],
    });
    const validation = validateDeck(deck);
    expect(validation.ok).toBe(false);
    expect(validation.errors[0]?.code).toBe("UNKNOWN_COMPONENT");
    expect(validation.errors[0]?.suggestedFix).toContain("listComponents");
  });

  it("renders the same component source deck with three themes", async () => {
    const dir = await mkdtemp(join(tmpdir(), "slideml2-themes-"));
    for (const theme of listThemes()) {
      const deck = createSourceDeck({ title: `Theme ${theme}`, theme, brand: { name: "Demo", primary: theme === "technical-blue" ? "0F62FE" : "2563EB", logo: sampleLogo() } });
      deck.slides.push({
        id: `${theme}-gallery`,
        title: `${theme} component gallery`,
        children: [{
          id: `${theme}.content`,
          type: "stack",
          area: "content",
          direction: "vertical",
          gap: 0.3,
          children: [
            { id: `${theme}.lead`, type: "text", text: "同一份语义 DOM 由 theme 决定视觉表现。", style: "lead" },
            {
              id: `${theme}.grid`,
              type: "grid",
              columns: 3,
              gap: 0.3,
              layoutWeight: 1,
              children: [
                componentNode(`${theme}.metric`, "metric-card", { value: "500亿+", label: "市场规模" }),
                componentNode(`${theme}.callout`, "callout", { text: "组件表达语义，theme 表达风格。", tone: "brand" }),
                componentNode(`${theme}.compare`, "comparison-card", { title: "Meta Ray-Ban", points: ["销量破百万", "AI眼镜标杆"] }),
              ],
            },
          ],
        }],
      });
      const rendered = await renderToPptx(sourceToRenderedDeck(deck), join(dir, `${theme}.pptx`));
      expect((await stat(rendered.outputPath)).size).toBeGreaterThan(1000);
      expect(validateDeck(deck).ok).toBe(true);
    }
  });

  it("generates decks through small per-slide LLM calls and appendSlide", async () => {
    const dir = await mkdtemp(join(tmpdir(), "slideml2-batch-agent-"));
    const markdownPath = join(dir, "report.md");
    await writeFile(markdownPath, [
      "# AI 可穿戴设备报告",
      "",
      "DO_NOT_PASS_FULL_MARKDOWN_SENTINEL",
      "",
      "这是一份较长报告，页面生成阶段不应该再次携带整份 markdown。",
    ].join("\n"), "utf8");

    const responses = [
      [
        { id: "summary", title: "执行摘要", intent: "说明市场增长和机会", keyFacts: ["2026 增长加速", "全球规模 500 亿美元+"] },
        { id: "strategy", title: "产品策略", intent: "说明产品落地方向", keyFacts: ["智能眼镜是核心入口", "端侧 AI 芯片需求增长"] },
      ],
      {
        id: "summary",
        title: "执行摘要",
        children: [{
          id: "summary.content",
          type: "component",
          component: "stack",
          area: "content",
          gap: "medium",
          children: [
            { id: "summary.lead", type: "component", component: "lead", text: "AI 可穿戴进入增长加速期。" },
            { id: "summary.metric", type: "component", component: "metric-card", metricValue: "500亿+", metricLabel: "全球规模" },
          ],
        }],
      },
      {
        id: "strategy",
        title: "产品策略",
        children: [{
          id: "strategy.content",
          type: "component",
          component: "stack",
          area: "content",
          gap: 12,
          children: [
            { id: "strategy.callout", type: "component", component: "callout", title: "核心判断", bullets: ["智能眼镜是核心入口", "端侧 AI 芯片需求增长"] },
          ],
        }],
      },
    ];
    const requests: Array<{ content: string }> = [];
    const originalFetch = globalThis.fetch;
    globalThis.fetch = (async (_url, init) => {
      const body = JSON.parse(String(init?.body || "{}")) as { messages?: Array<{ content?: string }> };
      requests.push({ content: String(body.messages?.[0]?.content || "") });
      const payload = responses.shift();
      return new Response(JSON.stringify({ content: [{ text: JSON.stringify(payload) }] }), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    }) as typeof fetch;
    try {
      const result = await generateDeckWithBatchAgent({
        markdownPath,
        deckPath: join(dir, "deck.slideml2.json"),
        outputPath: join(dir, "deck.pptx"),
        maxSlides: 2,
        config: { apiKey: "test", baseURL: "https://llm.test/v1", model: "test-model" },
      });
      const deck = JSON.parse(await readFile(result.deckPath, "utf8")) as { slides: unknown[] };
      expect(deck.slides).toHaveLength(2);
      expect(JSON.stringify(deck)).toContain("summary.lead");
      expect(result.validation.ok).toBe(true);
      expect(requests).toHaveLength(3);
      expect(requests[0]!.content).toContain("DO_NOT_PASS_FULL_MARKDOWN_SENTINEL");
      expect(requests[1]!.content).not.toContain("DO_NOT_PASS_FULL_MARKDOWN_SENTINEL");
      expect(requests[2]!.content).not.toContain("DO_NOT_PASS_FULL_MARKDOWN_SENTINEL");
      expect((await stat(result.outputPath)).size).toBeGreaterThan(1000);
    } finally {
      globalThis.fetch = originalFetch;
    }
  });

  it.skipIf(!runRealLlmTest)("lets a real LLM compose slides from basic components", async () => {
    const dir = await mkdtemp(join(tmpdir(), "slideml2-real-component-agent-"));
    const result = await generateWithComponentAgent(
      "/Users/river/Documents/Workspace/智能穿戴硬件新品调查报告.md",
      join(dir, "wearables-component-agent.pptx"),
      sampleLogo(),
    );
    expect(result.plan.slides.length).toBeGreaterThanOrEqual(4);
    expect((await stat(result.outputPath)).size).toBeGreaterThan(1000);
    expect(result.plan.slides.map((slide) => slide.title).join("\n")).not.toMatch(/封面|目录|结束|谢谢|数据来源/i);
    expect(collectComponentNames(result.plan)).not.toEqual(expect.arrayContaining(["cover", "section", "dashboard", "product-matrix", "risk-list", "recommendation-list"]));
    for (const slide of result.deck.slides) {
      expect(findNodeForTest(slide.dom, "slide-title")).toBeTruthy();
    }
    assertShapeBounds(renderToAst(result.deck));
  }, 120_000);

  it.skipIf(!runRealLlmTest)("uses a real LLM to generate one small slide JSON", async () => {
    const slide = await generateOneSlideWithLlm({
      id: "ai-wearables-summary",
      title: "AI可穿戴设备执行摘要",
      intent: "用一个主结论、三个指标和三条要点说明市场机会。",
      keyFacts: [
        "2026年是AI穿戴设备增长加速的一年",
        "全球市场规模预计达到500亿美元+",
        "智能眼镜增长率预计30%+",
        "AI芯片需求增长50%+",
        "Meta Ray-Ban销量破百万",
      ],
    });
    const validation = validateSlide(slide, { deck: { size: "16x9", theme: "enterprise-light", brand: { name: "AI Wearables", primary: "2563EB", logo: sampleLogo() } } });
    expect(slide.id).toBe("ai-wearables-summary");
    expect(slide.children.length).toBeGreaterThan(0);
    expect(validation.ok).toBe(true);
  }, 90_000);
});

function rectOf(nodes: ReturnType<typeof measureDeck>[number]["nodes"], name: string) {
  const found = nodes.find((node) => node.id === name);
  if (!found) throw new Error(`Measured node not found: ${name}`);
  return found.rect;
}

function overlaps(a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }): boolean {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function assertShapeBounds(ast: ReturnType<typeof renderToAst>): void {
  const slideWidth = 9_144_000;
  const slideHeight = 5_143_500;
  for (const slide of ast.slides) {
    for (const shape of slide.shapes) {
      expect(shape.xfrm.x, shape.name).toBeGreaterThanOrEqual(0);
      expect(shape.xfrm.y, shape.name).toBeGreaterThanOrEqual(0);
      expect(shape.xfrm.x + shape.xfrm.cx, shape.name).toBeLessThanOrEqual(slideWidth);
      expect(shape.xfrm.y + shape.xfrm.cy, shape.name).toBeLessThanOrEqual(slideHeight);
    }
  }
}

function collectComponentNames(plan: { slides: Array<{ children: unknown[] }> }): string[] {
  const output: string[] = [];
  const visit = (node: unknown) => {
    if (!node || typeof node !== "object") return;
    const record = node as { type?: unknown; component?: unknown; children?: unknown };
    if (record.type === "component" && typeof record.component === "string") output.push(record.component);
    if (Array.isArray(record.children)) record.children.forEach(visit);
  };
  plan.slides.forEach((slide) => slide.children.forEach(visit));
  return output;
}

function sampleSource(): Slideml2Deck {
  return {
    slideml2: 1,
    deck: {
      size: "16x9",
      theme: "simple",
      brand: {
        name: "Youdao",
        primary: "E8382C",
        logo: sampleLogo(),
      },
    },
    slides: [
      { id: "cover", layout: "cover", title: "Youdao Company", subtitle: "AI learning products and services" },
      { id: "business", layout: "title-and-content", title: "Business overview", items: ["Existing summary"] },
    ],
  };
}

function sourceSlide(id: string, title: string) {
  return {
    id,
    title,
    children: [{
      id: `${id}.content`,
      type: "stack" as const,
      area: "content",
      direction: "vertical",
      gap: 0.3,
      children: [
        { id: `${id}.lead`, type: "text" as const, text: "这是一个用于验证整页操作的页面。" },
        componentNode(`${id}.metric`, "metric-card", { value: "3", label: "操作数量" }),
      ],
    }],
  };
}

function componentNode(id: string, component: string, fields: Record<string, unknown>) {
  return {
    id,
    type: "component" as const,
    component,
    ...fields,
  };
}

function sampleLogo(): string {
  return dataSvg("<svg xmlns='http://www.w3.org/2000/svg' width='240' height='96'><rect width='240' height='96' rx='10' fill='#E8382C'/><text x='120' y='60' text-anchor='middle' font-family='Arial' font-size='40' font-weight='700' fill='white'>Youdao</text></svg>");
}

function dataSvg(svg: string): string {
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
}
