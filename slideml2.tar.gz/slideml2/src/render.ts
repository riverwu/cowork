import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { emitPackage } from "../../slideml/src/emitter/package.js";
import type { ChartAnnotation, ChartNumberFormat, ChartSeries, ChartType, DeckAst, ImageShape, LineSpec, Paragraph, ShapeList, SlideAst, TableCell, TextRun, ShapePreset } from "../../slideml/src/emitter/types.js";
import { expandComponent, isComponentTypedNode } from "./component-registry.js";
import { inferTextKind } from "./text-normalizer.js";
import type { AnchorPoint, DomNode, RenderedDeck } from "./types.js";
import type { Slideml2SourceDeck } from "./types.js";
import { sourceToRenderedDeck } from "./source-deck.js";
import { buildTheme, color, preferredFont, textStyle, type SimpleTheme } from "./theme.js";

const EMU_PER_CM = 360000;
const ANCHOR_POINTS: Set<string> = new Set([
  "top-left", "top-center", "top-right",
  "middle-left", "middle-center", "middle-right",
  "bottom-left", "bottom-center", "bottom-right",
]);
const SHAPE_PRESETS: Set<string> = new Set([
  "rect", "roundRect", "ellipse", "line",
  "triangle", "rightTriangle", "pentagon",
  "arrow-right", "arrow-down", "callout",
  "chevron", "star-5", "parallelogram", "cloud",
]);

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface MeasuredNode {
  id: string;
  type: string;
  rect: Rect;
}

export async function renderToPptx(deck: RenderedDeck, outputPath: string): Promise<{ outputPath: string; domPath: string }> {
  const ast = renderToAst(deck);
  const buffer = await emitPackage(ast);
  await mkdir(dirname(outputPath), { recursive: true });
  await writeFile(outputPath, buffer);
  const domPath = `${outputPath}.render-tree.json`;
  await writeFile(domPath, JSON.stringify(materializeDeck(deck), null, 2), "utf8");
  return { outputPath, domPath };
}

export async function renderSourceDeckToPptx(deck: Slideml2SourceDeck, outputPath: string): Promise<{ outputPath: string; domPath: string }> {
  return renderToPptx(sourceToRenderedDeck(deck), outputPath);
}

export function renderToAst(deck: RenderedDeck): DeckAst {
  const theme = buildTheme(deck.deck.brand, deck.deck.theme);
  const slides: SlideAst[] = deck.slides.map((slide, index) => {
    const dom = materializeAndCompactify(slide.dom, slide.id);
    const ids = { nextId: 2 };
    const shapes = renderSlide(theme, dom, ids, slide.id);
    shapes.push(...renderChrome(theme, deck, index, ids));
    return {
      shapes,
      background: { type: "solid", color: color(theme, dom.background, "background") },
      notes: typeof dom.notes === "string" ? dom.notes : undefined,
    };
  });
  return {
    size: "16x9",
    language: "zh-CN",
    title: "SlideML2 MVP",
    author: "SlideML2",
    slides,
  };
}

export function measureDeck(deck: RenderedDeck): Array<{ slideId: string; nodes: MeasuredNode[] }> {
  const theme = buildTheme(deck.deck.brand, deck.deck.theme);
  return deck.slides.map((slide) => {
    const dom = materializeAndCompactify(slide.dom, slide.id);
    const layout = layoutSlide(theme, dom);
    return { slideId: slide.id, nodes: layout.measured };
  });
}

function materializeAndCompactify(slideDom: DomNode, slideId: string): DomNode {
  const materialized = materializeNode(slideDom, slideId);
  const compactedChildren = (materialized.children || [])
    .map(compactifyNode)
    .filter((c): c is DomNode => c !== null);
  return { ...materialized, children: compactedChildren };
}

interface LayoutResult {
  measured: MeasuredNode[];
  rectsById: Map<string, Rect>;
}

function layoutSlide(theme: SimpleTheme, slideDom: DomNode): LayoutResult {
  const measured: MeasuredNode[] = [];
  const rectsById = new Map<string, Rect>();
  const slideRect = fullRect(theme);
  measured.push({ id: slideDom.id, type: slideDom.type, rect: slideRect });
  rectsById.set(slideDom.id, slideRect);
  for (const child of slideDom.children || []) {
    const childRect = rectForSlideChild(theme, child);
    measureSubtree(theme, child, childRect, measured, rectsById);
  }
  return { measured, rectsById };
}

function isOverlayChild(node: DomNode): boolean {
  if (typeof node.anchor === "string" && ANCHOR_POINTS.has(node.anchor)) return true;
  if (node.type === "image" && (node.position === "bottom-right" || node.position === "top-right" || node.position === "center")) return true;
  return false;
}

function flowChildren(slideDom: DomNode): DomNode[] {
  return (slideDom.children || []).filter((child) => !isOverlayChild(child));
}

function overlayChildren(slideDom: DomNode): DomNode[] {
  return (slideDom.children || []).filter(isOverlayChild);
}

function measureSubtree(theme: SimpleTheme, node: DomNode, rect: Rect, output: MeasuredNode[], rectsById: Map<string, Rect>): void {
  const caption = captionText(node);
  if (caption && (node.type === "image" || node.type === "table" || node.type === "chart")) {
    const { bodyRect, captionRect } = captionLayout(node, rect);
    output.push({ id: node.id, type: node.type, rect: bodyRect });
    output.push({ id: `${node.id}.caption`, type: "text", rect: captionRect });
    rectsById.set(node.id, bodyRect);
    rectsById.set(`${node.id}.caption`, captionRect);
    return;
  }
  output.push({ id: node.id, type: node.type, rect });
  rectsById.set(node.id, rect);
  if (node.type === "stack") {
    layoutStackChildren(theme, node, contentRect(theme, node, rect)).forEach(({ node: child, rect: childRect }) => measureSubtree(theme, child, childRect, output, rectsById));
    return;
  }
  if (node.type === "grid") {
    layoutGridChildren(theme, node, contentRect(theme, node, rect)).forEach(({ node: child, rect: childRect }) => measureSubtree(theme, child, childRect, output, rectsById));
  }
}

function rectForSlideChild(theme: SimpleTheme, node: DomNode): Rect {
  if (node.type === "text" && textStyleKey(node) === "slide-title" && !isOverlayChild(node)) {
    return { x: theme.layout.pageMarginX, y: theme.layout.titleTop, w: theme.layout.slideWidthCm - theme.layout.pageMarginX * 2, h: theme.layout.titleHeight };
  }
  if (typeof node.anchor === "string" && ANCHOR_POINTS.has(node.anchor)) {
    return rectFromAnchor(theme, node);
  }
  if (node.type === "image" && node.position === "bottom-right") {
    const w = numberProp(node, "width", 2.4);
    const h = numberProp(node, "height", 1.0);
    return { x: theme.layout.slideWidthCm - w - 0.7, y: theme.layout.slideHeightCm - h - 0.55, w, h };
  }
  if (node.type === "image" && node.position === "top-right") {
    const w = numberProp(node, "width", 2.4);
    const h = numberProp(node, "height", 1.0);
    return { x: theme.layout.slideWidthCm - w - 0.7, y: 0.55, w, h };
  }
  if (node.type === "image" && node.position === "center") {
    const w = numberProp(node, "width", 8);
    const h = numberProp(node, "height", 5);
    return { x: (theme.layout.slideWidthCm - w) / 2, y: (theme.layout.slideHeightCm - h) / 2, w, h };
  }
  if (stringProp(node, "area", "") === "content") {
    return { x: theme.layout.pageMarginX, y: theme.layout.contentTop, w: theme.layout.slideWidthCm - theme.layout.pageMarginX * 2, h: theme.layout.slideHeightCm - theme.layout.contentTop - theme.layout.contentBottom };
  }
  return fullRect(theme);
}

function rectFromAnchor(theme: SimpleTheme, node: DomNode): Rect {
  const anchor = node.anchor as AnchorPoint;
  const w = numberProp(node, "width", node.type === "image" ? 4 : 3);
  const h = numberProp(node, "height", node.type === "image" ? 3 : 1.2);
  const ox = numberProp(node, "offsetX", 0);
  const oy = numberProp(node, "offsetY", 0);
  const slideW = theme.layout.slideWidthCm;
  const slideH = theme.layout.slideHeightCm;
  let x = 0;
  let y = 0;
  if (anchor.endsWith("-left")) x = ox;
  else if (anchor.endsWith("-center")) x = (slideW - w) / 2 + ox;
  else x = slideW - w - ox;
  if (anchor.startsWith("top-")) y = oy;
  else if (anchor.startsWith("middle-")) y = (slideH - h) / 2 + oy;
  else y = slideH - h - oy;
  return { x, y, w, h };
}

function renderSlide(theme: SimpleTheme, slideDom: DomNode, ids: { nextId: number }, slideId: string): ShapeList {
  const layout = layoutSlide(theme, slideDom);
  const flow = flowChildren(slideDom);
  const overlays = overlayChildren(slideDom);
  const flowShapes: ShapeList = [];
  for (const child of flow) {
    const rect = layout.rectsById.get(child.id);
    if (!rect) continue;
    flowShapes.push(...renderNode(theme, child, rect, layout.rectsById, ids, slideId));
  }
  const sorted = [...overlays].sort((a, b) => numberProp(a, "zIndex", 0) - numberProp(b, "zIndex", 0));
  const below: ShapeList = [];
  const above: ShapeList = [];
  for (const child of sorted) {
    const rect = layout.rectsById.get(child.id);
    if (!rect) continue;
    const z = numberProp(child, "zIndex", 0);
    const shapes = renderNode(theme, child, rect, layout.rectsById, ids, slideId);
    if (z < 0) below.push(...shapes);
    else above.push(...shapes);
  }
  return [...below, ...flowShapes, ...above];
}

function renderNode(theme: SimpleTheme, node: DomNode, rect: Rect, rectsById: Map<string, Rect>, ids: { nextId: number }, slideId: string): ShapeList {
  if (node.type === "stack") return renderStack(theme, node, rect, rectsById, ids, slideId);
  if (node.type === "grid") return renderGrid(theme, node, rect, rectsById, ids, slideId);
  if (node.type === "spacer") return [];
  if (rect.h < 0.18 || rect.w < 0.18) {
    layoutDropWarnings.add(`${slideId}/${node.id}:${rect.w.toFixed(2)}x${rect.h.toFixed(2)}`);
    return [];
  }
  if (node.type === "divider") return [dividerShape(theme, node, rect, ids)];
  if (node.type === "text") return [textShape(theme, node, rect, ids)];
  if (node.type === "bullets") return [bulletsShape(theme, node, rect, ids)];
  if (node.type === "image") return captionedShapes(theme, node, rect, ids, (bodyRect) => imageShape(theme, node, bodyRect, ids));
  if (node.type === "table") return captionedShapes(theme, node, rect, ids, (bodyRect) => [tableShape(theme, node, bodyRect, ids)]);
  if (node.type === "chart") return captionedShapes(theme, node, rect, ids, (bodyRect) => [chartShape(theme, node, bodyRect, ids)]);
  if (node.type === "shape") return [presetShape(theme, node, rect, ids)];
  return [];
}

const layoutDropWarnings = new Set<string>();
export function listLayoutDropWarnings(): string[] {
  return Array.from(layoutDropWarnings);
}
export function clearLayoutDropWarnings(): void {
  layoutDropWarnings.clear();
}

function renderStack(theme: SimpleTheme, node: DomNode, rect: Rect, rectsById: Map<string, Rect>, ids: { nextId: number }, slideId: string): ShapeList {
  const children = node.children || [];
  if (children.length === 0) return [];
  return [
    ...containerBackgroundShape(theme, node, rect, ids),
    ...layoutStackChildren(theme, node, contentRect(theme, node, rect)).flatMap(({ node: child, rect: childRect }) => {
      rectsById.set(child.id, childRect);
      return renderNode(theme, child, childRect, rectsById, ids, slideId);
    }),
  ];
}

function renderGrid(theme: SimpleTheme, node: DomNode, rect: Rect, rectsById: Map<string, Rect>, ids: { nextId: number }, slideId: string): ShapeList {
  const children = node.children || [];
  if (children.length === 0) return [];
  return [
    ...containerBackgroundShape(theme, node, rect, ids),
    ...layoutGridChildren(theme, node, contentRect(theme, node, rect)).flatMap(({ node: child, rect: childRect }) => {
      rectsById.set(child.id, childRect);
      return renderNode(theme, child, childRect, rectsById, ids, slideId);
    }),
  ];
}

function renderChrome(theme: SimpleTheme, deck: RenderedDeck, slideIndex: number, ids: { nextId: number }): ShapeList {
  const out: ShapeList = [];
  const layout = theme.layout;
  const chrome = theme.chrome;
  const footerY = layout.slideHeightCm - chrome.footerHeight;
  if (chrome.footerLine) {
    out.push({
      type: "shape",
      id: ids.nextId++,
      name: "chrome.footer-line",
      preset: "line",
      xfrm: xfrm({ x: layout.pageMarginX, y: footerY, w: layout.slideWidthCm - layout.pageMarginX * 2, h: 0.01 }),
      fill: { type: "none" },
      line: { color: color(theme, "divider"), width: cm(0.02) },
    });
  }
  if (chrome.pageNumber) {
    out.push(textShape(theme, {
      id: `chrome.page-${slideIndex + 1}`,
      type: "text",
      text: `${slideIndex + 1} / ${deck.slides.length}`,
      style: "footnote",
      align: "right",
    }, { x: layout.slideWidthCm - chrome.footerPadding - 2, y: footerY + 0.05, w: 2, h: chrome.footerHeight - 0.05 }, ids));
  }
  return out;
}

function textShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList[number] {
  const kind = textStyleKey(node);
  const style = textStyle(theme, kind, "paragraph");
  const paragraphs = buildParagraphs(theme, node, style);
  const autoFit = node.autoFit === "shrink" || node.autoFit === "resize" ? node.autoFit : undefined;
  const cornerRadius = typeof node.cornerRadius === "number"
    ? node.cornerRadius
    : (typeof node.fill === "string" || typeof node.line === "string" ? 0.08 : undefined);
  return {
    type: "text",
    id: ids.nextId++,
    name: nodeLabel(node),
    xfrm: xfrm(rect),
    valign: valignProp(node, kind),
    paragraphs,
    margin: { l: cm(0.1), r: cm(0.1), t: cm(0.05), b: cm(0.05) },
    fill: typeof node.fill === "string" ? { type: "solid", color: color(theme, node.fill) } : undefined,
    line: typeof node.line === "string" ? { color: color(theme, node.line), width: cm(0.02) } : undefined,
    cornerRadius,
    ...(autoFit ? { autoFit } : {}),
  };
}

function buildParagraphs(theme: SimpleTheme, node: DomNode, style: ReturnType<typeof textStyle>): Paragraph[] {
  if (Array.isArray(node.paragraphs) && node.paragraphs.length > 0) {
    return node.paragraphs.map((rawPara) => {
      const rec = rawPara && typeof rawPara === "object" ? rawPara as Record<string, unknown> : {};
      const paraStyleKey = typeof rec.style === "string" ? rec.style : undefined;
      const paraStyle = paraStyleKey ? textStyle(theme, paraStyleKey, "paragraph") : style;
      const runs: TextRun[] = Array.isArray(rec.runs)
        ? rec.runs.map((r) => richRunToTextRun(theme, r, paraStyle, paraStyle.weight === "bold"))
        : [{
            text: typeof rec.text === "string" ? rec.text : "",
            sizeHalfPt: paraStyle.fontSize * 2,
            bold: paraStyle.weight === "bold",
            color: color(theme, typeof rec.color === "string" ? rec.color : undefined, paraStyle.color),
            fontFace: containsCjk(typeof rec.text === "string" ? rec.text : "") ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"),
            cjk: true,
          }];
      const para: Paragraph = {
        runs,
        align: paragraphAlign(rec.align ?? node.align),
      };
      if (typeof rec.indentLevel === "number" && rec.indentLevel > 0) para.indentLevel = rec.indentLevel;
      if (typeof rec.lineSpacing === "number") para.lineSpacingHalfPt = rec.lineSpacing * 2;
      if (typeof rec.spaceAfter === "number") para.spaceAfterHalfPt = rec.spaceAfter * 2;
      if (rec.bullet === "auto") para.bullet = { auto: true };
      else if (rec.bullet === "number") para.bullet = { number: true };
      return para;
    });
  }
  const runs = textRuns(theme, node, style);
  const para: Paragraph = {
    align: paragraphAlign(node.align),
    runs,
  };
  if (typeof node.indentLevel === "number" && node.indentLevel > 0) para.indentLevel = node.indentLevel;
  if (typeof node.lineSpacing === "number") para.lineSpacingHalfPt = node.lineSpacing * 2;
  if (typeof node.spaceAfter === "number") para.spaceAfterHalfPt = node.spaceAfter * 2;
  return [para];
}

function paragraphAlign(value: unknown): "left" | "center" | "right" | "justify" | undefined {
  if (value === "left" || value === "center" || value === "right" || value === "justify") return value;
  return undefined;
}

function bulletsShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList[number] {
  const rawItems = Array.isArray(node.items) ? node.items : [];
  const style = textStyle(theme, node.density === "compact" ? "bullet-compact" : "bullet", "paragraph");
  const title = typeof node.title === "string" && node.title.trim() ? node.title.trim() : "";
  const numbered = node.numbered === true;
  const defaultIndent = typeof node.indentLevel === "number" ? node.indentLevel : 0;
  const itemParas: Paragraph[] = rawItems.map((rawItem) => {
    const isObject = rawItem && typeof rawItem === "object" && !Array.isArray(rawItem);
    const itemRec = isObject ? rawItem as Record<string, unknown> : { text: String(rawItem ?? "") };
    const text = typeof itemRec.text === "string" ? itemRec.text : "";
    const indent = typeof itemRec.indentLevel === "number" ? itemRec.indentLevel : defaultIndent;
    const bold = itemRec.bold === true || (style.weight === "bold");
    const colorToken = typeof itemRec.color === "string" ? itemRec.color : (typeof node.color === "string" ? node.color : undefined);
    const customRuns = Array.isArray(itemRec.runs) ? itemRec.runs : null;
    const runs: TextRun[] = customRuns
      ? customRuns.map((r) => richRunToTextRun(theme, r, style, bold))
      : [{ text, sizeHalfPt: style.fontSize * 2, bold, color: color(theme, colorToken, style.color), fontFace: containsCjk(text) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"), cjk: true }];
    const para: Paragraph = {
      bullet: numbered ? { number: true as const } : { auto: true as const },
      runs,
      spaceAfterHalfPt: node.density === "compact" ? 4 : 10,
    };
    if (indent > 0) para.indentLevel = indent;
    return para;
  });
  return {
    type: "text",
    id: ids.nextId++,
    name: nodeLabel(node),
    xfrm: xfrm(rect),
    paragraphs: [
      ...(title ? [{
        runs: [{ text: title, sizeHalfPt: theme.text["card-title"].fontSize * 2, bold: true, color: color(theme, "brand.primary"), fontFace: containsCjk(title) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"), cjk: true }],
        spaceAfterHalfPt: 6,
      }] : []),
      ...itemParas,
    ],
    margin: { l: cm(0.2), r: cm(0.1), t: cm(0.08), b: cm(0.08) },
  };
}

function presetShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList[number] {
  const presetCandidate = typeof node.preset === "string" && SHAPE_PRESETS.has(node.preset) ? node.preset : "rect";
  const preset = presetCandidate as ShapePreset;
  const lineWidthCm = typeof node.lineWidth === "number" ? node.lineWidth : 0.02;
  const lineDash = node.lineDash === "dash" || node.lineDash === "dashDot" || node.lineDash === "dot" ? node.lineDash : undefined;
  return {
    type: "shape",
    id: ids.nextId++,
    name: nodeLabel(node),
    preset,
    xfrm: xfrm(rect, node),
    fill: typeof node.fill === "string" ? { type: "solid", color: color(theme, node.fill) } : { type: "none" },
    line: typeof node.line === "string" ? { color: color(theme, node.line), width: cm(lineWidthCm), ...(lineDash ? { dash: lineDash } : {}) } : undefined,
    ...(typeof node.cornerRadius === "number" ? { cornerRadius: node.cornerRadius } : {}),
  };
}

function dividerShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList[number] {
  const orientation = node.orientation === "horizontal" || node.orientation === "vertical"
    ? node.orientation
    : rect.w >= rect.h ? "horizontal" : "vertical";
  const thickness = numberProp(node, "thickness", 0.025);
  const lineRect = orientation === "horizontal"
    ? { x: rect.x, y: rect.y + rect.h / 2, w: rect.w, h: Math.max(0.01, thickness) }
    : { x: rect.x + rect.w / 2, y: rect.y, w: Math.max(0.01, thickness), h: rect.h };
  const dash = node.dash === "dash" || node.dash === "dashDot" || node.dash === "dot" ? node.dash : undefined;
  return {
    type: "shape",
    id: ids.nextId++,
    name: nodeLabel(node),
    preset: "line",
    xfrm: xfrm(lineRect),
    fill: { type: "none" },
    line: { color: color(theme, node.line, "divider"), width: cm(Math.max(0.01, thickness)), ...(dash ? { dash } : {}) },
  };
}

function tableShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList[number] {
  const headers = Array.isArray(node.headers) ? node.headers.map(String) : [];
  const rawRows: unknown[][] = Array.isArray(node.rows) ? node.rows.map((row) => Array.isArray(row) ? row : []) : [];
  const headerRow: unknown[] = headers.length > 0 ? headers : [];
  const allRows: unknown[][] = headerRow.length > 0 ? [headerRow, ...rawRows] : rawRows;
  const colCount = Math.max(1, ...allRows.map((row) => row.length));
  const rowCount = Math.max(1, allRows.length);
  const cellAlign = node.align === "center" || node.align === "right" || node.align === "left" ? node.align : "left";
  const firstRowHeader = node.firstRowHeader === false ? false : headers.length > 0;
  const colWidths = resolveTableColWidths(node.colWidths, colCount, rect.w);
  const rowHeightsCm = resolveTableRowHeights(node.rowHeights, rowCount, rect.h);
  const cells: TableCell[][] = allRows.map((row, rowIndex) => Array.from({ length: colCount }, (_, colIndex) => {
    const raw = row[colIndex];
    const isHeader = rowIndex === 0 && firstRowHeader;
    return makeTableCell(theme, raw, isHeader, cellAlign);
  }));
  return {
    type: "table",
    id: ids.nextId++,
    name: nodeLabel(node),
    xfrm: xfrm(rect),
    colWidths: colWidths.map(cm),
    rowHeights: rowHeightsCm.map(cm),
    cells,
    firstRowHeader,
    borderColor: color(theme, typeof node.borderColor === "string" ? node.borderColor : "divider"),
    borderWidth: cm(typeof node.borderWidth === "number" ? node.borderWidth : 0.01),
  };
}

function resolveTableColWidths(raw: unknown, colCount: number, totalCm: number): number[] {
  if (Array.isArray(raw) && raw.length === colCount) {
    const nums = raw.map((v) => typeof v === "number" && Number.isFinite(v) && v > 0 ? v : 0);
    const sum = nums.reduce((a, b) => a + b, 0);
    if (sum > 0) {
      // Treat as widths if total is close to totalCm; otherwise as weights.
      const looksAbsolute = Math.abs(sum - totalCm) < totalCm * 0.5 && nums.every((n) => n >= 0.3);
      if (looksAbsolute) return nums;
      return nums.map((n) => (n / sum) * totalCm);
    }
  }
  return Array.from({ length: colCount }, () => totalCm / colCount);
}

function resolveTableRowHeights(raw: unknown, rowCount: number, totalCm: number): number[] {
  if (Array.isArray(raw) && raw.length === rowCount) {
    const nums = raw.map((v) => typeof v === "number" && Number.isFinite(v) && v > 0 ? v : 0);
    const sum = nums.reduce((a, b) => a + b, 0);
    if (sum > 0) {
      const looksAbsolute = Math.abs(sum - totalCm) < totalCm * 0.5 && nums.every((n) => n >= 0.2);
      if (looksAbsolute) return nums;
      return nums.map((n) => (n / sum) * totalCm);
    }
  }
  return Array.from({ length: rowCount }, () => totalCm / rowCount);
}

function makeTableCell(theme: SimpleTheme, raw: unknown, isHeader: boolean, defaultAlign: "left" | "center" | "right"): TableCell {
  const kind = isHeader ? "table-header" : "table-cell";
  const style = textStyle(theme, kind, "table-cell");
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    const cell = raw as Record<string, unknown>;
    const text = typeof cell.text === "string" ? cell.text : "";
    const customRuns = Array.isArray(cell.runs) ? cell.runs : null;
    const align = cell.align === "left" || cell.align === "center" || cell.align === "right" ? cell.align : (isHeader ? "center" : defaultAlign);
    const valign = cell.valign === "top" || cell.valign === "bottom" || cell.valign === "middle" ? cell.valign : "middle";
    const fillToken = typeof cell.fill === "string" ? cell.fill : isHeader ? "surface.subtle" : undefined;
    const colorToken = typeof cell.color === "string" ? cell.color : undefined;
    const bold = cell.bold === true || (style.weight === "bold");
    const runs: TextRun[] = customRuns
      ? customRuns.map((r) => richRunToTextRun(theme, r, style, bold))
      : [{ text, sizeHalfPt: style.fontSize * 2, bold, color: color(theme, colorToken, style.color), fontFace: containsCjk(text) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"), cjk: true }];
    return {
      runs,
      fill: fillToken ? { type: "solid", color: color(theme, fillToken) } : undefined,
      align,
      valign,
    };
  }
  const text = String(raw ?? "");
  return {
    runs: [{ text, sizeHalfPt: style.fontSize * 2, bold: style.weight === "bold", color: color(theme, undefined, style.color), fontFace: containsCjk(text) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"), cjk: true }],
    fill: isHeader ? { type: "solid", color: color(theme, "surface.subtle") } : undefined,
    align: isHeader ? "center" : defaultAlign,
    valign: "middle",
  };
}

function richRunToTextRun(theme: SimpleTheme, raw: unknown, style: ReturnType<typeof textStyle>, defaultBold: boolean): TextRun {
  const rec = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
  const text = typeof rec.text === "string" ? rec.text : "";
  const marks = Array.isArray(rec.marks) ? rec.marks.map(String) : [];
  return {
    text,
    sizeHalfPt: style.fontSize * 2,
    bold: defaultBold || marks.includes("bold") || marks.includes("emphasis") || rec.bold === true,
    italic: marks.includes("italic"),
    underline: marks.includes("underline"),
    color: color(theme, typeof rec.color === "string" ? rec.color : undefined, style.color),
    fontFace: marks.includes("code") ? preferredFont(theme, "mono") : containsCjk(text) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"),
    cjk: true,
    mono: marks.includes("code"),
    hyperlink: typeof rec.link === "string" ? rec.link : undefined,
    breakLine: rec.breakLine === true,
  };
}

function chartShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList[number] {
  const labels = Array.isArray(node.labels) ? node.labels.map(String) : [];
  const series = normalizeChartSeries(node.series);
  const customColors = Array.isArray(node.colors) ? node.colors.filter((c): c is string => typeof c === "string") : null;
  const palette = customColors && customColors.length > 0
    ? customColors.map((token) => color(theme, token))
    : (theme.chart?.series || ["brand.primary", "brand.primary.tint", "text.muted"]).map((token) => color(theme, token));
  const showLegend = typeof node.showLegend === "boolean" ? node.showLegend : series.length > 1;
  const annotations = normalizeChartAnnotations(node.annotations);
  return {
    type: "chart",
    id: ids.nextId++,
    name: nodeLabel(node),
    xfrm: xfrm(rect),
    chartType: chartType(node.chartType),
    labels,
    series,
    colors: palette,
    showLegend,
    showValues: Boolean(node.showValues),
    title: typeof node.title === "string" ? node.title : undefined,
    yFormat: chartNumberFormat(node.yFormat),
    annotations: annotations.length > 0 ? annotations : undefined,
  };
}

function normalizeChartAnnotations(value: unknown): ChartAnnotation[] {
  if (!Array.isArray(value)) return [];
  const out: ChartAnnotation[] = [];
  for (const raw of value) {
    if (!raw || typeof raw !== "object") continue;
    const rec = raw as Record<string, unknown>;
    const label = typeof rec.label === "string" ? rec.label : "";
    if (!label) continue;
    const ann: ChartAnnotation = { label };
    if (typeof rec.at === "number") ann.at = rec.at;
    if (Array.isArray(rec.range) && rec.range.length === 2 && typeof rec.range[0] === "number" && typeof rec.range[1] === "number") {
      ann.range = [rec.range[0], rec.range[1]];
    }
    if (rec.style === "callout" || rec.style === "marker" || rec.style === "band") ann.style = rec.style;
    out.push(ann);
  }
  return out;
}

function chartNumberFormat(value: unknown): ChartNumberFormat | undefined {
  if (value === "int" || value === "decimal" || value === "percent" || value === "wanyuan" || value === "yi") return value;
  return undefined;
}

function imageShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList {
  const src = stringProp(node, "src", "");
  if (!src) return [];
  const shape: ImageShape = {
    type: "image",
    id: ids.nextId++,
    name: nodeLabel(node),
    xfrm: xfrm(rect, node),
    src,
    altText: stringProp(node, "alt", nodeLabel(node)),
    fit: node.fit === "cover" || node.fit === "fill" ? node.fit : "contain",
  };
  if (node.clip === "rounded" || node.clip === "circle" || node.clip === "square") shape.clip = node.clip;
  if (typeof node.cornerRadius === "number") shape.cornerRadius = node.cornerRadius;
  const border = imageBorderSpec(theme, node);
  if (border) shape.border = border;
  const overlay = imageOverlaySpec(theme, node);
  if (overlay) shape.overlay = overlay;
  const crop = imageCropSpec(node);
  if (crop) shape.crop = crop;
  if (typeof node.softEdge === "number") shape.softEdge = node.softEdge;
  const shadow = imageShadowSpec(theme, node);
  if (shadow) shape.shadow = shadow;
  if (node.grayscale === true) shape.grayscale = true;
  if (typeof node.brightness === "number") shape.brightness = node.brightness;
  if (typeof node.blur === "number") shape.blur = node.blur;
  const duotone = imageDuotoneSpec(theme, node);
  if (duotone) shape.duotone = duotone;
  return [shape];
}

function imageBorderSpec(theme: SimpleTheme, node: DomNode): LineSpec | undefined {
  const raw = node.border;
  if (!raw || typeof raw !== "object") return undefined;
  const rec = raw as Record<string, unknown>;
  const colorToken = typeof rec.color === "string" ? rec.color : "divider";
  const width = typeof rec.width === "number" ? cm(rec.width) : cm(0.025);
  const dash = rec.dash === "dash" || rec.dash === "dashDot" || rec.dash === "dot" ? rec.dash : undefined;
  return { color: color(theme, colorToken), width, ...(dash ? { dash } : {}) };
}

function imageOverlaySpec(theme: SimpleTheme, node: DomNode): { color: string; alpha?: number } | undefined {
  const raw = node.overlay;
  if (!raw || typeof raw !== "object") return undefined;
  const rec = raw as Record<string, unknown>;
  if (typeof rec.color !== "string") return undefined;
  const out: { color: string; alpha?: number } = { color: color(theme, rec.color) };
  if (typeof rec.alpha === "number") out.alpha = rec.alpha;
  return out;
}

function imageCropSpec(node: DomNode): { left?: number; right?: number; top?: number; bottom?: number } | undefined {
  const raw = node.crop;
  if (!raw || typeof raw !== "object") return undefined;
  const rec = raw as Record<string, unknown>;
  const out: { left?: number; right?: number; top?: number; bottom?: number } = {};
  if (typeof rec.left === "number") out.left = rec.left;
  if (typeof rec.right === "number") out.right = rec.right;
  if (typeof rec.top === "number") out.top = rec.top;
  if (typeof rec.bottom === "number") out.bottom = rec.bottom;
  return Object.keys(out).length > 0 ? out : undefined;
}

function imageShadowSpec(theme: SimpleTheme, node: DomNode): { color: string; alpha?: number; blur?: number; dx?: number; dy?: number } | undefined {
  const raw = node.shadow;
  if (!raw || typeof raw !== "object") return undefined;
  const rec = raw as Record<string, unknown>;
  const colorToken = typeof rec.color === "string" ? rec.color : "111827";
  const out: { color: string; alpha?: number; blur?: number; dx?: number; dy?: number } = { color: color(theme, colorToken) };
  if (typeof rec.alpha === "number") out.alpha = rec.alpha;
  if (typeof rec.blur === "number") out.blur = rec.blur;
  if (typeof rec.dx === "number") out.dx = rec.dx;
  if (typeof rec.dy === "number") out.dy = rec.dy;
  return out;
}

function imageDuotoneSpec(theme: SimpleTheme, node: DomNode): { dark: string; light: string } | undefined {
  const raw = node.duotone;
  if (!raw || typeof raw !== "object") return undefined;
  const rec = raw as Record<string, unknown>;
  if (typeof rec.dark !== "string" || typeof rec.light !== "string") return undefined;
  return { dark: color(theme, rec.dark), light: color(theme, rec.light) };
}

function captionedShapes(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }, renderBody: (rect: Rect) => ShapeList): ShapeList {
  const caption = captionText(node);
  if (!caption) return renderBody(rect);
  const position = node.captionPosition;
  if (position === "none") return renderBody(rect);
  const { bodyRect, captionRect } = captionLayout(node, rect);
  const captionShape = textShape(theme, {
    id: `${node.id}.caption`,
    type: "text",
    text: caption,
    style: "figure-caption",
    align: position === "right" ? "left" : "center",
  }, captionRect, ids);
  return [
    ...renderBody(bodyRect),
    captionShape,
  ];
}

function captionText(node: DomNode): string {
  return typeof node.caption === "string" && node.caption.trim() ? node.caption.trim() : "";
}

function captionLayout(node: DomNode, rect: Rect): { bodyRect: Rect; captionRect: Rect } {
  const position = node.captionPosition;
  const gap = 0.1;
  if (position === "above") {
    const captionHeight = Math.min(0.72, Math.max(0.48, rect.h * 0.14));
    const bodyRect = { x: rect.x, y: rect.y + captionHeight + gap, w: rect.w, h: Math.max(0.2, rect.h - captionHeight - gap) };
    return { bodyRect, captionRect: { x: rect.x, y: rect.y, w: rect.w, h: captionHeight } };
  }
  if (position === "right") {
    const captionWidth = Math.min(7, Math.max(3.5, rect.w * 0.32));
    const bodyRect = { x: rect.x, y: rect.y, w: Math.max(0.2, rect.w - captionWidth - gap), h: rect.h };
    return { bodyRect, captionRect: { x: bodyRect.x + bodyRect.w + gap, y: rect.y, w: captionWidth, h: rect.h } };
  }
  const captionHeight = Math.min(0.72, Math.max(0.48, rect.h * 0.14));
  const bodyRect = { ...rect, h: Math.max(0.2, rect.h - captionHeight - gap) };
  return {
    bodyRect,
    captionRect: { x: rect.x, y: bodyRect.y + bodyRect.h + gap, w: rect.w, h: captionHeight },
  };
}

function textRuns(theme: SimpleTheme, node: DomNode, style: ReturnType<typeof textStyle>): TextRun[] {
  const content = node.content;
  if (Array.isArray(content)) {
    return content.map((raw) => {
      const record = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
      const text = typeof record.text === "string" ? record.text : "";
      const marks = Array.isArray(record.marks) ? record.marks.map(String) : [];
      return {
        text,
        sizeHalfPt: style.fontSize * 2,
        bold: style.weight === "bold" || marks.includes("bold") || marks.includes("emphasis"),
        italic: marks.includes("italic"),
        underline: marks.includes("underline"),
        color: color(theme, record.color, style.color),
        fontFace: marks.includes("code") ? preferredFont(theme, "mono") : containsCjk(text) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"),
        cjk: true,
        mono: marks.includes("code"),
        hyperlink: typeof record.link === "string" ? record.link : undefined,
        breakLine: record.breakLine === true,
      };
    });
  }
  const text = stringProp(node, "text", typeof content === "string" ? content : "");
  return [{
    text,
    sizeHalfPt: style.fontSize * 2,
    bold: style.weight === "bold",
    color: color(theme, node.color, style.color),
    fontFace: containsCjk(text) ? preferredFont(theme, "cjk") : preferredFont(theme, "latin"),
    cjk: true,
    mono: textStyleKey(node) === "code",
  }];
}

function materializeNode(node: DomNode, slideId: string): DomNode {
  const expanded = isComponentTypedNode(node) ? expandComponent(slideId, node) : node;
  return {
    ...expanded,
    children: expanded.children?.map((child) => materializeNode(child, slideId)),
  };
}

function compactifyNode(node: DomNode): DomNode | null {
  if (node.type === "bullets") {
    const items = bulletsItemsFromNode(node);
    if (items.length === 0) return null;
    return { ...node, items };
  }
  if (node.type === "text") {
    const text = typeof node.text === "string" ? node.text.trim() : "";
    const hasContent = Array.isArray(node.content) && node.content.length > 0;
    const hasParagraphs = Array.isArray(node.paragraphs) && node.paragraphs.length > 0;
    if (!text && !hasContent && !hasParagraphs) return null;
    return node;
  }
  if (Array.isArray(node.children)) {
    const compacted = node.children.map(compactifyNode).filter((c): c is DomNode => c !== null);
    if ((node.type === "stack" || node.type === "grid") && compacted.length === 0) return null;
    return { ...node, children: compacted };
  }
  return node;
}

function bulletsItemsFromNode(node: DomNode): unknown[] {
  if (Array.isArray(node.items) && node.items.length > 0) return node.items;
  for (const alias of ["bullets", "points", "list", "lines"]) {
    const value = node[alias];
    if (Array.isArray(value) && value.length > 0) return value;
  }
  return [];
}

function materializeDeck(deck: RenderedDeck): RenderedDeck {
  return {
    ...deck,
    slides: deck.slides.map((slide) => ({
      ...slide,
      dom: materializeAndCompactify(slide.dom, slide.id),
    })),
  };
}

function containerBackgroundShape(theme: SimpleTheme, node: DomNode, rect: Rect, ids: { nextId: number }): ShapeList {
  const style = componentStyle(theme, node);
  const fillToken = typeof node.fill === "string" ? node.fill : style.fill;
  const lineToken = typeof node.line === "string" ? node.line : style.line;
  if (!fillToken && !lineToken) return [];
  const cornerRadius = typeof node.cornerRadius === "number" ? node.cornerRadius : 0.08;
  return [{
    type: "shape",
    id: ids.nextId++,
    name: `${nodeLabel(node)}-background`,
    preset: "roundRect",
    xfrm: xfrm(rect),
    fill: fillToken ? { type: "solid", color: color(theme, fillToken) } : { type: "none" },
    line: lineToken ? { color: color(theme, lineToken), width: cm(0.02) } : undefined,
    cornerRadius,
  }];
}

function contentRect(theme: SimpleTheme, node: DomNode, rect: Rect): Rect {
  const style = componentStyle(theme, node);
  const pad = numberProp(node, "padding", style.padding ?? 0);
  if (pad <= 0) return rect;
  return {
    x: rect.x + pad,
    y: rect.y + pad,
    w: Math.max(0, rect.w - pad * 2),
    h: Math.max(0, rect.h - pad * 2),
  };
}

function layoutStackChildren(theme: SimpleTheme, node: DomNode, rect: Rect): Array<{ node: DomNode; rect: Rect }> {
  const children = node.children || [];
  if (children.length === 0) return [];
  const gap = gapCm(theme, node);
  const direction = node.direction === "horizontal" ? "horizontal" : "vertical";
  const mainSize = direction === "horizontal" ? rect.w : rect.h;
  const crossSize = direction === "horizontal" ? rect.h : rect.w;
  const availableMain = Math.max(0, mainSize - gap * (children.length - 1));
  const childSizes = resolveMainSizes(theme, children, direction, availableMain, crossSize);
  let cursor = direction === "horizontal" ? rect.x : rect.y;
  return children.map((child, index) => {
    const size = childSizes[index]!;
    const cross = childCrossRect(child, direction === "horizontal" ? rect.y : rect.x, crossSize, node, child);
    const childRect = direction === "horizontal"
      ? { x: cursor, y: cross.start, w: size, h: cross.size }
      : { x: cross.start, y: cursor, w: cross.size, h: size };
    cursor += size + gap;
    return { node: child, rect: childRect };
  });
}

function childCrossRect(child: DomNode, parentCrossStart: number, parentCrossSize: number, parent: DomNode, _self: DomNode): { start: number; size: number } {
  const align = stringProp(child, "align", stringProp(parent, "align", "stretch"));
  const valign = stringProp(child, "valign", stringProp(parent, "valign", "stretch"));
  const isHorizontal = parent.direction === "horizontal";
  const crossAlign = isHorizontal ? valign : align;
  const fixedCross = optionalNumberProp(child, isHorizontal ? "fixedHeight" : "fixedWidth");
  if (fixedCross === undefined || crossAlign === "stretch") return { start: parentCrossStart, size: parentCrossSize };
  const size = Math.min(fixedCross, parentCrossSize);
  if (crossAlign === "center" || crossAlign === "middle") return { start: parentCrossStart + (parentCrossSize - size) / 2, size };
  if (crossAlign === "end" || crossAlign === "bottom" || crossAlign === "right") return { start: parentCrossStart + parentCrossSize - size, size };
  return { start: parentCrossStart, size };
}

function layoutGridChildren(theme: SimpleTheme, node: DomNode, rect: Rect): Array<{ node: DomNode; rect: Rect }> {
  const children = node.children || [];
  if (children.length === 0) return [];
  const columns = Math.max(1, numberProp(node, "columns", 2));
  const rows = Math.ceil(children.length / columns);
  const gap = gapCm(theme, node);
  const availableWidth = Math.max(0, rect.w - gap * (columns - 1));
  const availableHeight = Math.max(0, rect.h - gap * (rows - 1));
  const columnWeights = weightsFromProp(node.columnWeights, columns);
  const colX = positionsFromWeights(rect.x, availableWidth, gap, columnWeights);
  const rowHeights = resolveGridRowHeights(theme, children, columns, rows, availableHeight, colX.map((col) => col.size), node.rowWeights);
  const rowY = positionsFromSizes(rect.y, gap, rowHeights);
  return children.map((child, index) => {
    const col = index % columns;
    const row = Math.floor(index / columns);
    return { node: child, rect: { x: colX[col]!.start, y: rowY[row]!.start, w: colX[col]!.size, h: rowY[row]!.size } };
  });
}

function resolveMainSizes(theme: SimpleTheme, children: DomNode[], direction: "horizontal" | "vertical", availableMain: number, crossSize: number): number[] {
  return solveSizes(children.map((child) => childMainSpec(theme, child, direction, crossSize)), availableMain);
}

interface SizeSpec {
  basis: number;
  min: number;
  max: number;
  weight: number;
  grow: boolean;
  fixed: boolean;
}

function childMainSpec(theme: SimpleTheme, node: DomNode, direction: "horizontal" | "vertical", crossSize: number): SizeSpec {
  const fixed = optionalNumberProp(node, direction === "horizontal" ? "fixedWidth" : "fixedHeight");
  const intrinsic = intrinsicMainSize(theme, node, direction, crossSize);
  const min = optionalNumberProp(node, direction === "horizontal" ? "minWidth" : "minHeight") ?? intrinsicMinSize(theme, node, direction, crossSize);
  const max = optionalNumberProp(node, direction === "horizontal" ? "maxWidth" : "maxHeight") ?? Number.POSITIVE_INFINITY;
  const hasExplicitWeight = optionalNumberProp(node, "layoutWeight") !== undefined;
  const isContainer = node.type === "stack" || node.type === "grid";
  // For containers, fixedHeight/Width is treated as a soft minimum: if the children's
  // natural intrinsic size exceeds it, let the container grow so children aren't crushed.
  const naturalContainerMain = isContainer && fixed !== undefined
    ? containerNaturalMainSize(theme, node, direction, crossSize)
    : undefined;
  const effectiveFixed = (isContainer && fixed !== undefined && naturalContainerMain !== undefined && naturalContainerMain > fixed)
    ? undefined
    : fixed;
  const fixedSize = effectiveFixed === undefined ? undefined : Math.max(0, effectiveFixed);
  const defaultWeight = node.type === "image" ? theme.imageGrowWeight : 1;
  if (fixedSize === undefined) {
    const lower = isContainer && fixed !== undefined ? Math.max(min, fixed) : Math.max(0, min);
    const basisCandidate = isContainer && naturalContainerMain !== undefined ? naturalContainerMain : intrinsic;
    return {
      basis: clamp(basisCandidate, lower, max),
      min: lower,
      max: Math.max(lower, max),
      weight: Math.max(0.0001, numberProp(node, "layoutWeight", defaultWeight)),
      grow: hasExplicitWeight || canGrow(node),
      fixed: false,
    };
  }
  return {
    basis: fixedSize,
    min: fixedSize,
    max: fixedSize,
    weight: Math.max(0.0001, numberProp(node, "layoutWeight", defaultWeight)),
    grow: false,
    fixed: true,
  };
}

function containerNaturalMainSize(theme: SimpleTheme, node: DomNode, direction: "horizontal" | "vertical", crossSize: number): number {
  if (direction === "vertical") {
    if (node.type === "stack") return stackIntrinsicHeight(theme, node, crossSize);
    if (node.type === "grid") return gridIntrinsicHeight(theme, node, crossSize);
    return 0;
  }
  if (node.type === "stack" && node.direction === "horizontal") return horizontalStackIntrinsicWidth(theme, node, crossSize);
  return crossSize;
}

const sizeOverflowWarnings = new Set<string>();

export function listSizeOverflowWarnings(): string[] {
  return Array.from(sizeOverflowWarnings);
}

export function clearSizeOverflowWarnings(): void {
  sizeOverflowWarnings.clear();
}

function solveSizes(specs: SizeSpec[], availableMain: number): number[] {
  if (specs.length === 0) return [];
  const available = Math.max(0, availableMain);
  const sizes = specs.map((spec) => clamp(spec.basis, spec.min, spec.max));
  const total = sizes.reduce((sum, size) => sum + size, 0);
  if (total > available) return shrinkSizes(specs, sizes, available);
  if (total < available) return growSizes(specs, sizes, available - total);
  return sizes;
}

function shrinkSizes(specs: SizeSpec[], sizes: number[], available: number): number[] {
  let overflow = sizes.reduce((sum, size) => sum + size, 0) - available;
  const shrinkable = specs.map((spec, index) => ({ spec, index })).filter(({ spec, index }) => !spec.fixed && sizes[index]! > spec.min);
  while (overflow > 0.0001 && shrinkable.some(({ spec, index }) => sizes[index]! > spec.min + 0.0001)) {
    const capacities = shrinkable.map(({ spec, index }) => Math.max(0, sizes[index]! - spec.min));
    const totalCapacity = capacities.reduce((sum, capacity) => sum + capacity, 0);
    if (totalCapacity <= 0) break;
    shrinkable.forEach(({ spec, index }, listIndex) => {
      const reduction = Math.min(sizes[index]! - spec.min, overflow * (capacities[listIndex]! / totalCapacity));
      sizes[index] -= reduction;
    });
    overflow = sizes.reduce((sum, size) => sum + size, 0) - available;
  }
  if (overflow > 0.0001) {
    sizeOverflowWarnings.add(`overflow=${overflow.toFixed(2)}cm; available=${available.toFixed(2)}cm`);
    return fitToAvailableRespectingFixed(specs, sizes, available);
  }
  return sizes;
}

function growSizes(specs: SizeSpec[], sizes: number[], extra: number): number[] {
  let remaining = extra;
  let growIndexes = specs.map((spec, index) => spec.grow && sizes[index]! < spec.max ? index : -1).filter((index) => index >= 0);
  while (remaining > 0.0001 && growIndexes.length > 0) {
    const weights = normalizeWeights(growIndexes.map((index) => specs[index]!.weight));
    let consumed = 0;
    growIndexes.forEach((index, weightIndex) => {
      const room = specs[index]!.max - sizes[index]!;
      const addition = Math.min(room, remaining * weights[weightIndex]!);
      sizes[index] += addition;
      consumed += addition;
    });
    if (consumed <= 0.0001) break;
    remaining -= consumed;
    growIndexes = growIndexes.filter((index) => sizes[index]! < specs[index]!.max - 0.0001);
  }
  return sizes;
}

function intrinsicMainSize(theme: SimpleTheme, node: DomNode, direction: "horizontal" | "vertical", crossSize: number): number {
  const fixed = optionalNumberProp(node, direction === "horizontal" ? "fixedWidth" : "fixedHeight");
  if (fixed !== undefined) return fixed;
  if (direction === "horizontal") {
    if (node.type === "image") return Math.min(12, Math.max(6, crossSize * 0.9));
    if (node.type === "text") return textIntrinsicWidth(theme, node);
    if (node.type === "divider") return numberProp(node, "thickness", 0.025) + 0.02;
    if (node.type === "stack" && node.direction === "horizontal") return horizontalStackIntrinsicWidth(theme, node, crossSize);
    return 3.2;
  }
  if (node.type === "text") return textIntrinsicHeight(theme, node, crossSize);
  if (node.type === "bullets") return bulletsIntrinsicHeight(theme, node, crossSize);
  if (node.type === "spacer") return direction === "vertical" ? 0.4 : 0.6;
  if (node.type === "divider") return numberProp(node, "thickness", 0.025) + 0.02;
  if (node.type === "image") return Math.min(10, Math.max(4, crossSize * 0.62));
  if (node.type === "stack") return stackIntrinsicHeight(theme, node, crossSize);
  if (node.type === "grid") return gridIntrinsicHeight(theme, node, crossSize);
  return 2;
}

function intrinsicMinSize(theme: SimpleTheme, node: DomNode, direction: "horizontal" | "vertical", crossSize: number): number {
  const explicit = optionalNumberProp(node, direction === "horizontal" ? "minWidth" : "minHeight");
  if (explicit !== undefined) return explicit;
  if (direction === "horizontal") return Math.min(intrinsicMainSize(theme, node, direction, crossSize), node.type === "divider" ? 0.02 : 0.45);
  if (node.type === "text") return singleLineTextHeight(theme, node);
  if (node.type === "bullets") return 0.8;
  if (node.type === "divider") return numberProp(node, "thickness", 0.025) + 0.02;
  if (node.type === "spacer") return 0;
  return Math.min(intrinsicMainSize(theme, node, direction, crossSize), 0.9);
}

function canGrow(node: DomNode): boolean {
  return node.type === "image" || node.type === "grid" || node.type === "stack" || node.type === "table" || node.type === "chart" || node.type === "shape" || node.type === "spacer" || node.fill === true;
}

function stackIntrinsicHeight(theme: SimpleTheme, node: DomNode, crossSize: number): number {
  const children = node.children || [];
  if (children.length === 0) return 0;
  const gap = gapCm(theme, node);
  const pad = paddingCm(theme, node);
  const innerWidth = Math.max(0, crossSize - pad * 2);
  if (node.direction === "horizontal") {
    const availableWidth = Math.max(0, innerWidth - gap * Math.max(0, children.length - 1));
    const widths = resolveMainSizes(theme, children, "horizontal", availableWidth, 10);
    const childHeights = children.map((child, index) => intrinsicMainSize(theme, child, "vertical", widths[index] || innerWidth));
    return Math.max(0, ...childHeights) + pad * 2;
  }
  const fixed = children.reduce((sum, child) => sum + intrinsicMainSize(theme, child, "vertical", innerWidth), 0);
  return fixed + gap * Math.max(0, children.length - 1) + pad * 2;
}

function horizontalStackIntrinsicWidth(theme: SimpleTheme, node: DomNode, heightCm: number): number {
  const children = node.children || [];
  if (children.length === 0) return 0;
  const gap = gapCm(theme, node);
  const pad = paddingCm(theme, node);
  return children.reduce((sum, child) => sum + intrinsicMainSize(theme, child, "horizontal", heightCm), 0) + gap * Math.max(0, children.length - 1) + pad * 2;
}

function gridIntrinsicHeight(theme: SimpleTheme, node: DomNode, widthCm: number): number {
  const children = node.children || [];
  if (children.length === 0) return 0;
  const columns = Math.max(1, numberProp(node, "columns", 2));
  const rows = Math.ceil(children.length / columns);
  const gap = gapCm(theme, node);
  const columnWeights = weightsFromProp(node.columnWeights, columns);
  const contentWidth = contentRect(theme, node, { x: 0, y: 0, w: widthCm, h: 10 }).w;
  const availableWidth = Math.max(0, contentWidth - gap * (columns - 1));
  const colWidths = columnWeights.map((weight) => availableWidth * weight);
  let total = 0;
  for (let row = 0; row < rows; row++) {
    let rowHeight = 0;
    for (let col = 0; col < columns; col++) {
      const child = children[row * columns + col];
      if (!child) continue;
      rowHeight = Math.max(rowHeight, intrinsicMainSize(theme, child, "vertical", colWidths[col] || availableWidth / columns));
    }
    total += rowHeight;
  }
  return total + gap * Math.max(0, rows - 1);
}

function resolveGridRowHeights(theme: SimpleTheme, children: DomNode[], columns: number, rows: number, availableHeight: number, colWidths: number[], rowWeightsValue: unknown): number[] {
  const rowWeights = weightsFromProp(rowWeightsValue, rows);
  const specs: SizeSpec[] = [];
  for (let row = 0; row < rows; row++) {
    let basis = 0;
    let min = 0.4;
    for (let col = 0; col < columns; col++) {
      const child = children[row * columns + col];
      if (!child) continue;
      const width = colWidths[col] || colWidths[0] || 1;
      basis = Math.max(basis, intrinsicMainSize(theme, child, "vertical", width));
      min = Math.max(min, intrinsicMinSize(theme, child, "vertical", width));
    }
    specs.push({ basis, min, max: Number.POSITIVE_INFINITY, weight: rowWeights[row] || 1, grow: true, fixed: false });
  }
  return solveSizes(specs, availableHeight);
}

function textIntrinsicHeight(theme: SimpleTheme, node: DomNode, widthCm: number): number {
  const style = textStyle(theme, textStyleKey(node), "paragraph");
  const fontPt = style.fontSize;
  const text = stringProp(node, "text", typeof node.content === "string" ? node.content : "");
  const charWidthCm = avgCharWidthCm(theme, fontPt);
  const charsPerLine = Math.max(8, Math.floor(widthCm / charWidthCm));
  const lines = Math.max(1, Math.ceil(weightedTextLength(text) / charsPerLine));
  const boxPadding = typeof node.fill === "string" || typeof node.line === "string" ? 0.28 : 0.18;
  return Math.min(8, Math.max(fontPt * 0.0353 * style.lineHeight + boxPadding, lines * fontPt * 0.0353 * style.lineHeight + boxPadding));
}

function componentStyle(theme: SimpleTheme, node: DomNode) {
  return typeof node.role === "string" ? theme.component[node.role] || {} : {};
}

function gapCm(theme: SimpleTheme, node: DomNode): number {
  return numberProp(node, "gap", theme.layout.defaultGap);
}

function paddingCm(theme: SimpleTheme, node: DomNode): number {
  const style = componentStyle(theme, node);
  return numberProp(node, "padding", style.padding ?? 0);
}

function avgCharWidthCm(theme: SimpleTheme, fontPt: number): number {
  const latin = preferredFont(theme, "latin").toLowerCase();
  const factor = latin.includes("aptos") || latin.includes("calibri") ? 0.0175 : latin.includes("arial") ? 0.0185 : 0.018;
  return fontPt * factor;
}

function textIntrinsicWidth(theme: SimpleTheme, node: DomNode): number {
  const style = textStyle(theme, textStyleKey(node), "paragraph");
  const text = stringProp(node, "text", typeof node.content === "string" ? node.content : "");
  const weighted = weightedTextLength(text.replace(/\n/g, " "));
  const width = weighted * avgCharWidthCm(theme, style.fontSize) + 0.35;
  return Math.min(8, Math.max(0.45, width));
}

function bulletsIntrinsicHeight(theme: SimpleTheme, node: DomNode, widthCm: number): number {
  const items = Array.isArray(node.items) ? node.items.map(String) : [""];
  const style = textStyle(theme, node.density === "compact" ? "bullet-compact" : "bullet", "paragraph");
  const charWidthCm = avgCharWidthCm(theme, style.fontSize);
  const charsPerLine = Math.max(8, Math.floor(widthCm / charWidthCm));
  const lineCount = items.reduce((sum, item) => sum + Math.max(1, Math.ceil(weightedTextLength(item) / charsPerLine)), 0);
  const lineHeight = style.fontSize * 0.0353 * style.lineHeight;
  const paragraphGap = (node.density === "compact" ? 0.012 : 0.018) * style.fontSize;
  const titleHeight = typeof node.title === "string" && node.title.trim() ? 0.62 : 0;
  return Math.max(1.05, titleHeight + lineCount * lineHeight + Math.max(0, items.length - 1) * paragraphGap + 0.35);
}

function singleLineTextHeight(theme: SimpleTheme, node: DomNode): number {
  const style = textStyle(theme, textStyleKey(node), "paragraph");
  return style.fontSize * 0.0353 * style.lineHeight + 0.16;
}

function textStyleKey(node: DomNode): string {
  if (typeof node.style === "string" && node.style.trim()) return node.style;
  return inferTextKind(node).kind;
}

function nodeLabel(node: DomNode): string {
  return node.id;
}

function weightedTextLength(text: string): number {
  let length = 0;
  for (const char of text) length += /[\u4e00-\u9fff]/.test(char) ? 1.05 : 0.58;
  return length;
}

function fitToAvailableRespectingFixed(specs: SizeSpec[], sizes: number[], availableMain: number): number[] {
  const fixedTotal = specs.reduce((sum, spec, index) => sum + (spec.fixed ? sizes[index]! : 0), 0);
  const flexTotal = sizes.reduce((sum, size, index) => sum + (specs[index]!.fixed ? 0 : size), 0);
  const flexAvailable = Math.max(0, availableMain - fixedTotal);
  if (flexTotal <= 0) return sizes;
  if (flexTotal <= flexAvailable) return sizes;
  const scale = flexAvailable / flexTotal;
  return sizes.map((size, index) => specs[index]!.fixed ? size : size * scale);
}

function weightsFromProp(value: unknown, count: number): number[] {
  if (Array.isArray(value) && value.length === count) {
    return normalizeWeights(value.map((item) => typeof item === "number" && Number.isFinite(item) && item > 0 ? item : 1));
  }
  return normalizeWeights(Array.from({ length: count }, () => 1));
}

function normalizeWeights(values: number[]): number[] {
  const total = values.reduce((sum, value) => sum + Math.max(value, 0), 0);
  if (total <= 0) return values.map(() => 1 / values.length);
  return values.map((value) => Math.max(value, 0) / total);
}

function positionsFromWeights(start: number, availableSize: number, gap: number, weights: number[]): Array<{ start: number; size: number }> {
  const sizes = weights.map((weight) => availableSize * weight);
  return positionsFromSizes(start, gap, sizes);
}

function positionsFromSizes(start: number, gap: number, sizes: number[]): Array<{ start: number; size: number }> {
  const items: Array<{ start: number; size: number }> = [];
  let cursorEmu = Math.round(start * EMU_PER_CM);
  const gapEmu = Math.round(gap * EMU_PER_CM);
  for (const size of sizes) {
    const sizeEmu = Math.round(size * EMU_PER_CM);
    items.push({ start: cursorEmu / EMU_PER_CM, size: sizeEmu / EMU_PER_CM });
    cursorEmu += sizeEmu + gapEmu;
  }
  return items;
}

function fullRect(theme: SimpleTheme): Rect {
  return { x: 0, y: 0, w: theme.layout.slideWidthCm, h: theme.layout.slideHeightCm };
}

function xfrm(rect: Rect, node?: DomNode) {
  const base: { x: number; y: number; cx: number; cy: number; rot?: number; flipH?: boolean; flipV?: boolean } = {
    x: cm(rect.x), y: cm(rect.y), cx: cm(rect.w), cy: cm(rect.h),
  };
  if (node) {
    if (typeof node.rotation === "number" && node.rotation !== 0) base.rot = Math.round(node.rotation * 60000);
    if (node.flipH === true) base.flipH = true;
    if (node.flipV === true) base.flipV = true;
  }
  return base;
}

function cm(value: number): number {
  return Math.round(value * EMU_PER_CM);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function stringProp(node: DomNode, key: string, fallback: string): string {
  const value = node[key];
  return typeof value === "string" ? value : fallback;
}

function numberProp(node: DomNode, key: string, fallback: number): number {
  const value = node[key];
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function optionalNumberProp(node: DomNode, key: string): number | undefined {
  const value = node[key];
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function alignProp(node: DomNode): "left" | "center" | "right" {
  return node.align === "center" || node.align === "right" ? node.align : "left";
}

function valignProp(node: DomNode, kind: string): "top" | "middle" | "bottom" {
  if (node.valign === "top" || node.valign === "bottom" || node.valign === "middle") return node.valign;
  if (kind === "paragraph" || kind === "article" || kind === "lead" || kind === "footnote" || kind === "caption" || kind === "figure-caption" || kind === "code") return "top";
  return "middle";
}

function containsCjk(text: string): boolean {
  return /[\u4e00-\u9fff]/.test(text);
}

function chartType(value: unknown): ChartType {
  if (value === "line" || value === "pie" || value === "doughnut" || value === "area" ||
      value === "stacked-bar" || value === "combo" || value === "scatter" || value === "waterfall") return value;
  return "bar";
}

function normalizeChartSeries(value: unknown): ChartSeries[] {
  if (!Array.isArray(value)) return [];
  const output: ChartSeries[] = [];
  value.forEach((item, index) => {
    if (!item || typeof item !== "object") return null;
    const record = item as Record<string, unknown>;
    const name = typeof record.name === "string" ? record.name : `Series ${index + 1}`;
    if (Array.isArray(record.points)) {
      const points = record.points
        .filter((p): p is Record<string, unknown> => Boolean(p && typeof p === "object"))
        .map((p) => ({ x: Number(p.x), y: Number(p.y) }))
        .filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y));
      if (points.length > 0) output.push({ name, values: [], points });
      return;
    }
    const values = Array.isArray(record.values)
      ? record.values.map((v) => v === null ? null : Number(v)).filter((v): v is number | null => v === null || Number.isFinite(v))
      : [];
    if (values.length === 0) return;
    const series: ChartSeries = { name, values };
    if (record.type === "bar" || record.type === "line") series.type = record.type;
    output.push(series);
  });
  return output;
}
