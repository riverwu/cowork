export type SlideSize = "16x9";

export interface Slideml2Deck {
  slideml2: 1;
  deck: DeckSpec;
  slides: SlideSpec[];
}

export interface DeckSpec {
  size?: SlideSize;
  theme?: "default" | "enterprise-light" | "technical-blue" | "simple" | string;
  brand?: BrandSpec;
  chrome?: ChromeSpec;
  metadata?: Record<string, unknown>;
}

export interface BrandSpec {
  name?: string;
  primary?: string;
  logo?: string;
}

export type LayoutName = "cover" | "title-and-content" | "image-and-text";

export interface SlideSpec {
  id: string;
  layout: LayoutName;
  title?: string;
  subtitle?: string;
  items?: string[];
  image?: string;
  text?: string;
}

export interface SlideV2 {
  id: string;
  title?: string;
  background?: string;
  children: DomNode[];
  notes?: string;
  metadata?: Record<string, unknown>;
}

export interface Slideml2SourceDeck {
  slideml2: 2;
  deck: Required<Pick<DeckSpec, "size">> & Omit<DeckSpec, "size">;
  slides: SlideV2[];
}

export interface ChromeSpec {
  brandMark?: "none" | "top-right" | "bottom-right";
  pageNumber?: boolean;
  footerText?: string;
}

export type NodeType = "slide" | "stack" | "grid" | "spacer" | "divider" | "text" | "bullets" | "image" | "table" | "chart" | "shape" | "component";

export type TextContent = string | RichTextRun[];

export interface RichTextRun {
  text: string;
  marks?: Array<"bold" | "italic" | "underline" | "code" | "emphasis">;
  color?: string;
  link?: string;
  breakLine?: boolean;
}

export interface RichParagraph {
  text?: string;
  runs?: RichTextRun[];
  align?: "left" | "center" | "right" | "justify";
  indentLevel?: number;
  lineSpacing?: number;
  spaceAfter?: number;
  bullet?: "auto" | "number" | "none";
  style?: string;
  color?: string;
}

export type AnchorPoint =
  | "top-left" | "top-center" | "top-right"
  | "middle-left" | "middle-center" | "middle-right"
  | "bottom-left" | "bottom-center" | "bottom-right";

export interface CellSpec {
  text?: string;
  runs?: RichTextRun[];
  align?: "left" | "center" | "right";
  valign?: "top" | "middle" | "bottom";
  fill?: string;
  color?: string;
  bold?: boolean;
  colspan?: number;
  rowspan?: number;
}

export interface ChartAnnotationSpec {
  at?: number;
  range?: [number, number];
  label: string;
  style?: "callout" | "marker" | "band";
}

export interface DomNode {
  id: string;
  type: NodeType | string;
  children?: DomNode[];
  [property: string]: any;
}

export interface RenderedSlide {
  id: string;
  layout: LayoutName;
  dom: DomNode;
}

export interface RenderedDeck {
  deck: Required<Pick<DeckSpec, "size" | "theme">> & { brand: BrandSpec };
  slides: RenderedSlide[];
}

export type EditOp =
  | { op: "setSlideProp"; slideId: string; prop: string; value: unknown }
  | { op: "setNodeProp"; slideId: string; nodeName: string; prop: string; value: unknown }
  | { op: "insertNode"; slideId: string; parentName: string; node: DomNode; position?: InsertPosition }
  | { op: "deleteNode"; slideId: string; nodeName: string };

export type InsertPosition =
  | "first"
  | "last"
  | { before: string }
  | { after: string }
  | { index: number };

export interface AuditIssue {
  code: string;
  slideId?: string;
  nodeName?: string;
  message: string;
}

export interface AuditReport {
  ok: boolean;
  issues: AuditIssue[];
}

export interface AgentTask {
  requireCoverBrandBackground?: boolean;
  requireBrandLogoBottomRight?: boolean;
  requireBusinessBullets?: boolean;
  requireCompanyOverviewLayout?: {
    slideId: string;
  };
}
