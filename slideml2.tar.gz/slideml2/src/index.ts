export { auditDeck } from "./audit.js";
export { applyEdits } from "./edit.js";
export { inspectDeck } from "./inspect.js";
export { buildDom, getSlide } from "./layouts.js";
export { renderToAst, renderToPptx } from "./render.js";
export { buildTheme } from "./theme.js";
export { runSimpleAgentLoop } from "./agent/loop.js";
export { deckFromPlan, generateFromMarkdown, planPagesFromMarkdown, planPagesFromMarkdownWithLlm } from "./agent/markdown-pipeline.js";
export { deckFromComponentPlan, generateWithComponentAgent, planWithComponentAgent } from "./agent/component-agent.js";
export { generateDeckWithBatchAgent, generateOneSlideWithLlm } from "./agent/batch-agent.js";
export { buildAgentPromptPack, getAgentSystemPrompt } from "./agent-disclosure.js";
export { designComparisonSlide, designComplexDeck, designDashboardSlide, designDeckFromBrief, designSlideFromBrief, designTimelineSlide } from "./agent/page-designer.js";
export {
  bulletList, companyOverviewLayout, comparisonCard, ctaButton, iconText, imageBlock,
  imageWithCaptionPanel, insightCallout, kpiGrid, metricCard, numberedList, paragraphText,
  profileCard, quoteBlock, sectionBreak, stepCard, swotMatrix, timelineBlock, titleText,
} from "./components.js";
export { listComponents, describeComponents } from "./component-registry.js";
export type { DescribeComponentsResult } from "./component-registry.js";
export { describeDeck } from "./deck-disclosure.js";
export type { DeckDescription, DeckFieldDescription } from "./deck-disclosure.js";
export { listTextKinds, describeTextKind } from "./text-kinds.js";
export { listThemes } from "./theme.js";
export { createDeck, setDeckProps, appendSlide, insertSlide, replaceSlide, deleteSlide, validateDeckPath, renderDeck } from "./deck-ops.js";
export { createSourceDeck, sourceToRenderedDeck } from "./source-deck.js";
export { validateDeck, validateSlide } from "./validate.js";
export { generateBriefLayoutDemo, generateComplexLayoutDemo, generateComponentLayoutDemo, generateMarkdownPipelineDemo } from "./demo.js";
export type {
  AgentTask,
  AuditIssue,
  AuditReport,
  BrandSpec,
  DeckSpec,
  DomNode,
  EditOp,
  InsertPosition,
  LayoutName,
  NodeType,
  RenderedDeck,
  RenderedSlide,
  SlideSize,
  SlideSpec,
  Slideml2Deck,
} from "./types.js";
export type { MarkdownPlan, MarkdownPipelineResult, PlannedPage } from "./agent/markdown-pipeline.js";
export type { AgentComponentNode, AgentNode, AgentPrimitiveNode, ComponentAgentPlan, ComponentAgentResult, ComponentAgentSlidePlan } from "./agent/component-agent.js";
export type { BatchAgentResult } from "./agent/batch-agent.js";
export type { AgentPromptPackOptions } from "./agent-disclosure.js";
export type { ComponentDefinition, ComponentDescription, ComponentSummary } from "./component-registry.js";
export type { ValidationReport, ValidationIssue } from "./validate.js";
