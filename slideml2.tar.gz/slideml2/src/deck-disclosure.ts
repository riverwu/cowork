import { buildTheme, listThemes } from "./theme.js";

export interface DeckFieldDescription {
  type: "string" | "number" | "boolean" | "enum" | "object";
  required?: boolean;
  enum?: string[];
  description: string;
  default?: unknown;
}

export interface DeckDescription {
  size: { value: "16x9"; slideWidthCm: number; slideHeightCm: number };
  contentArea: {
    marginX: number;
    titleTop: number;
    titleHeight: number;
    contentTop: number;
    contentBottom: number;
    contentHeight: number;
    description: string;
  };
  themes: { available: string[]; default: string; description: string };
  brand: { description: string; fields: Record<string, DeckFieldDescription>; example: unknown };
  chrome: { description: string; fields: Record<string, DeckFieldDescription>; example: unknown };
  colorTokens: { description: string; tokens: string[] };
  textStyles: { description: string; styles: string[] };
  slideRoot: { description: string; fields: Record<string, DeckFieldDescription> };
  layoutPrinciples: string[];
  consistencyPrinciples: string[];
  textHygiene: string[];
  componentChoiceGuidelines: string[];
  doNot: string[];
}

export function describeDeck(): DeckDescription {
  const sample = buildTheme();
  const layout = sample.layout;
  const contentHeight = sample.layout.slideHeightCm - layout.contentTop - layout.contentBottom;
  const colorTokens = Object.keys(sample.colors).sort();
  const textStyles = Object.keys(sample.text).sort();
  return {
    size: { value: "16x9", slideWidthCm: layout.slideWidthCm, slideHeightCm: layout.slideHeightCm },
    contentArea: {
      marginX: layout.pageMarginX,
      titleTop: layout.titleTop,
      titleHeight: layout.titleHeight,
      contentTop: layout.contentTop,
      contentBottom: layout.contentBottom,
      contentHeight,
      description: `Title sits at y=${layout.titleTop}cm with height ${layout.titleHeight}cm. The content rect (area:'content') spans x=${layout.pageMarginX}..${(layout.slideWidthCm - layout.pageMarginX).toFixed(2)}, y=${layout.contentTop}..${(layout.slideHeightCm - layout.contentBottom).toFixed(2)} (height ${contentHeight.toFixed(2)}cm). All cm.`,
    },
    themes: {
      available: listThemes(),
      default: "default",
      description: "Pick one theme per deck. Themes pre-tune typography, palettes, chrome, and component padding/radius. Do not change theme between slides.",
    },
    brand: {
      description: "Brand identity injected into every slide. Drives brand.primary token, derived brand.tint and brand.shade, optional logo placement via chrome.brandMark.",
      fields: {
        name: { type: "string", description: "Brand or product name (used by metadata, not rendered as text)." },
        primary: { type: "string", description: "6-char hex (no '#'). Becomes brand.primary; derived tint + shade tokens are auto-mixed." },
        logo: { type: "string", description: "Absolute path, URL, or data URL to a logo image. Required for chrome.brandMark != 'none'." },
      },
      example: { name: "Youdao", primary: "E8382C", logo: "/abs/path/logo.png" },
    },
    chrome: {
      description: "Per-deck decorations stamped onto every slide by the renderer. Set once at deck level; do not duplicate inside slide DOMs.",
      fields: {
        brandMark: { type: "enum", enum: ["none", "top-right", "bottom-right"], description: "Logo placement. 'none' suppresses it.", default: "none" },
        pageNumber: { type: "boolean", description: "Render '1 / N' page counter in the footer.", default: false },
        footerText: { type: "string", description: "Optional footer text (left side)." },
      },
      example: { brandMark: "bottom-right", pageNumber: true, footerText: "Internal use" },
    },
    colorTokens: {
      description: "Use these tokens anywhere a color is expected (fill, line, color). Avoid raw hex except for one-off accents. Tokens auto-update when theme or brand.primary changes.",
      tokens: colorTokens,
    },
    textStyles: {
      description: "Each text node has an inferred or explicit `style`. These names map to font sizes, weights, and colors managed by the theme — do NOT set fontSize on text nodes.",
      styles: textStyles,
    },
    slideRoot: {
      description: "Top-level slide DOM has type:'slide' and exactly one direct child with area:'content'. Optional title is a slide-title text node placed by the renderer at the top.",
      fields: {
        background: { type: "string", description: "theme token or 6-char hex; sets the slide fill." },
        notes: { type: "string", description: "Speaker notes (markdown-inline)." },
      },
    },
    layoutPrinciples: [
      "One central message per slide. The slide-title is the headline; the body proves it once.",
      "Use exactly one stack/grid with area:'content' as the slide's root container; never place primitives directly under slide.",
      "Prefer auto-layout (stack/grid) over absolute positioning. Use the anchor/zIndex overlay system only for chrome-style decorations.",
      "Respect the content rect bounds. If your intrinsic content is taller than the area, split into two slides instead of shrinking text.",
      "Leave breathing room. A grid with > 4 columns or a stack with > 6 vertical children almost always feels cramped.",
      "Use spacer for intentional asymmetry; do not pad with empty text nodes.",
      "Align: visually heavy elements (image, chart, big metric) deserve at least 40% of the content rect to read confidently.",
    ],
    consistencyPrinciples: [
      "Same content type, same layout. If two slides each show a 3-way comparison, both should use the same comparison-card grid pattern with the same column count.",
      "Same role across the deck means same component. Don't alternate between metric-card and a hand-rolled stack of texts for KPIs.",
      "Pick one accent color (brand.primary) for emphasis; do not introduce a second highlight color per slide.",
      "Page numbering and brand mark are deck-level decisions — set them once via chrome, do not toggle per slide.",
      "Title casing, punctuation, and language must be uniform (all Chinese or all English; consistent ending punctuation).",
      "Section-break slides should appear at chapter boundaries, never as a stand-alone closing slide.",
    ],
    textHygiene: [
      "Slide title ≤ 18 CJK chars / 60 latin chars; otherwise split.",
      "Card title (h2 / metric label / step-card title) ≤ 10 CJK chars / 30 latin chars to fit one line.",
      "Bullet item ≤ 22 CJK chars / 70 latin chars; longer than that, demote into paragraph or split.",
      "Callout ≤ 40 CJK chars / 120 latin chars to fit two lines.",
      "Metric value should be one short token (number+unit), not a sentence.",
      "Avoid trailing period on labels and bullets unless they are full sentences.",
    ],
    componentChoiceGuidelines: [
      "One headline insight → `callout` or a single `lead` paragraph.",
      "Many KPIs → `kpi-grid` or `grid` with 3-4 `metric-card` children. Use `unit` and `trend` fields for delta semantics.",
      "Stage / process / roadmap → `timeline` or a `grid` of `step-card`.",
      "Compare 2-4 things → `grid` of `comparison-card` with parallel `points` arrays of equal length.",
      "Define a term → `definition-card`. For a list of definitions, use a grid of them.",
      "Person bio → `profile-card` (renders circular photo).",
      "Long article body → `article` (auto-paginates across multiple slides).",
      "Pull-quote / testimonial → `quote` with optional source.",
      "Strategic 2x2 analysis → `swot-matrix`.",
      "Single action / CTA → `cta` button-style text.",
      "Chapter divider → `section-break` (use as the only content of the slide).",
      "Icon + label pair → `icon-text` (uses shape preset for the icon).",
      "Numbered procedure → `numbered-list` (NOT `bullets` with numbers prefixed in text).",
    ],
    doNot: [
      "Do not set fontSize, fontFace, or rgb-hex `color` on text nodes; use `style` and theme tokens.",
      "Do not nest `type:'component'` + `component:'X'`; write `type:'X'` directly.",
      "Do not wrap node fields under `props` — fields are flat.",
      "Do not use absolute pixel coordinates; everything is in cm.",
      "Do not draw your own page-number / logo / footer inside slides — that is chrome.",
      "Do not use shape primitives to fake bullets, dividers, or cards — there are dedicated components.",
      "Do not exceed one `area:'content'` root container per slide.",
    ],
  };
}
